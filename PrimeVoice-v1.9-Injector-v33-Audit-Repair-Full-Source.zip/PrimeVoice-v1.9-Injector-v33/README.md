# Prime Voice v33 — Audit Fixes

This package contains the v33 source update. See `V33_REPAIR_REPORT.md` and `VERIFICATION.md` for verified and pending items.

---

# Prime Voice v33 — Audit Fixes

This package contains the v33 source update. See `V33_REPAIR_REPORT.md` and `VERIFICATION.md` for verified and pending items.

---

# Prime Voice v32 — Audit Repair

See `V32_AUDIT_REPAIR_REPORT.md` for fixed items, corrected audit claims, and remaining work.
Version: 1.9 Injector v32 Audit Repair (versionCode 39).

# Prime Voice v31 — Compile & Lifecycle Repair

Current source version: versionCode 38. See `V31_SOURCE_AUDIT_AND_REPAIR.md`.

# Prime Voice v30 — Unified Shizuku Lifecycle

Current source version: versionCode 37. See `V30_SHIZUKU_LIFECYCLE_HARDENING.md`.

# Prime Voice v30 — Unified Shizuku Lifecycle

Current source version: versionCode 37. See `V30_SHIZUKU_LIFECYCLE_HARDENING.md`.

# Prime Voice v29 — Shizuku Binder Death Recovery\n\nCurrent source version: versionCode 36. See `V29_SHIZUKU_BINDER_HARDENING.md`. This update adds remote UserService Binder death tracking and server-side IPC input validation.\n\n# Prime Voice v28 — Handshake Timeout Hardening

Current source version: versionCode 35. See `V28_HARDENING_REPORT.md`. GitHub Actions validates the built APK package, merged Shizuku provider, provider authority and required DEX classes before uploading the artifact.

## Current source update: v27 (versionCode 34)

See `V27_CONSOLIDATED_UPDATE_REPORT.md` for applied changes and verification limits.

# Prime Voice — v1.9 Injector v22 Social Call (experimental)

Android source project based on the supplied v13 source ZIP.

## Existing features retained
- Floating PV bubble and floating sound-pack panel.
- Music and Fun folders remain isolated.
- Music auto-next / loop and Music-only shuffle.
- Fun plays one selected clip and stops.
- ZIP import limits and partial-extraction cleanup from v11/v12.
- Existing local `ME ONLY` MediaPlayer path.

## v14 additions
- Shizuku Binder bridge with AudioPolicy injector route start/stop and PCM pipe methods.
- Hidden AudioPolicy injector attempt in `ShizukuAudioUserService`.
- MediaExtractor / MediaCodec decode to PCM16, mono downmix, and Shizuku pipe streaming.
- Floating menu output selector: `ME ONLY` or `TEAMMATES ONLY`.
- TEAMMATES ONLY uses the injector path; ME ONLY uses local playback.

See `V14_INJECTOR_IMPLEMENTATION.md` for technical details and limitations.

## Build
Use Android Studio or the included GitHub Actions workflow. Required toolchain: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35. This workspace does not include a Gradle wrapper.

## Device verification still required
The source has not been compiled or installed in this environment. `ROUTE_READY` is not proof that Free Fire teammates receive PCM. Verify on the target Redmi 14C with Shizuku running, headphones connected, and a second player/teammate confirming the sound. Test ME ONLY and TEAMMATES ONLY separately.


## v15 — TEAMMATES ONLY seek bar
- Added duration and playback-position reporting from the MediaCodec output timestamps.
- Added a SeekBar to the TEAMMATES ONLY injected floating player, with elapsed/total time labels.
- Seeking is requested atomically and applied on the decoder worker thread using MediaExtractor.seekTo() and MediaCodec.flush(); the Shizuku PCM route remains active.
- Seeking while paused is accepted and applied without requiring Resume first.
- This is source-level implementation only; compile and device/Free Fire validation are still required.


## v16 — BOTH mode (experimental)
- Adds a third output mode: BOTH (Bluetooth + Team).
- The same decoded mono PCM stream is sent to the Shizuku AudioPolicy injector and a local streaming AudioTrack pinned to a connected Bluetooth A2DP output.
- The Bluetooth monitor is explicitly selected; playback aborts if AudioTrack reports that its routed output is no longer Bluetooth A2DP, to avoid intentionally falling back to the phone speaker.
- This is an experimental source implementation. Android may delay route changes or behave differently across OEM Bluetooth stacks; verify with a connected A2DP headset and a second Free Fire player.


## v19 — BOTH Bluetooth hardening

- Adds a Shizuku-side pause/resume control for the injected AudioTrack, so Pause suspends both local Bluetooth monitoring and the virtual-microphone route.
- Preserves paused state when a seek rebuilds the Shizuku route.
- Watches Android audio-device removal and AudioTrack routing changes; if the selected A2DP device disappears or the track is routed elsewhere, playback fails closed and both outputs are stopped.
- Verifies AudioTrack initialization before playback.
- Keeps Bluetooth A2DP as the supported local-monitor transport; BLE-only headsets are not guaranteed.

Build and device verification are still required. `setPreferredDevice()` is a routing preference, not an OS-level guarantee against every possible fallback race; the route watcher reduces risk but cannot prove speaker silence under all OEM firmware behavior.


## v20 — additional lifecycle and route hardening

See `V20_HARDENING.md`. The route watcher is armed before A2DP negotiation; remote route teardown is centralized in the decoder worker; Bluetooth writes have a bounded stall timeout; seek is clamped to duration; and the Shizuku service refuses to replace an AudioTrack while an old PCM writer is still alive. This remains source-level experimental work, not a compiled or device-tested release.


## v21 additional hardening
See `V21_ADDITIONAL_HARDENING.md` for the route watchdog and serialized start changes. These are source-level changes only; no APK build or device test is claimed.


## v22 — Social Call experimental profile

- Adds a persistent Social Call ON/OFF switch in Settings and the floating library panel.
- When ON, clips require TEAMMATES ONLY or BOTH and Android must currently report `AudioManager.MODE_IN_COMMUNICATION`.
- The Shizuku AudioPolicy route is restricted to capture preset `VOICE_COMMUNICATION` (preset 7); it does not fall back to MIC, CAMCORDER, VOICE_RECOGNITION, or VOICE_CALL presets.
- Playback stops if Android leaves `MODE_IN_COMMUNICATION`. This is a best-effort Internet-call profile, not an app-specific WhatsApp/Messenger/IMO integration. Android does not expose a reliable public API here to prove which app owns the active call or whether that app's mic capture is injectable.
- SIM/telephony calls (`MODE_IN_CALL`) are intentionally not supported. Root/system telephony privileges are not present.
- No APK build or target-device runtime test is claimed. Verify separately with each call app and a second participant.


## v23 Social Call hardening
See `SOCIAL_CALL_V23_HARDENING.md`. This adds independent Shizuku-side MODE_IN_COMMUNICATION gates and stops active Social Call playback when the master switch is turned OFF. It remains experimental and has not been built or device-tested.


## v24 Capture / Injector Cleanup Hardening

- `CaptureTestRecorder` claims the run before starting its worker, preventing STOP from being overwritten by a late worker start.
- STOP requests cancellation and stops the active `AudioRecord` to unblock a blocking read; the worker remains the sole owner that releases the recorder.
- `AudioRecord` is now released in `finally` for initialization, start, read, and processing failures.
- Injector candidate setup now tracks registration state and releases a candidate `AudioTrack` if creation succeeds but `play()` or later setup fails. It only unregisters policies whose registration actually succeeded.
- Existing playback modes, folders, seek behavior, and Social Call behavior were not intentionally changed.
- Source-level change only: Android build and device behavior still require verification.
