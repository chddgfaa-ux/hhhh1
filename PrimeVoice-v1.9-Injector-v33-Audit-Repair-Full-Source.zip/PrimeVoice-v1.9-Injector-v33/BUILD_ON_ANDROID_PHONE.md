# Build Prime Voice APK using GitHub Actions (phone-friendly)

এই প্রজেক্টে একটিমাত্র canonical workflow `.github/workflows/build-apk.yml` রাখা হয়েছে। এটি GitHub Actions-এ Debug APK build করবে। GitHub-এর cloud runner-এ JDK 17, Android SDK 35 এবং Gradle 8.9 দিয়ে Debug APK build করার চেষ্টা করবে। আপনার ফোনে Gradle ইনস্টল করতে হবে না।

## ফোন থেকে build করার ধাপ

1. GitHub-এ একটি নতুন repository তৈরি করুন।
2. এই ZIP extract করে **ভেতরের `PrimeVoice-v1.9-Injector-v27` ফোল্ডারের সব ফাইল** repository-র root-এ upload/commit করুন। `.github/workflows/build-apk.yml`-সহ hidden `.github` ফোল্ডারটিও upload হয়েছে কি না নিশ্চিত করুন।
3. GitHub repository-তে **Actions** tab খুলুন।
4. **Build Prime Voice APK** workflow নির্বাচন করুন।
5. **Run workflow** চাপুন। প্রথমবার Actions enable করার confirmation চাইতে পারে।
6. Run শেষ হলে green check থাকলে run-এ ঢুকে **Artifacts** থেকে `Prime-Voice-debug-apk` download করুন।
7. ZIP extract করে `app-debug.apk` ইনস্টল করুন।

## গুরুত্বপূর্ণ

- এই workflow শুধু cloud build চালাবে; build সফল হবে এমন নিশ্চয়তা নয়। Kotlin/Gradle compile error হলে Actions log-এর প্রথম আসল error অংশটি পাঠান।
- সফল build হলেও এটি Debug APK; Redmi 14C-তে install ও Shizuku/audio mode পরীক্ষা আলাদাভাবে করতে হবে।
- Build সফল হওয়ার পর APK-তে `rikka.shizuku.ShizukuProvider` class এবং merged manifest entry আছে কি না আলাদাভাবে যাচাই করা উচিত।
- ME ONLY, TEAMMATES ONLY, BOTH এবং Social Call—কোনোটিই workflow green হলেই বাস্তবে কাজ করছে প্রমাণিত হয় না।
