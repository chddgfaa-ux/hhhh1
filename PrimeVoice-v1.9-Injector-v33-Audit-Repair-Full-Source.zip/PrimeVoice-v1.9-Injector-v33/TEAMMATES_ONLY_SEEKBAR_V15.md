# TEAMMATES ONLY Seek Bar — v15

## Changes
- The injected-player panel now displays a seek bar plus elapsed and total duration.
- `PcmClipStreamer` reports progress using decoded PCM buffer presentation timestamps.
- `seekTo(positionMs)` queues a seek request; only the decoder worker touches `MediaExtractor` and `MediaCodec`.
- The worker seeks to the previous sync sample and flushes the decoder, then continues writing PCM into the existing Shizuku route.
- The seek request can be made while paused.

## Limits / validation required
- `MediaExtractor.SEEK_TO_PREVIOUS_SYNC` may land slightly before the requested timestamp depending on source encoding.
- PCM already buffered downstream in the Shizuku AudioTrack can briefly remain audible after a seek; exact instantaneous scrubbing would require an explicit downstream AudioTrack flush command in the bridge.
- Duration is shown as `--:--` if the source metadata does not expose duration.
- This source change has not been compiled with Android Gradle Plugin or tested on-device in this environment. Validate build, seek forward/backward, seek while paused, end-of-file, and Free Fire teammate audibility on the Redmi 14C.
