# Two Voice Folders — Music (playlist) / Fun (one-shot) (v10)

> **v11 আপডেট:** (১) Shuffle শুধু Music-এ — Fun Player-এ Shuffle
> বোতাম নেই, Fun-এ Shuffle থেকে কখনো নতুন ভয়েস চালু হয় না।
> (২) Folder sync এখন live — দুই দিকেই listener আছে, শুধু একই Key
> নয়। (৩) Recording `startRecording()`-এর সময় ধরা Folder-এ save
> হয়। (৪) ZIP Import-এ সীমা আছে (১০০ entry / ৫০ MB প্রতি ফাইল /
> ২০০ MB মোট), সীমা ভাঙলে আংশিক ফাইল মুছে Import বাতিল হয়।
> বিস্তারিত: `V11_FIXES.md` দেখুন।
>
> **v12 আপডেট:** ZIP-এর সীমা এখন Non-Audio Entry-তেও প্রযোজ্য —
> প্রতিটি Entry-র decompressed data byte ধরে গোনা হয়। বিস্তারিত:
> `V12_ZIP_SAFETY.md` দেখুন।
>
> **সংস্করণ:** v10 — versionCode **17**, versionName **"1.9 Capture Test v10"**
> (v9-এর Capture Test race fix অপরিবর্তিত।)
> বদলানো ফাইল: নতুন `VoiceFolders.kt`, `FloatingMenuService.kt`,
> `MainActivity.kt` (+ version-এর জন্য `build.gradle.kts` ও লেবেল)।
> CaptureTestProbe.kt, CountDownLatch, Late Registration, Shizuku
> diagnostics — সব v9-এর মতোই অপরিবর্তিত।

## নিয়ম — শুধু নাম আলাদা নয়, Playback Logic-ও আলাদা

| | Music | Fun |
|---|---|---|
| ভয়েস শেষ হলে | পরের ভয়েস Auto Play | Playback সম্পূর্ণ বন্ধ |
| শেষ ভয়েস শেষ হলে | প্রথম ভয়েস থেকে আবার (Infinite Loop) | বন্ধই থাকে |
| ১টি ভয়েস থাকলে | সেটি শেষ হলে আবার বাজে | শেষ হলে বন্ধ হয় |
| Shuffle | শুধু Music-এর ভয়েস থেকে Random | Auto Next নেই, তাই Shuffle-এর ভূমিকা নেই |
| পরের ভয়েস চালাতে | কিছু করতে হয় না | ব্যবহারকারীকে নিজে ক্লিক করতে হয় |
| Next / Previous | Music তালিকার ভেতরে | Fun তালিকার ভেতরে |
| Pause → Play | বর্তমান ভয়েস থেকেই চলে | বর্তমান ভয়েস থেকেই চলে |

## Storage ও Import

- SharedPreferences `prime_voice_library`-তে দুটি আলাদা key:
  `clips_music` ও `clips_fun`। একটি Folder-এর ফাইল অন্য Folder-এর
  তালিকায় কখনো আসে না।
- একই নামের ফাইল দুই Folder-এ আলাদা entry হিসেবে থাকে (key আলাদা,
  তাই নাম মিললেও মিশে যায় না)।
- খোলা Folder (`selected_folder`, app ও floating panel — দুজনেই একই
  prefs পড়ে): Audio Import, ZIP Import ও Recording — তিনটিই খোলা
  Folder-এ সংরক্ষণ হয়। Delete-ও খোলা Folder থেকেই হয়।
- **ZIP Import নতুন:** v1.9/v9-এ ZIP Import ছিল না; v10-এ যোগ করা
  হয়েছে। ZIP-এর audio ফাইল (.mp3/.wav/.m4a/.ogg/.flac/.aac/.opus)
  খোলা Folder-এ extract হয় (IO thread-এ, UI freeze হয় না)।
  Import শুরুর সময় যে Folder খোলা ছিল, ফাইল সেখানেই যায় — মাঝখানে
  Folder বদলালেও ভুল Folder-এ যায় না।
- **Migration (একবার):** v9 ও তার আগের `clips` key-এর সব ফাইল
  Music-এ চলে যায় — কারণ v9-এর আচরণ ছিল playlist + loop, যা
  Music-এর নিয়ম। পুরোনো ব্যবহারকারীর কোনো ফাইল হারায় না।

## Player ও Navigation

- Floating Player-এ `playingFolder` ধরা থাকে (যে Folder-এর clip
  এখন বাজছে)। Completion Listener সেই Folder দেখে সিদ্ধান্ত নেয়:
  Music → Auto Next; Fun → থামে। নাম দেখে নয়, Folder দেখে।
- Next / Previous / Seekbar / Pause / Resume — সবসময় PLAYING
  Folder-এর তালিকার ভেতরে কাজ করে (দেখানো Folder-এর তালিকায় নয়)।
- Folder বদলালে চলমান clip থামানো হয় না — সেটি শেষ পর্যন্ত বাজে,
  তারপর থামে (নিচে scenario F দেখুন)। নতুন Folder-এ clip চাপলে
  পুরোনো player release হয় (generation বাড়ে) — পুরোনো Listener
  মৃত হয়ে যায়।
- Generation / Identity protection (v9) অপরিবর্তিত: Completion
  Listener `mp !== player` ও `gen != playerGeneration` — দুটোই
  মিলিয়ে তবে কিছু করে।
- অ্যাপের (MainActivity) Soundboard-এ ট্যাপ করলে একটি clip বাজে
  (preview) — Auto Next শুধু Floating Player-এ। Folder-এর তালিকা,
  Import ও Delete — দুই জায়গাতেই খোলা Folder অনুযায়ী।

## Execution scenario (কোড পড়ে বের করা order — ফোনে চালিয়ে নয়)

### A. Music-এর ৩টি ভয়েস ধারাবাহিকভাবে চলে

| ধাপ | যা ঘটে |
|---|---|
| 1 | Music Folder খোলা। তালিকা: গান ১, গান ২, গান ৩ (`clips_music`) |
| 2 | গান ১-এ ক্লিক → `startClip(MUSIC, 0)` → `playingFolder = MUSIC` → বাজছে |
| 3 | গান ১ শেষ → listener: পরিচয় + generation মেলে, `playerVisible = true`, folder MUSIC → `autoNext()` → `pickNextIndex()` = ১ → `startClip(MUSIC, 1)` → গান ২ বাজে |
| 4 | গান ২ শেষ → একইভাবে গান ৩ বাজে |

**ফলাফল:** ৩টি ভয়েস ধারাবাহিকভাবে চলে, কোনো ক্লিক ছাড়া।

### B. শেষ গান শেষে প্রথম গান চলে (Infinite Loop)

| ধাপ | যা ঘটে |
|---|---|
| 1 | গান ৩ বাজছে (`currentIndex = 2`, size ৩) |
| 2 | গান ৩ শেষ → listener → `autoNext()` → `pickNextIndex()`: shuffle OFF → `(2 + 1) % 3` = ০ → `startClip(MUSIC, 0)` → গান ১ বাজে |
| 3 | গান ১ শেষ → গান ২ … — চক্র চলতেই থাকে |

**ফলাফল:** শেষ গান শেষে প্রথম গান থেকে আবার শুরু হয়, কখনো থামে না।

### C. Fun-এর একটি ভয়েস শেষ হলে বন্ধ হয়

| ধাপ | যা ঘটে |
|---|---|
| 1 | Fun Folder খোলা। ভয়েস X-এ ক্লিক → `startClip(FUN, 0)` → `playingFolder = FUN` → বাজছে |
| 2 | ভয়েস X শেষ → listener: পরিচয় + generation মেলে, `playerVisible = true`, কিন্তু folder FUN → Auto Next করে না; `seekTo(0)` + বোতাম "▶" করে ফেরে |

**ফলাফল:** Playback সম্পূর্ণ বন্ধ হয়। Play চাপলে X আবার বাজে; পরের ভয়েস বাজে না।

### D. Fun থেকে অন্য ভয়েস নিজে থেকে চালু হয় না

| ধাপ | যা ঘটে |
|---|---|
| 1 | Fun-এ ভয়েস X বাজছে, তালিকায় আরও ভয়েস Y, Z আছে |
| 2 | X শেষ → listener Fun শাখায় ফেরে — `autoNext()` ডাকা হয় না, `startClip()` ডাকা হয় না |
| 3 | Y বা Z বাজাতে হলে ব্যবহারকারীকে নিজে ক্লিক করতে হয় → `startClip(FUN, 1)` → Y বাজে |

**ফলাফল:** Fun থেকে কখনো নিজে থেকে পরের ভয়েস চালু হয় না।

### E. Music ও Fun-এর Import আলাদা থাকে

| ধাপ | যা ঘটে |
|---|---|
| 1 | অ্যাপে Music Folder খোলা → IMPORT AUDIO → song.mp3 → `saveClips(MUSIC)` → শুধু `clips_music`-এ যায় |
| 2 | Fun Folder খোলা → IMPORT ZIP (৩টি fun audio) → `targetFolder = FUN` ধরা হয় → extract → `saveClips(FUN)` → শুধু `clips_fun`-এ যায় |
| 3 | Music Folder খুললে শুধু Music-এর ফাইল দেখায়; Fun Folder খুললে শুধু Fun-এর ফাইল দেখায় |
| 4 | দুই Folder-এ একই নামের ফাইল (যেমন `hello.mp3`) থাকলেও আলাদা entry থাকে — key আলাদা বলে মিশে যায় না |
| 5 | Floating panel-এ Music tab-এ শুধু Music, Fun tab-এ শুধু Fun দেখায় (দুজনেই একই prefs পড়ে) |

**ফলাফল:** একটি Folder-এর ফাইল অন্য Folder-এর Playlist-এ কখনো দেখায় না।

### F. Folder পরিবর্তনের সময় পুরোনো Listener নতুন Folder-এ Playback শুরু করে না

| ধাপ | যা ঘটে |
|---|---|
| 1 | Music-এর গান ২ বাজছে (player panel দেখা যাচ্ছে, `playingFolder = MUSIC`) |
| 2 | ব্যবহারকারী Playlist চাপে → `playerVisible = false`, লাইব্রেরি দেখায় (Music তালিকা) |
| 3 | Fun tab চাপে → `switchFolder(FUN)` → `currentFolder = FUN`, তালিকা = Fun-এর; চলমান গান ২ থামানো হয় না |
| 4 | গান ২ শেষ → listener: পরিচয় + generation মেলে, কিন্তু `playerVisible = false` → Auto Next করে না; শুধু `seekTo(0)` করে ফেরে |
| 5 | ব্যবহারকারী Fun-এর ভয়েস Y-এ ক্লিক করে → `startClip(FUN, 0)` → `releasePlayer()` (generation বাড়ে) → পুরোনো Music listener মৃত → Y বাজে |
| 6 | Y শেষ → listener: folder FUN → থামে, Auto Next হয় না |

**ফলাফল:** পুরোনো Music Listener Fun-এ কিছু শুরু করতে পারে না —
তিনটি স্তরে আটকায়: (১) `playerVisible` guard, (২) listener-এ
ধরা `folder` (MUSIC) — Fun-এর তালিকা দিয়ে Auto Next হয় না,
(৩) নতুন clip শুরু হলে generation বদলে পুরোনো listener মৃত হয়।

### G. Shuffle শুধু Music থেকে Random নেয়

| ধাপ | যা ঘটে |
|---|---|
| 1 | Music বাজছে, Shuffle চালু (⇄ সবুজ + ✓) |
| 2 | গান শেষ → `autoNext()` → `pickNextIndex()`: shuffle ON → `Random.nextInt(musicClips.size)` — শুধু `musicClips` থেকে, `funClips` কখনো pool-এ আসে না; যেটি এইমাত্র শেষ হলো সেটি এলে আবার নেয় |
| 3 | Fun-এর clip বাজছে, Shuffle চালু থাকলেও Fun-এর শেষে Auto Next হয় না — Shuffle-এর কোনো ভূমিকা নেই |

**ফলাফল:** Music-এর Shuffle কখনো Fun-এর ভয়েস বাজায় না।

## সত্যিকারের অবস্থা

- Kotlin compilation: এখানে যাচাই হয়নি (Android SDK / kotlinc নেই) —
  শুধু static syntax scan করা হয়েছে। GitHub Actions-এ build করে
  ফোনে চালিয়ে উপরের scenario-গুলো বাস্তবে মেলাতে হবে।
- Capture Test-এর কোড (CaptureTestProbe.kt, STOP synchronization,
  CountDownLatch, Late Registration, Shizuku diagnostics) v9-এর মতোই
  অপরিবর্তিত — SHA-256 `VERIFICATION.md`-তে আছে।
- অ্যাপের Soundboard-এ ট্যাপ = একটি clip-এর preview (Auto Next নেই);
  পূর্ণ Playlist Logic (Auto Next / Loop / Next / Previous) শুধু
  Floating Player-এ।
