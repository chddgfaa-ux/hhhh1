# Prime Voice v24 — Capture / Injector Cleanup Hardening

## Changes

1. **CaptureTestRecorder start/stop race**
   - `running` is claimed under a lock before the worker is started.
   - A second capture is rejected while a previous worker is still alive, including after a timed-out STOP join.
   - STOP clears the run flag and asks the active `AudioRecord` to stop so a blocking read can return.
   - The worker retains ownership of `AudioRecord.release()`; cleanup is in `finally` and covers initialization, start, read, and processing failures.
   - The worker reference is only cleared by the worker that owns it (or after it has actually terminated).

2. **AudioPolicy candidate partial-failure cleanup**
   - Candidate setup tracks whether `registerAudioPolicy()` returned success.
   - If an `AudioTrack` was created but `play()` or later setup fails, the candidate track is paused/flushed/stopped/released.
   - `unregisterAudioPolicy()` is attempted only for a candidate whose registration returned success.

## Not changed intentionally

- Music/Fun folder separation and playback policies.
- ME ONLY / TEAMMATES ONLY / BOTH output mode behavior.
- Seek, Pause, and Stop behavior outside Capture Test cleanup.
- Social Call preset/mode restrictions.

## Verification status

- Source edits reviewed and ZIP integrity can be checked.
- **Not compiled:** this environment does not have the Android SDK/Gradle build toolchain.
- **Not device-tested:** AudioRecord stop-unblock behavior and AudioPolicy cleanup must be verified on the target Redmi 14C / Android 16.
- A successful `ROUTE_READY` remains insufficient proof that a target game/VoIP app receives the injected PCM.
