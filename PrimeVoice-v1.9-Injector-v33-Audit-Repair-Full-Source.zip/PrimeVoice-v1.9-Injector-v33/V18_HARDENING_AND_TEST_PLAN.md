# Prime Voice v1.9 Injector v18 — hardening notes

## Source changes

1. **Bluetooth disconnect detection:** registers `AudioManager.AudioDeviceCallback`; removal of the selected A2DP device immediately pauses/flushes Bluetooth output, closes the PCM pipe, stops the Shizuku route, and interrupts the decode worker.
2. **Output-route monitoring:** registers `AudioRouting.OnRoutingChangedListener` after initial A2DP route confirmation. A route change away from the selected A2DP device fails closed. The worker also validates the selected device ID before each Bluetooth write.
3. **Remote pause/resume:** extends `IShizukuAudioBridge` with `setInputRoutePaused(boolean)`; Shizuku pauses/resumes its injector AudioTrack as well as the local Bluetooth AudioTrack.
4. **Seek while paused:** after rebuilding the Shizuku route, the new injector track is paused before PCM resumes. Bluetooth queue is flushed; the local track stays paused until Resume.
5. **AudioTrack initialization:** rejects an uninitialized Bluetooth AudioTrack before starting playback.
6. **Version:** versionCode 24; versionName `1.9 Injector v18 BOTH Hardened`.

## Important limitation

Android's `AudioTrack.setPreferredDevice()` expresses a preferred route; it is not a universal hard-routing lock. The new callbacks and per-write route checks reduce the chance of audio going to the phone speaker, but an OEM audio-policy race cannot be ruled out without testing on the exact phone/firmware. If strict speaker silence is mandatory, verify it physically during disconnect tests. This build explicitly supports A2DP devices; BLE-only audio devices may not appear as `TYPE_BLUETOOTH_A2DP`.

## Required verification (not yet performed)

- Clean Gradle debug build with Android SDK 35 / JDK 17.
- Install on Redmi 14C / Android 16; grant Bluetooth/Nearby devices and Shizuku permissions.
- BOTH: confirm local audio in the selected Bluetooth headset and simultaneous reception by a second Free Fire account.
- Disconnect Bluetooth during playback: both outputs must stop; phone speaker must remain silent.
- Change Bluetooth output device during playback: playback must stop safely.
- Pause/resume: both destinations pause/resume together.
- Seek while playing and while paused: neither destination should play pre-seek buffered audio.
- Stop/Next/Previous and Music/Fun folder behavior regression tests.

No APK build or device/runtime test is claimed by this source package.
