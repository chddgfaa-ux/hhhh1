# v11 Fixes — Shuffle Music-only, Live Folder Sync, Recording Folder Capture, ZIP Safety

> **সংস্করণ:** v11 — versionCode **18**, versionName **"1.9 Capture Test v11"**
> (v10-এর Capture Test কোড অপরিবর্তিত।)
> বদলানো ফাইল: শুধু `FloatingMenuService.kt` ও `MainActivity.kt`
> (+ version-এর জন্য `build.gradle.kts` ও লেবেল)।
> Music Auto Next + Loop, Fun Single Clip + Stop, আলাদা Storage, v9
> Migration, Generation/Identity protection, STOP synchronization,
> CountDownLatch, Late Registration, Shizuku diagnostics — সব
> অপরিবর্তিত।

## ১. Shuffle শুধু Music-এর জন্য

**v10-এর সমস্যা:** `toggleShuffle()` Fun Player থেকেও `next(true)`
কল করতে পারত, কারণ `next(true)` playingFolder-এর তালিকা ব্যবহার
করত। Fun-এ Shuffle চাপলে অন্য Fun ভয়েস randomভাবে বাজতে পারত।

**সংশোধন (তিন স্তর):**
1. Fun Player-এ Shuffle বোতাম **নেই** — `showPlayer()` শুধু
   `playingFolder == MUSIC` হলে বোতাম বসায়।
2. `toggleShuffle()` Fun-এ কিছু করে না (`playingFolder != MUSIC`
   হলে সঙ্গে সঙ্গে ফেরে)।
3. `next(shuffle=true)` Fun-এ কিছু করে না — shuffle অনুরোধ এলেও
   নতুন ভয়েস চালু হয় না।
4. `pickNextIndex()` ও Random selection শুধু `musicClips` ব্যবহার
   করে (v10-এও তাই ছিল — যাচাই করা হয়েছে, বদলানো হয়নি)।

### Execution scenario

| ধাপ | যা ঘটে |
|---|---|
| 1 | Fun-এর ভয়েস X বাজছে → player panel-এ Shuffle বোতাম নেই (শুধু Playlist ও Close) — চাপার মতো কিছুই নেই |
| 2 | ধরা যাক কোনোভাবে `toggleShuffle()` ডাকা হলো → `playingFolder = FUN` দেখে সঙ্গে সঙ্গে ফেরে; `shuffleOn` বদলায় না, কোনো clip শুরু হয় না |
| 3 | ধরা যাক কোনোভাবে `next(true)` ডাকা হলো → `folder = FUN` দেখে সঙ্গে সঙ্গে ফেরে; কোনো clip শুরু হয় না |
| 4 | Music-এর গান বাজছে → Shuffle বোতাম দেখা যায় → চাপলে `shuffleOn` বদলায়, চালু হলে random Music গান বাজে; Auto Next-এ `pickNextIndex()` শুধু `musicClips` থেকে নেয় |

**ফলাফল:** Fun-এর কোনো অবস্থায় Shuffle থেকে নতুন ভয়েস চালু হয় না।

## ২. MainActivity ও Floating Panel Folder Sync (live)

**v10-এর সমস্যা:** দুই জায়গা একই `selected_folder` key ব্যবহার
করলেও MainActivity-র Compose `folder` state স্বয়ংক্রিয়ভাবে
আপডেট হতো না। Floating Panel-এ Folder বদলালে অ্যাপ পুরোনো Folder
দেখাত; Import/Delete তখন ভুল Folder-এ যেতে পারত।

**সংশোধন:** দুই দিকেই `SharedPreferences.OnSharedPreferenceChangeListener`
আছে — শুধু একই Key নয়, live sync।
- **MainActivity → Floating Panel:** অ্যাপে `switchFolder()` লিখলে
  service-এর listener জাগে; লাইব্রেরি panel খোলা থাকলে সেটি সঙ্গে
  সঙ্গে নতুন Folder-এর তালিকা ও tab দেখায়। Player panel চলতে
  থাকলে সেটি সরানো হয় না — পরের বার লাইব্রেরি খুললে নতুন Folder
  দেখায়।
- **Floating Panel → MainActivity:** panel-এ `switchFolder()` লিখলে
  অ্যাপের listener জাগে; Compose `folder` state + তালিকা আপডেট হয়
  (পুরোনো clip-এর preview বন্ধ করে)। দুই জায়গার tab সবসময় একই
  Folder দেখায়।
- নিজের লেখা change নিজের listener উপেক্ষা করে (state ইতিমধ্যে
  মিলে গেছে) — কোনো loop বা double কাজ হয় না।
- Listener service-এ field-এ রাখা হয় (SharedPreferences listener
  weak reference-এ রাখে — local variable হলে garbage-collect হয়ে
  sync বন্ধ হয়ে যেত)। `onDestroy()`-এ unregister করা হয়।
- View/State সব main thread-এ ছোঁয়া হয় (`handler.post` /
  `Handler(Looper.getMainLooper())`)।

### Execution scenario — অ্যাপ থেকে বদল

| ধাপ | যা ঘটে |
|---|---|
| 1 | অ্যাপ খোলা (Music), floating লাইব্রেরি খোলা (Music) |
| 2 | অ্যাপে Fun tab চাপে → `switchFolder(FUN)` → prefs-এ `selected_folder = "fun"` লেখে |
| 3 | Service-এর listener জাগে → main thread-এ `newFolder = FUN ≠ currentFolder (MUSIC)`, panel খোলা আছে, `playerVisible = false` → `reloadClips()` + `showLibraryPanel()` → panel সঙ্গে সঙ্গে Fun-এর তালিকা ও highlighted Fun tab দেখায় |

**ফলাফল:** দুই জায়গায় একই Folder।

### Execution scenario — Panel থেকে বদল

| ধাপ | যা ঘটে |
|---|---|
| 1 | অ্যাপ খোলা (Music, Soundboard দেখা যাচ্ছে), floating লাইব্রেরি খোলা |
| 2 | Panel-এ Music tab থেকে Fun tab চাপে → `switchFolder(FUN)` → prefs-এ `"fun"` লেখে |
| 3 | অ্যাপের listener জাগে → main thread-এ `newFolder = FUN ≠ folder (MUSIC)` → `stopAudio()`, `folder = FUN`, তালিকা = Fun-এর → অ্যাপ সঙ্গে সঙ্গে Fun tab highlighted + Fun-এর তালিকা দেখায় |

**ফলাফল:** অ্যাপের state আপডেট হয়; এরপর অ্যাপে Import/Delete
Fun Folder-এই হয় — ভুল Folder-এ যায় না।

### Execution scenario — Player চলতে থাকলে

| ধাপ | যা ঘটে |
|---|---|
| 1 | Music-এর গান বাজছে (player panel দেখা যাচ্ছে) |
| 2 | অ্যাপে Fun tab চাপে → service-এর listener দেখে `playerVisible = true` → panel re-render করে না — গান থামে না, panel সরানো হয় না |
| 3 | ব্যবহারকারী Playlist চাপে → `showLibraryPanel()` → `reloadClips()` → Fun Folder দেখায় |

**ফলাফল:** চলমান Playback-এ sync ব্যাঘাত ঘটায় না।

## ৩. Recording Folder Capture

**v10-এর সমস্যা:** `stopRecording()` থামার সময়ের `folder` দিয়ে
save করত। Recording চলাকালে Folder বদলালে Recording ভুল Folder-এ
যেত।

**সংশোধন:** `startRecording()`-এর সময় `recordingFolder` ধরা হয়।
`stopRecording()` সেই Folder-এই save করে — থামার সময় কোন Folder
খোলা আছে তা দেখে না।

### Execution scenario

| ধাপ | যা ঘটে |
|---|---|
| 1 | Music Folder খোলা → Record শুরু → `recordingFolder = MUSIC` ধরা হয় |
| 2 | Recording চলছে → ব্যবহারকারী Fun tab-এ যায় (`folder = FUN` হয়, তালিকা Fun-এর দেখায়) |
| 3 | Stop & Save চাপে → `targetFolder = recordingFolder = MUSIC` → ফাইল `clips_music`-এ save হয় |
| 4 | খোলা Folder Fun বলে `clips` state বদলায় না — Music-এ ফিরলে Recording দেখা যায় |

**ফলাফল:** Recording সবসময় সেই Folder-এ save হয় যেখানে শুরু
হয়েছিল; ভুল Folder-এ কখনো যায় না।

## ৪. ZIP Import Safety

**v10-এর সমস্যা:** ZIP Entry সংখ্যা ও মোট আকারের কোনো সীমা ছিল না।
ভুল বা অতিরিক্ত বড় ZIP এলে সব ফাইল extract হয়ে যেত, আংশিক
extract-ও থেকে যেত।

**সংশোধন (সীমা copy করার সময়ই মাপা হয়, পরে নয়):**
- Entry সর্বোচ্চ **১০০টি** (audio নয় এমন entry-ও গোনা হয়)।
- প্রতিটি ফাইল সর্বোচ্চ **৫০ MB**।
- মোট সর্বোচ্চ **২০০ MB**।
- সীমা ভাঙলে বা ZIP পড়া না গেলে Import বাতিল হয় — আংশিক
  extract হওয়া **সব ফাইল মুছে ফেলা হয়**, কিছুই save হয় না।
- কাজ আগের মতো IO thread-এ হয় (`Dispatchers.IO`), UI freeze হয় না।

### Execution scenario — অতিরিক্ত বড় ZIP

| ধাপ | যা ঘটে |
|---|---|
| 1 | ৩০০ MB-এর ZIP Import করা হলো (Music Folder খোলা) |
| 2 | Extract চলছে (IO thread) → মোট ২০০ MB ছাড়াতেই `tooBig` → লুপ থামে, `abortReason` সেট হয় |
| 3 | Main thread-এ: `abortReason` আছে বলে `createdFiles`-এর সব ফাইল মুছে ফেলা হয়, কিছুই save হয় না → status: "Import cancelled: ZIP too large (limit 200 MB total). Partial files removed." |

**ফলাফল:** বড় ZIP-এ আংশিক ফাইল থেকে যায় না, Storage ভরে না।

### Execution scenario — ভুল ZIP / বেশি entry

| ধাপ | যা ঘটে |
|---|---|
| 1 | ১৫০টি entry-ওয়ালা ZIP Import করা হলো |
| 2 | ১০১তম entry-তে `abortReason = "too many files (limit 100)"` → লুপ থামে |
| 3 | আংশিক extract হওয়া ফাইলগুলো মুছে ফেলা হয়, কিছুই save হয় না |
| 4 | ভাঙা ZIP (পড়া যায় না) হলে exception ধরা পড়ে → একইভাবে cleanup হয় |

**ফলাফল:** ভুল ZIP নিরাপদে বাতিল হয়, আংশিক ফাইল থাকে না।

## সত্যিকারের অবস্থা

- Kotlin compilation: এখানে যাচাই হয়নি (Android SDK / kotlinc নেই) —
  শুধু static syntax scan করা হয়েছে। GitHub Actions-এ build করে
  ফোনে চালিয়ে উপরের scenario-গুলো বাস্তবে মেলাতে হবে।
- Capture Test-এর কোড (CaptureTestProbe.kt, STOP synchronization,
  CountDownLatch, Late Registration, Shizuku diagnostics) v10-এর মতোই
  অপরিবর্তিত — SHA-256 `VERIFICATION.md`-তে আছে।
