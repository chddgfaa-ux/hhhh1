# Build status — v14

- Source archive created from the v13 project with the additive v14 injector changes.
- AndroidManifest.xml parses as XML; source files pass a brace-balance sanity check.
- The original v13 Capture Test, folder, ZIP-safety, recorder, and import files were not modified.
- A full Android build was **not run**: this environment has no Gradle executable, Android SDK `android.jar`, or Android Gradle Plugin installation. Running plain `kotlinc` cannot compile Android sources without those platform/dependency classes.
- Therefore no APK is supplied and no compilation success is claimed. Use Android Studio / the included GitHub Actions workflow with JDK 17, Gradle 8.9, and Android SDK 35.
- After build, install and test on the target device. A successful build or `ROUTE_READY` is not proof of Free Fire teammate audio reception.
