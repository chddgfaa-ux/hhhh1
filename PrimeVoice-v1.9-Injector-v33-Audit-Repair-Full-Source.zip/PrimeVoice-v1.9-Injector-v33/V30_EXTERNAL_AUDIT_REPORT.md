# PrimeVoice v1.9 Injector v30 — নিরাপত্তা ও কার্যকারিতা পর্যালোচনা রিপোর্ট

Nov 28, 2026 · @royan

## সারসংক্ষেপ

v30 সোর্স এখন যে অবস্থায় আছে সেটা কম্পাইল হবে না। বিল্ড ঠিক করলেও Shizuku-ভিত্তিক TEAMMATES ONLY, BOTH আর Social Call মোড সম্ভবত একবারও চালু হবে না, কারণ Shizuku আপনার দুটি UserService ক্লাস শুরুই করতে পারবে না।

তিনটি ব্লকার সবচেয়ে জরুরি:

- **বিল্ড ফেল (C1, C2):** `FloatingMenuService.kt`-এ চারটি ভ্যারিয়েবল ডিক্লেয়ার করা নেই, আর `MainActivity.kt`-এ `GraphicEq` আইকনের import নেই।
- **UserService চালু হয় না (R1, R2):** দুটি ক্লাস `android.app.Service` থেকে extend করা, অথচ Shizuku ক্লাসটিকে `IBinder` হিসেবে কাস্ট করে। কাস্ট ব্যর্থ হলে প্রসেস `exit(1)` করে।
- **গেমের জন্য ব্যবহারযোগ্য নয় (R5):** ফ্লোটিং প্যানেলে স্ক্রল নেই, উচ্চতার সীমাও নেই। Free Fire-এর ল্যান্ডস্কেপ স্ক্রিনে ক্লিপ-তালিকা আর নিচের বোতামগুলো স্ক্রিনের বাইরে চলে যাওয়ার কথা।

নিরাপত্তার দিক থেকে দূর থেকে কাজে লাগানো যায় এমন গুরুতর দুর্বলতা পাইনি। অ্যাপে `INTERNET` পারমিশন নেই, আর এক্সপোর্টেড কম্পোনেন্ট শুধু লঞ্চার Activity ও Shizuku Provider। বাকি নিরাপত্তা-পর্যবেক্ষণ ছোট মাত্রার, বিস্তারিত নিচে।

## পরিধি ও পদ্ধতি

এই রিপোর্ট স্ট্যাটিক সোর্স রিভিউ; অ্যাপটি কম্পাইল বা ফোনে চালানো হয়নি। স্থানীয় পরিবেশে Android SDK নেই, তাই Kotlin কম্পাইলার চালানো সম্ভব হয়নি।

**যা পড়া হয়েছে:** সব Kotlin সোর্স (৯টি ফাইল), দুটি AIDL, `AndroidManifest.xml`, Gradle ফাইল, GitHub Actions ওয়ার্কফ্লো, `verify-apk.sh` আর আপনার নোটস (V12–V30)। CaptureTestProbe-এর (১০০০+ লাইন) শুধু শুরুর অংশ, কন্টেক্সট ও থ্রেড ব্যবহার দেখা হয়েছে।

**কীভাবে যাচাই হয়েছে:** Shizuku-র আসল সোর্স (`RikkaApps/Shizuku-API` ও `Shizuku`) ক্লোন করে `UserService.create`, `UserServiceManager`, `UserServiceRecord` আর ডেমো UserService পড়া হয়েছে। R1, R3, R4 তার ওপর দাঁড়িয়ে।

**নিশ্চয়তার লেবেল:**

- *নিশ্চিত* — সোর্সে সরাসরি দেখা যায় (আনডিক্লেয়ার্ড সিমবল, মিসিং import)
- *উচ্চ* — Shizuku-র সোর্স আর Java সিম্যান্টিক্স থেকে পাওয়ার মতো
- *অনুমান* — লেআউট/ডিভাইসের আচরণ নিয়ে, Redmi 14C-তে যাচাই দরকার

আপনার নিজের নোটও স্বীকার করে (`FINAL_BUILD_REPORT.md`, `V30_*.md`) যে এই সংস্করণ বিল্ড করা বা ডিভাইসে টেস্ট করা হয়নি। তাই আমার ফলাফল আপনার নোটের সাথে বিরোধী নয়, বরং সেখানকার ফাঁকগুলোর উত্তর।

## ফাইন্ডিংসের তালিকা

মোট ২৯টি ফাইন্ডিং: ২টি বিল্ড ব্লকার ও ২টি Shizuku অচল (Critical), ৩টি High, ৬টি Medium, ১৪টি Low, ২টি Info। আইডির অক্ষর: C = বিল্ড, R = রানটাইম, S = নিরাপত্তা/প্যাকেজিং, B = অন্যান্য বাগ।

| আইডি | তীব্রতা | বিষয় | ফাইল | নিশ্চয়তা |
| --- | --- | --- | --- | --- |
| C1 | Critical | চারটি মেম্বার (`pcmStreamer`, `injectedStatusText`, `injectedDurationMs`, `injectedPlaybackFailed`) ডিক্লেয়ার করা নেই | FloatingMenuService.kt | নিশ্চিত |
| C2 | Critical | `GraphicEq` আইকনের import নেই | MainActivity.kt:911 | নিশ্চিত |
| R1 | Critical | UserService ক্লাস `IBinder` নয়, তাই Shizuku শুরু করতে পারে না | ShizukuAudioUserService.kt:25, CaptureTestUserService.kt:28 | উচ্চ |
| R2 | Critical | `Service`-এ baseContext নেই, `getSystemService` NPE দেবে | ShizukuAudioUserService.kt:47, 168; CaptureTestProbe.kt:394 | নিশ্চিত |
| R3 | High | AIDL-এ `destroy()` নেই, ফলে প্রসেস ও AudioPolicy লিক হয় | দুটি `.aidl` | উচ্চ |
| R4 | High | Activity ও ফ্লোটিং সার্ভিস একই UserService রেকর্ড `remove=true` দিয়ে মুছে দেয় | MainActivity.kt:544; FloatingMenuService.kt:202, 816 | উচ্চ |
| R5 | High | ফ্লোটিং প্যানেলে স্ক্রল/উচ্চতা-সীমা নেই, ল্যান্ডস্কেপে কাটা পড়ে | FloatingMenuService.kt:328, 433, 626 | অনুমান |
| R6 | Medium | সার্ভিস না ঠাড়লে অসীম reconnect লুপ | MainActivity.kt:239; FloatingMenuService.kt:212 | নিশ্চিত |
| R7 | Medium | ইনজেক্টর API 33+ চায়, অথচ `minSdk = 26` | ShizukuAudioUserService.kt:232; app/build.gradle.kts | উচ্চ |
| R8 | Medium | শুধু একটি capture preset (সাধারণত `7`) কভার হয় | ShizukuAudioUserService.kt:158–193 | অনুমান |
| R9 | Medium | `FloatingMenuService` ফোরগ্রাউন্ড সার্ভিস নয় | FloatingMenuService.kt:803; AndroidManifest.xml | উচ্চ |
| R10 | Low | `UserServiceArgs.version(2)` স্থির, আপডেটে পুরোনো কোড চলতে পারে | MainActivity.kt:108; FloatingMenuService.kt:89 | নিশ্চিত |
| R11 | Low | sample-rate fallback উপেক্ষিত, স্পিড/পিচ ভুল হতে পারে | ShizukuAudioUserService.kt:155; PcmClipStreamer.kt:250 | নিশ্চিত |
| R12 | Medium | `controlLock` ও ব্লকিং রাইটে UI থ্রেড আটকে ANR হতে পারে | PcmClipStreamer.kt:363, 528, 534 | উচ্চ |
| R13 | Low | প্রতি ক্লিপ ও seek-এ AudioPolicy নতুন করে রেজিস্টার হয় | PcmClipStreamer.kt:179, 311 | অনুমান |
| S1 | Low | অপ্রয়োজনীয় exported `<service>` এন্ট্রি | AndroidManifest.xml | নিশ্চিত |
| S2 | Low | Binder-এ caller যাচাই নেই (defense-in-depth) | ShizukuAudioUserService.kt | নিশ্চিত |
| S3 | Medium | শুধু debug APK; CI-তে প্রতি রানে ভিন্ন সাইনিং কী, আপডেট ইনস্টল ফেল | build-apk.yml; app/build.gradle.kts | উচ্চ |
| S4 | Low | CI অ্যাকশন ট্যাগে পিন করা, commit SHA-তে নয় | build-apk.yml | নিশ্চিত |
| S5 | Low | `verify-apk.sh` ভুল আশ্বাস দেয় | scripts/verify-apk.sh | নিশ্চিত |
| S6 | Low | ক্লিপ মুছলেও ফাইল ডিস্কে থাকে | MainActivity.kt:946 | নিশ্চিত |
| S7 | Info | টেস্ট কোড ও টেস্ট UI প্রোডাকশন বিল্ডেও থাকে | AndroidManifest.xml; MainActivity.kt:1037 | নিশ্চিত |
| B1 | Low | নামে `\|` থাকলে এন্ট্রি ভাঙে; ক্রম ও ডুপ্লিকেট হারায় | VoiceFolders.kt:138, 144 | নিশ্চিত |
| B2 | Low | রেকর্ডারে AudioRecord লিক ও read ত্রুটিতে busy loop | PcmWavRecorder.kt:192–210 | নিশ্চিত |
| B3 | Low | ZIP ইমপোর্টে স্ক্রিন ঘুরলে অর্ফান ফাইল; লম্বা নামে পুরো ইমপোর্ট বাতিল | MainActivity.kt:609–705 | উচ্চ |
| B4 | Low | ME ONLY মোডেও Shizuku bind ও Toast | FloatingMenuService.kt:274, 292 | নিশ্চিত |
| B5 | Low | বাবল স্ক্রিনের বাইরে টেনে নেওয়া যায় | FloatingMenuService.kt:352 | নিশ্চিত |
| B6 | Low | `playClip`-এ মেইন থ্রেডে `prepare()` | MainActivity.kt:730 | নিশ্চিত |
| B7 | Info | README এলোমেলো; অনুপস্থিত ফাইলের উল্লেখ | README.md; CAPTURE\_TEST.md | নিশ্চিত |
