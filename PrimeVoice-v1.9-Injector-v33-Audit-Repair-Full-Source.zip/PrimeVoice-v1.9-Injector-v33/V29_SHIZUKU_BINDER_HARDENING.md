# Prime Voice v29 — Shizuku Binder Death & IPC Hardening

## Source changes
1. Added `linkToDeath` tracking for the remote Shizuku Audio UserService Binder. This is separate from Shizuku manager Binder monitoring and detects the audio service process dying while Shizuku itself remains alive.
2. Added safe unlink/cleanup of the remote Binder death recipient on disconnect, handshake failure, heartbeat failure, Shizuku manager death, and UI disposal.
3. A null service Binder or a Binder that dies during registration now fails closed and schedules reconnection.
4. Added server-side sample-rate validation (8,000–96,000 Hz) before route creation.
5. Added server-side PCM chunk validation: non-empty, even byte count for PCM16, maximum 65,536 bytes per Binder transaction.
6. Added service lifecycle identity logs (UID/PID/Android SDK) for diagnostics without hardcoding shell UID, preserving Shizuku configurations that may run with a different authorized identity.
7. Updated versionCode to 36 and versionName to v29.

## What this does NOT prove
- It does not bypass Android/HyperOS audio restrictions.
- It does not prove AudioPolicy registration or teammate-side microphone reception.
- It does not prove ME ONLY / TEAMMATES ONLY / BOTH or Social Call behavior on the Redmi 14C.
- No APK was built in this environment. GitHub Actions must compile and run the packaged APK verification script.
