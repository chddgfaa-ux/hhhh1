# v20 hardening changes (source-level; not runtime-certified)

## Changes over v19

1. **Bluetooth route watcher is armed before route negotiation.** It ignores expected transient routing states until the selected A2DP device has been positively observed, then fails closed on subsequent route changes.
2. **Single owner for Shizuku AudioPolicy teardown.** The PCM decoder worker's `finally` block owns remote route teardown. UI Stop and Bluetooth failure paths signal cancellation, mute/flush local output, close the pipe, and interrupt the worker instead of racing a second Binder stop against an in-flight route start/seek.
3. **Bounded Bluetooth writes.** A2DP non-blocking writes that make no progress for 750 ms fail closed instead of holding the dual-output lock indefinitely.
4. **Seek clamping.** Requested seek positions are clamped to the known clip duration when available.
5. **Shizuku pipe teardown guard.** The service waits up to 1500 ms for its previous PCM writer to exit. If it remains alive, it does not release/replace the AudioTrack underneath that thread and refuses a new route start with `ROUTE_STOP_TIMEOUT`.
6. **Diagnostics and active health check.** Shizuku diagnostics report whether the PCM pipe worker is alive and its last pipe failure. AIDL now exposes `getPipeStatus()`, and the client checks it every 500 ms while streaming so a dead remote writer fails the local Bluetooth output closed instead of silently continuing alone.

## Important limits

- This is not sample-accurate synchronization. Bluetooth A2DP has transport/device latency and the Shizuku AudioTrack has a separate output queue. Both receive the same PCM sequence, but audible start times can differ.
- `setPreferredDevice()` is a routing preference; route monitoring and fail-closed behavior reduce risk but cannot guarantee that every OEM firmware will never transiently route elsewhere.
- Pipe health is polled every 500 ms; this is not an asynchronous Binder death callback and a failure may remain audible for a short interval before detection.
- Android 16 / Redmi 14C / Free Fire runtime behavior remains untested.
- No APK build is claimed. This ZIP has no Gradle wrapper and this environment has no Android SDK or Gradle installation.

## Required validation

Clean build; install; verify Bluetooth A2DP + Shizuku + Free Fire; check disconnect/device-switch; pause/resume; seek while playing and paused; stop/next/previous; test Music auto-next/loop and Fun one-shot; inspect `getDiagnostics()` and `getLog()` after injected playback.
