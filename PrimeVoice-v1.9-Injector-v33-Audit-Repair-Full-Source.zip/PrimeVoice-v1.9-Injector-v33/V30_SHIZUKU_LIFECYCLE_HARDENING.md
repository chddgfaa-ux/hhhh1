# Prime Voice v30 — Shizuku Lifecycle Hardening

## Applied source changes
1. FloatingMenuService now treats `onServiceConnected` as provisional and performs `getDiagnostics()` on a worker thread before releasing queued playback requests.
2. The floating playback path no longer immediately fails just because the asynchronous Shizuku bind has not completed. The requested clip waits for a successful handshake, with a generation check to discard stale callbacks.
3. Added remote UserService Binder `linkToDeath` monitoring, `onBindingDied`, `onNullBinding`, Shizuku manager Binder received/dead listeners, 8-second bind/handshake timeout, heartbeat and bounded exponential reconnect.
4. Added cleanup of Binder death recipients, callbacks and pending handler tasks when the service disconnects or is destroyed.
5. UserService `debuggable` now follows `BuildConfig.DEBUG`, so release builds do not request a debuggable UserService.
6. Added the platform `INTERACT_ACROSS_USERS_FULL` permission requirement to both exported Shizuku UserService declarations to reduce unintended direct binding by ordinary third-party apps (the Shizuku shell-mediated flow must be confirmed on-device).
7. Fixed a duplicate reconnect-attempt increment in MainActivity that caused backoff to advance faster than intended.
8. VersionCode 37 / `1.9 Injector v30 Unified Shizuku Lifecycle`.

## Security / compatibility notes
- Shizuku UserService declarations remain exported because Shizuku must be able to start/bind the service. A naive app-only signature permission or UID allowlist can block Shizuku's shell-mediated Binder flow, so no unverified caller restriction was added. This still requires an explicit threat-model review and real-device validation; the GitHub APK verifier now checks that both service declarations retain this permission.
- MainActivity diagnostic bridge and FloatingMenuService playback bridge are still separate bindings to the same UserService component. They now both recover more safely, but a single process-wide shared connection manager is a future architectural consolidation, not claimed as completed here.
- Synchronous AIDL calls inside the PCM streaming implementation require a further end-to-end thread/timeout review; this source update does not claim every IPC call has a hard timeout.
- No APK build or Redmi 14C runtime test was performed in this environment. GitHub Actions must compile the source and verify the built APK.
- AudioPolicy injection and teammate-side reception remain Android/OEM/game dependent and are not guaranteed by Shizuku lifecycle improvements alone.
