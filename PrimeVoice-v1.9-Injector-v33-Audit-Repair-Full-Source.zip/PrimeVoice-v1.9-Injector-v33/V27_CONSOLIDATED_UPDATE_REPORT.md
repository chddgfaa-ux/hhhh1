# Prime Voice v27 — Consolidated Source Update

Base: Prime Voice v1.9 Injector v25.6 Async Shizuku Recovery
New versionCode: 34
New versionName: 1.9 Injector v27 Shizuku Provider Audit

## Source audit and applied update

1. Retained the v25.6 asynchronous Shizuku lifecycle implementation:
   - Worker-thread UserService handshake and heartbeat diagnostics.
   - 10-second heartbeat with an in-flight guard.
   - Stale Binder callback checks.
   - 8-second bind callback timeout.
   - onBindingDied/onNullBinding recovery.
   - bounded reconnect backoff.
2. Retained the Shizuku Provider dependency in app/build.gradle.kts:
   `implementation("dev.rikka.shizuku:provider:13.1.5")`
   The Manifest declares `rikka.shizuku.ShizukuProvider` with
   `${applicationId}.shizuku` authority. This corrects the source-level
   omission reported against v24. It does NOT prove the class is present
   in a built APK; that requires APK DEX inspection after a successful build.
3. Retained the Shizuku UserService AIDL bridge and the separate Capture Test
   service, without applying the v24 patch blindly over the already-updated
   v25.6 implementation.
4. Retained the Music/Fun folder separation and playback behavior, the
   floating menu minimize/close behavior, Social Call gate, and existing
   three-mode output selection.
5. Bumped app versionCode from 33 to 34 and versionName to v27.

## Important verification status

- ZIP integrity: to be checked on the delivered archive.
- Source inspection: performed for Gradle dependencies, Manifest, Shizuku
  lifecycle, AIDL bridge, UserService, Capture Test service, and floating UI.
- Android Gradle build: NOT RUN in this environment (Gradle executable and
  Gradle wrapper are absent).
- APK DEX / merged Manifest inspection: NOT RUN; no new APK was built.
- Redmi 14C / Android 16 runtime: NOT TESTED in this session.
- ME ONLY / TEAMMATES ONLY / BOTH / Social Call: NOT newly tested here.
  Prior user-reported behavior remains historical evidence, not a v27 test.

## Required post-build checks

1. Run `:app:assembleDebug`.
2. Inspect merged APK manifest for provider
   `rikka.shizuku.ShizukuProvider` and authority
   `com.primevoice.app.shizuku`.
3. Inspect DEX for `rikka/shizuku/ShizukuProvider`.
4. Install on Redmi 14C and confirm Shizuku connected state.
5. Test ME ONLY, TEAMMATES ONLY, BOTH separately with local and teammate
   listening checks. Test Social Call only during an actual supported call.
6. Verify Music auto-next/loop, Fun one-shot, minimize persistence, and close
   stopping playback.

A successful source ZIP check is not an APK build or device verification.


## Phone-friendly cloud build workflow (added after v27 package)
- Added `.github/workflows/build-apk.yml` for manual and main/master push builds.
- Workflow provisions JDK 17, Android SDK 35, Gradle 8.9; runs `:app:assembleDebug`; uploads `app-debug.apk` as `Prime-Voice-debug-apk`.
- This is build automation only. No workflow has been run from this environment; compilation, APK DEX/manifest inspection, and Redmi 14C runtime tests remain pending.
