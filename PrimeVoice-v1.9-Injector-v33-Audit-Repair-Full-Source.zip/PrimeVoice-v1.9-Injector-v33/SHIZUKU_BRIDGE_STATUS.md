# Shizuku bridge status (v1.8)

## Implemented
- Shizuku `UserServiceArgs` binding request from Settings after Shizuku permission is granted.
- UserService Binder interface (`IShizukuAudioBridge`) with UID and diagnostic methods.
- Diagnostic response checks SDK level and whether framework AudioPolicy/AudioMix-related classes are present.

## Not implemented / not proven
- No `AudioManager.registerAudioPolicy()` call.
- No `AudioMixingRule` injector registration.
- No PCM pipe feeding an AudioTrack owned by an AudioPolicy mix.
- No proof that Free Fire's `AudioRecord(MIC)` receives soundboard PCM.
- No claim that the service UID is privileged; UID is reported for observation only.

## Why this is deliberate
The reference APK analysis describes hidden/internal AudioPolicy behavior, but does not provide its original source code. Recreating that path by guessing reflection signatures could crash or silently fail on Android 16 / HyperOS. The current bridge is a buildable diagnostic foundation; the next stage must be validated against actual framework behavior on the target phone and must include an end-to-end capture test.


## v1.9 lifecycle update
Shizuku permission-result and binder lifecycle listeners are registered and removed with the app screen. Duplicate bind requests are guarded, and the diagnostic service is unbound when the screen is disposed. This remains a diagnostics bridge only; Free Fire microphone routing is not implemented or verified.
