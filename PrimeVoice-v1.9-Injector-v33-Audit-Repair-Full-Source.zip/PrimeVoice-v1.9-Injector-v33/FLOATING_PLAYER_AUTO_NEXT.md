# Floating Player — Auto Next + Infinite Loop (v9)

> **v10 আপডেট:** Auto Next + Infinite Loop এখন শুধু **Music** Folder-এ
> প্রযোজ্য। **Fun** Folder-এর clip শেষ হলে Playback থামে (কোনো Auto
> Next / Loop নেই)। বিস্তারিত: `VOICE_FOLDERS.md` দেখুন।
>
> **v11 আপডেট:** Shuffle-ও এখন শুধু **Music**-এ। Fun Player-এ Shuffle
> বোতাম নেই, আর Fun-এ Shuffle থেকে কখনো নতুন ভয়েস চালু হয় না।
> বিস্তারিত: `V11_FIXES.md` দেখুন।
>
> **সংস্করণ:** v9 — versionCode **16**, versionName **"1.9 Capture Test v9"**
> (v8-এর Capture Test race fix অপরিবর্তিত; শুধু Floating Player-এ এই
> ফিচার যোগ করা হয়েছে।)
> বদলানো ফাইল: শুধু `FloatingMenuService.kt` (+ version-এর জন্য
> `build.gradle.kts` ও `MainActivity.kt`-এর ১ লাইনের লেবেল)।
> MainActivity-র নিজের in-app player-এ কিছু বদলানো হয়নি।

## আচরণ (৯টি প্রয়োজন)

1. **Auto Next:** একটি ভয়েস শেষ হলে Completion Listener পরের ভয়েস
   স্বয়ংক্রিয়ভাবে চালু করে (`autoNext()` → `startClip(next)`).
2. **Infinite Loop:** শেষ ভয়েস শেষ হলে `(currentIndex + 1) % size`
   = ০ — প্রথম ভয়েস থেকে আবার শুরু হয়। Playback নিজে থেকে কখনো থামে না।
3. **Single clip:** Playlist-এ ১টি ভয়েস থাকলে `pickNextIndex()` ০
   ফেরত দেয় — সেটি শেষ হলে আবার বাজে।
4. **Pause:** Pause করলে MediaPlayer completion callback দেয় না, তাই
   Auto Next হয় না।
5. **Pause → Play:** একই player-এ `start()` হয় — বর্তমান ভয়েস থেকেই চলে।
6. **Next / Previous আগের মতো:** `next(false)` = `(currentIndex + 1) % size`,
   `previous()` = ৩ সেকেন্ডের বেশি বাজলে শুরুতে ফেরে, নাহলে আগের clip
   (প্রথম clip-এ থাকলে শেষ clip)। এগুলোর কোড একটুও বদলানো হয়নি।
7. **Shuffle:** ⇄ বোতাম এখন Shuffle চালু/বন্ধ করে (সবুজ + ✓ চিহ্ন
   দেখায় চালু থাকলে)। চালু থাকলে Auto Next random ভয়েস নেয় — যেটি
   এইমাত্র শেষ হলো সেটি নয় (Playlist-এ একাধিক ভয়েস থাকলে); বন্ধ থাকলে
   Playlist-এর ক্রম অনুসরণ করে। Manual Next সবসময় ক্রম অনুসরণ করে।
8. **Stop / Close:** Close বা Playlist চাপলে `playerVisible = false`
   হয়। Completion Listener তখন Auto Next করে না — clip শুধু শেষ হয়,
   হঠাৎ নতুন ভয়েস বাজে না। Service বন্ধ হলে / player release হলে
   generation বদলে যায়, তাই পুরোনো listener-ও কিছু করতে পারে না।
9. **Stale Listener:** প্রতিটি MediaPlayer তৈরির সময় একটি generation
   ধরা হয় (`playerGeneration`, `releasePlayer()`-এ বাড়ে)। Completion
   Listener `mp !== player` (পরিচয়) **এবং** `gen != playerGeneration`
   — দুটোই মিলিয়ে তবে Auto Next করে। পুরোনো listener নতুন player-কে
   release বা পরিবর্তন করতে পারে না।

## Execution scenario (কোড পড়ে বের করা order — ফোনে চালিয়ে নয়)

### A. Single-clip Playlist — Infinite Loop

| ধাপ | যা ঘটে |
|---|---|
| 1 | Playlist-এ ১টি clip। `startClip(0)` → player তৈরি (gen = 5) → বাজছে |
| 2 | Clip শেষ → completion listener: `mp === player`, gen ৫ = ৫, `playerVisible = true` → `autoNext()` |
| 3 | `pickNextIndex()`: size ১ → ০ ফেরত দেয় → `startClip(0)` → `releasePlayer()` (gen ৬) → নতুন player (gen ৬) → বাজছে |
| 4 | ধাপ ২–৩ বারবার চলে |

**ফলাফল:** একটিই ভয়েস বারবার বাজে, কখনো থামে না।

### B. Pause — Auto Next হয় না, Play করলে একই ভয়েস থেকে চলে

| ধাপ | যা ঘটে |
|---|---|
| 1 | Clip ২ বাজছে। ব্যবহারকারী Pause চাপে → `togglePlayback()` → `mp.pause()` → বোতাম "▶" |
| 2 | MediaPlayer pause অবস্থায় completion callback দেয় না → listener চলে না → Auto Next হয় না |
| 3 | ব্যবহারকারী Play চাপে → `togglePlayback()` → একই player-এ `mp.start()` → clip ২ থামা জায়গা থেকে চলে |
| 4 | Clip ২ শেষ হলে → listener → `autoNext()` → clip ৩ বাজে |

**ফলাফল:** Pause-এ কোনো Auto Next নেই; Play করলে বর্তমান ভয়েস থেকেই চলে।

### C. Manual Next — আগের মতো, Stale Listener কিছু করে না

| ধাপ | যা ঘটে |
|---|---|
| 1 | Clip ২ বাজছে (gen ৫)। ঠিক শেষ মুহূর্তে ব্যবহারকারী ▶\| (Next) চাপে |
| 2a | **Next আগে:** `next(false)` → `startClip(3)` → `releasePlayer()` (gen ৬) → নতুন player (gen ৬) → clip ৩ বাজছে। এরপর পুরোনো clip ২-এর completion callback এলে listener দেখে `mp !== player` (পুরোনো player) **এবং** gen ৫ ≠ ৬ → কিছু করে না, ফিরে যায় |
| 2b | **Completion আগে:** listener → `autoNext()` → clip ৩ বাজছে (gen ৬)। এরপর Next চাপলে `next(false)` → clip ৪ বাজে |

**ফলাফল:** দুটি order-ই ঠিক আছে — একবার advance হয় (2a-তে Next-এর জন্য, 2b-তে completion + Next = দুবার, যেটা ব্যবহারকারীর চাপের কারণে সঠিক)। পুরোনো listener নতুন player-কে release করে না, দ্বিতীয়বার advance করে না।

### D. Previous — আগের মতো

| ধাপ | যা ঘটে |
|---|---|
| 1 | Clip ৩ বাজছে, position ১০ সেকেন্ড। \|◀ চাপলে position > ৩০০০ ms → `seekTo(0)` → clip ৩ শুরু থেকে বাজে |
| 2 | Clip ৩ বাজছে, position ১ সেকেন্ড। \|◀ চাপলে `startClip(2)` → clip ২ বাজে |
| 3 | Clip ১ (প্রথম) বাজছে, position ১ সেকেন্ড। \|◀ চাপলে `startClip(lastIndex)` → শেষ clip বাজে |

**ফলাফল:** Previous আগের মতোই কাজ করে; Auto Next-এর সঙ্গে কোনো সংঘর্ষ নেই।

### E. Shuffle ON — Auto Next Random; Shuffle OFF — ক্রম অনুসরণ

| ধাপ | যা ঘটে |
|---|---|
| 1 | ⇄ চাপলে `shuffleOn = true` হয়, বোতাম সবুজ + "⇄ ✓" হয়, সঙ্গে সঙ্গে একটি random clip বাজে (আগের মতোই) |
| 2 | ওই clip শেষ হলে → listener → `autoNext()` → `pickNextIndex()`: shuffle ON, size > ১ → `Random.nextInt(size)` — যেটি এইমাত্র শেষ হলো সেটি এলে আবার নেয় → অন্য একটি random clip বাজে |
| 3 | আবার ⇄ চাপলে `shuffleOn = false` হয়, বোতাম আগের রঙে ফেরে, বর্তমান clip চলতে থাকে |
| 4 | ওই clip শেষ হলে → `autoNext()` → shuffle OFF → `(currentIndex + 1) % size` → পরের clip ক্রম অনুযায়ী বাজে; শেষ clip হলে প্রথম clip থেকে শুরু |

**ফলাফল:** Shuffle চালু থাকলে পরের ভয়েস random; বন্ধ থাকলে ক্রম অনুযায়ী, শেষে প্রথম থেকে আবার।

### F. Close / Stop — অপ্রত্যাশিত restart নেই

| ধাপ | যা ঘটে |
|---|---|
| 1 | Clip ২ বাজছে। ব্যবহারকারী Close চাপে → `playerVisible = false`, প্যানেল সরে যায় (audio তখনো বাজছে — আগের আচরণ) |
| 2 | Clip ২ শেষ হলে → listener: পরিচয় + generation মেলে, কিন্তু `playerVisible = false` → Auto Next করে না; শুধু `seekTo(0)` + UI reset করে ফেরে |
| 3 | ব্যবহারকারী আবার bubble চাপলে লাইব্রেরি দেখায়; clip চাপলে `startClip()` থেকে নতুন করে বাজে, Auto Next আগের মতো কাজ করে |

**ফলাফল:** Close-এর পরে হঠাৎ নতুন ভয়েস বাজে না। Service বন্ধ হলে
`onDestroy()` → `releasePlayer()` → generation বাড়ে → পুরোনো listener
আর কিছু করতে পারে না।

## সত্যিকারের অবস্থা

- Kotlin compilation: এখানে যাচাই হয়নি (Android SDK / kotlinc নেই) —
  শুধু static syntax scan করা হয়েছে। GitHub Actions-এ build করে
  ফোনে চালিয়ে উপরের scenario-গুলো বাস্তবে মেলাতে হবে।
- Capture Test-এর কোড (CaptureTestProbe.kt, STOP synchronization,
  CountDownLatch, Late Registration, Shizuku diagnostics) v8-এর মতোই
  অপরিবর্তিত — SHA-256 `VERIFICATION.md`-তে আছে।
