#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
if [[ ! -f "$APK" ]]; then echo "ERROR: APK not found: $APK" >&2; exit 2; fi
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK" ]]; then echo "ERROR: ANDROID_SDK_ROOT/ANDROID_HOME is not set" >&2; exit 2; fi
AAPT="$(find "$SDK/build-tools" -type f -name aapt 2>/dev/null | sort -V | tail -n 1)"
if [[ -z "$AAPT" ]]; then echo "ERROR: aapt not found in Android SDK build-tools" >&2; exit 2; fi
BADGING="$("$AAPT" dump badging "$APK")"
grep -Fq "package: name='com.primevoice.app'" <<<"$BADGING" || { echo "ERROR: Unexpected applicationId" >&2; exit 3; }
MANIFEST="$("$AAPT" dump xmltree "$APK" AndroidManifest.xml)"
grep -Fq 'rikka.shizuku.ShizukuProvider' <<<"$MANIFEST" || { echo "ERROR: ShizukuProvider missing from merged APK manifest" >&2; exit 4; }
grep -Fq 'com.primevoice.app.shizuku' <<<"$MANIFEST" || { echo "ERROR: Shizuku provider authority missing or incorrect" >&2; exit 5; }
grep -Fq 'android.permission.INTERACT_ACROSS_USERS_FULL' <<<"$MANIFEST" || { echo "ERROR: Shizuku cross-user service permission missing from merged manifest" >&2; exit 6; }
grep -Fq 'com.primevoice.app.ShizukuAudioUserService' <<<"$MANIFEST" || { echo "ERROR: Audio UserService missing from merged manifest" >&2; exit 7; }
grep -A 6 -F 'com.primevoice.app.ShizukuAudioUserService' <<<"$MANIFEST" | grep -Fq 'android.permission.INTERACT_ACROSS_USERS_FULL' || { echo "ERROR: Audio UserService permission missing from merged manifest" >&2; exit 8; }
grep -A 6 -F 'com.primevoice.app.CaptureTestUserService' <<<"$MANIFEST" | grep -Fq 'android.permission.INTERACT_ACROSS_USERS_FULL' || { echo "ERROR: Capture Test UserService permission missing from merged manifest" >&2; exit 9; }
python3 - "$APK" <<'PY2'
import sys, zipfile
apk=sys.argv[1]
required={"Shizuku Provider":b"Lrikka/shizuku/ShizukuProvider;", "Prime Voice Activity":b"Lcom/primevoice/app/MainActivity;", "Floating Menu Service":b"Lcom/primevoice/app/FloatingMenuService;", "Shizuku Audio UserService":b"Lcom/primevoice/app/ShizukuAudioUserService;", "Shizuku AIDL bridge":b"Lcom/primevoice/app/IShizukuAudioBridge;", "Capture Test UserService":b"Lcom/primevoice/app/CaptureTestUserService;", "Capture Test bridge":b"Lcom/primevoice/app/ICaptureTestBridge;"}
with zipfile.ZipFile(apk) as z:
    dex_names=sorted(n for n in z.namelist() if n.startswith("classes") and n.endswith(".dex"))
    if not dex_names: raise SystemExit("ERROR: APK contains no DEX files")
    dex=b"".join(z.read(n) for n in dex_names)
    missing=[name for name,marker in required.items() if marker not in dex]
    if missing: raise SystemExit("ERROR: Missing DEX class(es): "+", ".join(missing))
    print("DEX verification PASS:")
    for name in required: print(" - "+name)
PY2
echo "STATIC APK PACKAGE CHECK PASS: package, merged Shizuku provider, protected UserServices and required DEX class markers are present."
echo "NOTE: This check does not prove Shizuku startup, AudioPolicy registration, PCM delivery, or game/call reception."
