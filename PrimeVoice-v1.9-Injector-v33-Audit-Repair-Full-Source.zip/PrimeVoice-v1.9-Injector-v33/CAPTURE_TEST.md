# Capture Test — Prime Voice v1.9 (separate test only)

> **সংস্করণ:** Capture Test **v13** — versionCode **20**, versionName **"1.9 Capture Test v13"**
> (মূল v1.9 ছিল versionCode 10 / versionName "1.9"; v12 ছিল 19 / "1.9 Capture Test v12")।
> APK আর source ZIP-এর version একই। v13-এ কোনো নতুন ফিচার নেই —
> শুধু Final Audit-এ পাওয়া তিনটি নির্দিষ্ট Bug ঠিক করা হয়েছে
> (নিচে "v13 সংশোধন" দেখুন, বিস্তারিত `V13_AUDIT_FIXES.md`-তে)।
> এই version-ই Android SDK দিয়ে build করা হয়েছে; build report
> `FINAL_BUILD_REPORT.md`-তে আছে।

## উদ্দেশ্য — একটাই প্রশ্ন

Redmi 14C-এর Android 16 / HyperOS-এ, Shizuku UserService থেকে
`AudioPolicy.registerAudioPolicy()` + `createAudioTrackSource()` দিয়ে
PCM অডিও কি আদৌ `AudioRecord(MIC)`-এ পৌঁছায়?

এই উত্তর না জেনে v1.9-এ একসঙ্গে সবকিছু (PCM Transport + Voice Pack
Integration) যোগ করলে কোথায় ব্যর্থ হচ্ছে বোঝা যাবে না। তাই আগে এই
পরীক্ষা, তারপর বাকিটা।

## কী বদলানো হয়নি — নিশ্চিত করা হলো

**অক্ষত আছে (এক লাইনও বদলানো হয়নি):**
- `FloatingMenuService.kt` — Floating Player
- `LiveAudioEngine.kt` — Live FX
- `PcmWavRecorder.kt` — Recorder
- `ShizukuAudioUserService.kt` + `IShizukuAudioBridge.aidl` — আগের diagnostics ব্রিজ
- `README.md`, `SHIZUKU_LIFECYCLE_FIX.md`, `SHIZUKU_BRIDGE_STATUS.md`
- Soundboard / Voice Pack-এর সব কোড (`MainActivity.kt`-র Live FX, Soundboard, Recorder ট্যাব)

**শুধু যোগ করা হয়েছে (নতুন ফাইল):**
- `app/src/main/java/com/primevoice/app/CaptureTestProbe.kt` — পরীক্ষার আসল কাজ
- `app/src/main/java/com/primevoice/app/CaptureTestUserService.kt` — আলাদা Shizuku UserService
- `app/src/main/java/com/primevoice/app/CaptureTestRecorder.kt` — অ্যাপের ভেতরে MIC যাচাই
- `app/src/main/aidl/com/primevoice/app/ICaptureTestBridge.aidl` — আলাদা AIDL (মাত্র ৪টি method)

**ছোট additive পরিবর্তন (আগের কোড মুছে বা বদলে নয়):**
- `AndroidManifest.xml` — শুধু `CaptureTestUserService` service entry যোগ
- `app/build.gradle.kts` — শুধু `org.lsposed.hiddenapibypass:hiddenapibypass:6.1` dependency যোগ
- `MainActivity.kt` — শুধু Settings ট্যাবে “CAPTURE TEST” section যোগ + তার state/function;
  Floating Player / Soundboard / Live FX / Recorder-এর কোনো লাইন বদলানো হয়নি

## পরীক্ষাটা কী করে

1. **Shizuku UserService থেকে AudioPolicy বানানোর চেষ্টা** (`CaptureTestUserService` + `CaptureTestProbe`)।
2. **Hidden API access ও reflection-এর প্রতিটি ধাপের আলাদা Log:**
   `[1]` HiddenApiBypass, `[2]` Class.forName দিয়ে ক্লাস খোঁজা,
   `[3]` Builder-দের constructor/method তালিকা (এই ফোনে আসলে কী আছে, আন্দাজ নয়),
   `[4a]` AudioAttributes, `[4b]` AudioMixingRule, `[4c]` AudioMix,
   `[4d]` AudioPolicy, `[4e]` registerAudioPolicy।
3. **Constructor ও role — AOSP থেকে যাচাই করা (আন্দাজ নয়):**
   - `AudioPolicy.Builder` — একমাত্র constructor `Builder(Context)`। No-arg
     constructor AOSP-তে নেই; আগের সংস্করণে এটাই [4d]-তে ব্যর্থ হতো।
     এখন service-এর Context দিয়ে বানানো হয়, সঙ্গে `setLooper(main)`।
   - `AudioMix.Builder` — public constructor শুধু `Builder(AudioMixingRule)`।
     `setMixingRule()` package-private, তাই rule constructor-এই দেওয়া হয়।
   - `AudioMixingRule.Builder.setTargetMixRole(MIX_ROLE_INJECTOR)` — rule
     যোগ করার **আগে** ডাকা হয়। Role না সেট করলে `build()` ডিফল্ট PLAYERS
     বানায়, injector হয় না। বানানো rule-এর `getTargetMixRole()` পড়ে
     যাচাই করা হয়: `1=INJECTOR, 0=PLAYERS` — না মিললে ওই preset বাতিল।
   - `ROUTE_FLAG_LOOP_BACK = 2`, `RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET = 2`,
     `RULE_MATCH_ATTRIBUTE_USAGE = 1`, `MIX_ROLE_INJECTOR = 1` — reflection
     দিয়ে পড়ে লগ করা হয়।
4. **Phase A — register পরীক্ষা, preset একে একে:** `[7 VOICE_COMMUNICATION, 1 MIC, 5 CAMCORDER, 6 VOICE_RECOGNITION, 4 VOICE_CALL]`।
   প্রতিটি preset-এর জন্য আলাদা policy বানিয়ে register করে, তারপর সঙ্গে
   সঙ্গে unregister করে — তবে শুধু register `0` ফেরত দিলেই (অর্থাৎ সত্যিই
   registered হলেই)। ০ ছাড়া অন্য সংখ্যা মানে "register হয়নি", তাই
   unregister করার কিছু নেই। এই phase-এ কোনো tone বাজে না।
   **registerAudioPolicy()-এর ফলাফল ও ৮ সেকেন্ড timeout লগ করা:**
   ফেরত `0` মানে সফল। ৮০০০ ms-এর মধ্যে উত্তর না এলে `TIMEOUT` লেখা হয়,
   তারপর worker আরও ৩০ সেকেন্ড (৫ সেকেন্ড করে) আসল ফলের জন্য অপেক্ষা করে
   — background task-কে `shutdownNow()` দিয়ে মেরে ফেলা হয় না, কারণ
   চলমান Binder/reflection call সেটা মানতে নাও পারে। দেরিতে register
   হলে (code 0) সঙ্গে সঙ্গে unregister করা হয়; ৩৮ সেকেন্ডেও উত্তর না
   এলে policy-র অবস্থা UNKNOWN ধরা হয়, run বাতিল হয়, আর ওই policy
   কখনোই না জেনে unregister করা হয় না — বদলে `LEAK WARNING` লগ হয়।
   (মনে রাখতে হবে: probe timeout ১২ সেকেন্ড আর UserService startup wait
   ৩০ সেকেন্ড — আলাদা দুটি সীমা। এই পরীক্ষায় policy register-এর timeout
   ৮ সেকেন্ড, সেটা তৃতীয়, আলাদা সীমা।)
5. **Phase B — tone ধরে রাখা:** প্রথম যে preset register হয়েছে, সেটা
   আবার বানিয়ে register করে AudioTrack source তৈরি করা হয়, আর ৮৮০ Hz
   sine tone (৪৮,০০০ Hz) **STOP TEST চাপা পর্যন্ত একটানা বাজতে থাকে**
   (সর্বোচ্চ ১২০ সেকেন্ড)। তাই CHECK MIC দেরিতে চাপলেও tone থাকবে।
6. **ফলাফল যাচাই — তিনভাবে:**
   - **Baseline (আগে):** Settings-এ `BASELINE CHECK (no tone, 10s)` —
     tone ছাড়া ১০ সেকেন্ড MIC রেকর্ড করে ৮৮০ Hz ratio **আর RMS** মাপা।
     Ratio কম হলেই চলবে না — RMS silence floor (৫০)-এর নিচে থাকলে baseline
     অর্থহীন (প্রায় কিছুই রেকর্ড হয়নি), তখন baseline ধরা হয় না, আবার
     করতে হয়। ঘর শান্ত কি না, স্পিকার থেকে কিছু লিক হচ্ছে কি না — RMS-সহ
     baseline-ই বলে দেয়।
   - **অ্যাপের ভেতরে:** `CHECK MIC (10s)` — tone চলতে থাকা অবস্থায়
     `AudioRecord(MIC)` দিয়ে ১০ সেকেন্ড রেকর্ড করে ৮৮০ Hz tone আছে কি না
     দেখে (Goertzel পরীক্ষা)। `TONE_DETECTED` হতে হলে ratio ≥ ৪.০ **এবং**
     baseline-এর অন্তত ৩ গুণ হতে হবে। ফলাফল: `TONE_DETECTED` / `NO_TONE` /
     `SILENCE` / `BASELINE ALREADY HIGH`।
   - **অন্য অ্যাপে (আসল যাচাই):** tone বাজতে থাকা অবস্থায় অন্য একটি
     recorder অ্যাপ (বা Free Fire-এর voice chat) দিয়ে রেকর্ড করে শুনুন —
     ৮৮০ Hz tone শোনা যাচ্ছে কি না। এটাই চূড়ান্ত প্রমাণ।

## চালানোর ধাপ (Redmi 14C)

1. এই প্রজেক্ট GitHub-এ তুলে Actions → **Build Prime Voice APK** চালান
   (আগের `BUILD_ON_ANDROID_PHONE.md` অনুযায়ী), `app-debug.apk` ইন্সটল করুন।
   **এই পরিবেশে (এখানে) APK বানানো বা ফোনে টেস্ট করা হয়নি।**
2. Shizuku অ্যাপ চালু করুন (Shizuku running থাকতে হবে)।
3. Prime Voice খুলে Settings ট্যাবে যান → `CHECK / REQUEST SHIZUKU` চাপুন,
   Shizuku-তে permission approve করুন।
4. একবার Live FX ট্যাবে গিয়ে Microphone permission দিন (CHECK MIC-এর জন্য লাগবে)।
5. **হেডফোন লাগান** (তারের হেডফোন/ইয়ারফোন) যাতে ফোনের স্পিকার নীরব থাকে।
   স্পিকারের আওয়াজ মাইকে গেলে ভুল TONE_DETECTED আসে — নিচের সতর্কতা দেখুন।
6. শান্ত ঘরে, tone না চালিয়ে **BASELINE CHECK (no tone, 10s)** চাপুন।
   Ratio ৪.০-এর নিচে হওয়া উচিত। বেশি হলে ঘর বদলান / হেডফোন লাগান।
7. **RUN CAPTURE TEST** চাপুন। **REFRESH LOG** চেপে চেপে লগ দেখুন —
   Phase A-তে preset একে একে register পরীক্ষা হবে, তারপর Phase B-তে tone
   একটানা বাজতে থাকবে। Test চলতে থাকলে RUN বোতাম বন্ধ (disabled) থাকে —
   আগের test সম্পূর্ণ শেষ না হওয়া পর্যন্ত নতুন RUN শুরু হবে না।
8. Tone বাজতে থাকা অবস্থায় **CHECK MIC (10s)** চাপুন, অথবা অন্য recorder
   অ্যাপে রেকর্ড করুন। Tone থামবে না — তাড়াহুড়ো করতে হবে না।
9. **STOP TEST** চাপুন। উত্তর `STOPPED` এলে worker সত্যিই শেষ হয়েছে
   (tone বন্ধ, track release, policy unregister)। `STOPPING` এলে worker
   এখনো cleanup করছে — কয়েক সেকেন্ড অপেক্ষা করে **REFRESH LOG** চাপুন,
   `state=IDLE` লাইন দেখা গেলে তবেই আবার RUN চাপুন।
10. লগে `LEAK WARNING` দেখলে ফোন **reboot** করে তারপর আবার পরীক্ষা করুন —
    UNKNOWN অবস্থার policy রেখে নতুন test চালাবেন না।

## লগ কীভাবে পড়বেন

```
[+120ms] [4e] preset 7: registerAudioPolicy() -> 0 (45ms)
[+130ms] [4f] preset 7: AudioTrack source OK, playing 880 Hz tone for 3s
```

| যা দেখবেন | অর্থ |
|---|---|
| `[2] Class NOT found: android.media.AudioPolicy` | এই ফোনে hidden ক্লাস পাওয়া যায়নি — এই পথে injection সম্ভব নয় |
| `[4b] setTargetMixRole(MIX_ROLE_INJECTOR=1) OK` | Injector role সেট হয়েছে |
| `[4b] built rule targetMixRole=1` | বানানো rule সত্যিই INJECTOR (0 হলে PLAYERS — ওই preset বাতিল) |
| `[4b] ROLE MISMATCH` | Role INJECTOR হয়নি — ওই preset দিয়ে injection হবে না |
| `[4d] AudioPolicy.Builder(Context) used` | সঠিক constructor ব্যবহার হয়েছে |
| `[4d] AudioPolicy build FAILED` | Builder-এই ব্যর্থ — Capture Test আসল AudioPolicy পর্যন্ত পৌঁছায়নি |
| `[4e] registerAudioPolicy() returned 0` | Policy register সফল |
| `[4e] registerAudioPolicy() TIMEOUT` | ৮ সেকেন্ডে উত্তর আসেনি — worker আরও ৩০ সেকেন্ড আসল ফলের জন্য অপেক্ষা করছে |
| `[4e] LATE REGISTER` | ৮ সেকেন্ডের পরে register সফল হয়েছে — policy সঙ্গে সঙ্গে unregister করা হয়েছে; এই registration usable নয় |
| `[4] REGISTER OK but LATE` | Preset দেরিতে register হয়েছে — Phase B-র candidate হিসেবে ধরা হয়নি |
| `[5] STOP came before track creation` | STOP আগেই চাপা হয়েছে — track তৈরি হয়নি, tone বাজেনি |
| `[5] STOP arrived during track creation` | তৈরি হওয়ার সময় STOP চাপা হয়েছে — তৈরি হওয়া track সঙ্গে সঙ্গে release করা হয়েছে, tone বাজেনি |
| `[4e] LEAK WARNING` | ৩৮ সেকেন্ডেও উত্তর আসেনি — policy-র অবস্থা UNKNOWN; run বাতিল হয়েছে; ফোন reboot করে আবার পরীক্ষা করুন |
| `[4e] registerAudioPolicy() returned -1` / অন্য সংখ্যা | Register ব্যর্থ (সংখ্যাটাই ফলাফল) — register হয়নি, unregister করার কিছু নেই |
| `state=IDLE` | Worker সম্পূর্ণ শেষ + cleanup সম্পন্ন — এখন নতুন RUN করা যাবে |
| `tryStart REFUSED` | আগের test এখনো শেষ হয়নি — IDLE না হওয়া পর্যন্ত নতুন RUN হবে না |
| `[5] createAudioTrackSource FAILED` | Policy register হলেও track source বানানো যায়নি |
| `[5] TONE PLAYING preset X` | Tone একটানা বাজছে — এখন CHECK MIC চাপুন |
| `MIC CHECK: TONE_DETECTED` | ৮৮০ Hz tone `AudioRecord(MIC)`-এ পৌঁছেছে **এবং** baseline-এর ৩ গুণ ছাড়িয়েছে — injection-এর ইঙ্গিত (তবে একা প্রমাণ নয়) |
| `MIC CHECK: NO_TONE` / `SILENCE` | Tone মাইকে পৌঁছায়নি — এই ফোনে এই পথে injection কাজ করছে না |
| `BASELINE ALREADY HIGH` | Tone ছাড়াই ৮৮০ Hz শক্তিশালী — ঘর শোরগোল / স্পিকার লিক; baseline ঠিক না করে ফলাফল বিশ্বাস করা যাবে না |
| `Baseline INCONCLUSIVE` | Baseline-এ প্রায় কিছুই রেকর্ড হয়নি (RMS ৫০-এর নিচে) — ratio অর্থহীন; স্বাভাবিক ঘরের পরিবেশে আবার করুন |
| `RESULT: FAIL — no preset registered` | কোনো preset-ই register হয়নি |

## ফলাফল অনুযায়ী পরের ধাপ

| ফলাফল | পরের ধাপ |
|---|---|
| TONE_DETECTED (baseline কম ছিল + অ্যাপে + অন্য অ্যাপে) | পূর্ণ PCM Transport বানানো: ক্লিপ decode → PCM → pipe/Binder → injector-এর AudioTrack। তারপর Voice Pack Integration। |
| register `0` কিন্তু tone পৌঁছায়নি | Preset / mixing rule / route flag বদলে আবার পরীক্ষা; লগের `[3]` ধাপে এই ফোনের আসল method/field দেখে সিদ্ধান্ত নেওয়া। |
| register ব্যর্থ / TIMEOUT / ক্লাস পাওয়া যায়নি | এই ফোনে (Android 16 / HyperOS) এই AudioPolicy পথ বন্ধ — অন্য পথ খুঁজতে হবে, অথবা এই ফোনে injection সম্ভব নয় বলে ধরে নিতে হবে। |

## সতর্কতা

- **TONE_DETECTED একা প্রমাণ নয় (সবচেয়ে গুরুত্বপূর্ণ):** ফোনের স্পিকার
  থেকে বের হওয়া আওয়াজ মাইক্রোফোনে ধরা পড়লেও TONE_DETECTED আসতে পারে।
  তাই শুধু এই ফল দিয়ে ডিজিটাল অডিও ইনজেকশন প্রমাণ হয় না। তিনটি শর্ত
  একসঙ্গে পূরণ হলে তবেই injection ধরা যাবে: (১) baseline ratio কম ছিল,
  (২) tone চলার সময় ratio baseline-এর অন্তত ৩ গুণ হয়েছে, (৩) অন্য একটি
  অ্যাপের রেকর্ডিংয়েও ৮৮০ Hz tone শোনা গেছে। হেডফোন ব্যবহার করলে
  স্পিকারের আওয়াজ মাইকে যাওয়ার ঝুঁকি কমে।
- UID নিয়ে আগের নিয়ম এখানেও প্রযোজ্য: `getProcessUid()` শুধু UID ফেরত
  দেয় — UID-কে শুধু UID হিসেবেই ধরতে হবে, privileged permission-এর
  প্রমাণ হিসেবে নয়।
- Hidden API + reflection Android আপডেটে ভেঙে যেতে পারে। এই test-এর
  উদ্দেশ্যই হলো এই ফোনে, এই Android সংস্করণে, আসলে কী হয় তা জানা —
  আন্দাজ করে “কাজ করছে” ধরে নেওয়া নয়।
- গেমের voice chat-এ এভাবে অডিও পাঠানো গেমের নিয়ম ভাঙতে পারে —
  টেস্টের ফলাফল পাওয়ার পর সেটা মাথায় রেখে সিদ্ধান্ত নেওয়া দরকার।

## সংশোধনের ইতিহাস (review থেকে)

- **Fix 1:** `AudioPolicy.Builder` এখন `Builder(Context)` দিয়ে বানানো হয়
  (AOSP-তে এটাই একমাত্র constructor); সঙ্গে `setLooper(main)`। আগের
  no-arg constructor ফোনে [4d]-তে ব্যর্থ হতো।
- **Fix 1b:** `AudioMix.Builder` এখন `Builder(AudioMixingRule)` দিয়ে
  বানানো হয় (একমাত্র public constructor); `setMixingRule()` আর ডাকা হয় না।
- **Fix 2:** `setTargetMixRole(MIX_ROLE_INJECTOR)` rule যোগ করার আগে
  ডাকা হয়, আর বানানো rule-এর `getTargetMixRole()` পড়ে যাচাই করা হয়।
- **Fix 3:** Phase A (register পরীক্ষা) আর Phase B (tone ধরে রাখা)
  আলাদা করা হয়েছে। সফল preset-এ tone STOP TEST পর্যন্ত একটানা বাজে
  (সর্বোচ্চ ১২০ সেকেন্ড), তাই CHECK MIC দেরিতে চাপলেও চলবে।
- **Fix 4:** BASELINE CHECK যোগ করা হয়েছে; TONE_DETECTED-এর জন্য এখন
  baseline-এর ৩ গুণ ছাড়াতে হয়; হেডফোন নির্দেশনা যোগ করা হয়েছে।

### v3 সংশোধন (দ্বিতীয় review থেকে)

- **Fix 5 — Kotlin syntax error:** `stop()`-এ লেখা `runCatching { ... } catch`
  বৈধ Kotlin নয় (runCatching একটি function call, try নয়) — পুরো প্রজেক্ট
  খুঁজে এই pattern-এর ২টি occurrence পাওয়া গেছে, দুটোই plain `try/catch`
  দিয়ে বদলানো হয়েছে। এটা না ঠিক করলে compilation ব্যর্থ হতো।
- **Fix 6 — role যাচাই কঠোর করা:** `getTargetMixRole()` থেকে `null` এলে
  (যাচাই করা যায়নি) এখন আর Mix গ্রহণ করা হয় না — সেই preset বাতিল।
  Role ১ নিশ্চিত না হলে Injector ধরে এগোনো যাবে না।

### v4 সংশোধন (তৃতীয় review থেকে)

- **Fix 9 — Registration timeout ও cleanup:** `registerWithTimeout()`-এ
  timeout হলে background task-কে `shutdownNow()` দিয়ে মারা হয় না —
  চলমান Binder/reflection call সেটা মানতে নাও পারে। বদলে worker আরও
  ৩০ সেকেন্ড (৫ সেকেন্ড করে) আসল ফলের জন্য অপেক্ষা করে। দেরিতে register
  হলে (code 0) policy সঙ্গে সঙ্গে unregister করা হয়। ৩৮ সেকেন্ডেও উত্তর
  না এলে policy-র অবস্থা UNKNOWN ধরা হয়, run বাতিল হয়, আর ওই policy
  কখনোই না জেনে unregister করা হয় না — বদলে `LEAK WARNING` লগ হয়
  (ফোন reboot করার নির্দেশসহ)। register `0` ছাড়া অন্য সংখ্যা ফেরত দিলে
  "register হয়নি" ধরা হয়, তাই unregister করার কিছু নেই।
- **Fix 10 — STOP/RUN concurrency:** state machine যোগ করা হয়েছে
  (IDLE → RUNNING → FINISHING → IDLE)। নতুন RUN শুধু IDLE অবস্থায়
  অনুমোদিত — পুরোনো worker সম্পূর্ণ শেষ + cleanup সম্পন্ন না হওয়া পর্যন্ত
  `ALREADY_RUNNING` ফেরত যায়, আর MainActivity-তে RUN বোতাম disabled
  থাকে। `stopTest()` এখন String ফেরত দেয়: `STOPPED` (worker সত্যিই শেষ)
  বা `STOPPING` (এখনো cleanup চলছে)। Cleanup idempotent (`cleanupOnce`)
  — track release + policy unregister যাচাই করে লগে লেখে, কিছু বাকি
  থাকলে `LEAK:` লাইন দেখায়।
- **Fix 11 — ভুল fallback বাদ:** `AudioPolicy.Builder(Context)` আর
  `AudioMix.Builder(AudioMixingRule)` ছাড়া আর কোনো পথ নেই — no-arg
  fallback পুরোপুরি বাদ। সঠিক constructor না পেলে ওই preset সরাসরি
  ব্যর্থ হয়, সঙ্গে ফোনে আসলে কোন constructor আছে তার বিস্তারিত লগ।
  `setTargetMixRole` না থাকলেও preset ব্যর্থ হয় (আগে শুধু warning ছিল)।
- **Fix 12 — Version:** versionCode 10 → 11, versionName "1.9" →
  "1.9 Capture Test v4" — APK আর source ZIP-এর version এখন মিলবে।

### v5 সংশোধন (শুধু একটি সমস্যা — cleanup synchronization)

- **Fix 13 — Cleanup completion synchronization:** v4-এ `cleanupOnce()`-এ
  `cleanedUp = true` করার পর lock ছেড়ে track release / policy unregister
  করা হতো। ফলে STOP-এর Binder thread cleanup শুরু করলে, worker-এর
  finally-তে দ্বিতীয় `stop()` "cleanedUp = true" দেখে ফিরে যেত, আর
  worker cleanup শেষ হওয়ার আগেই `state = IDLE` করে দিতে পারত — নতুন RUN
  শুরু হতে পারত আগের Policy cleanup শেষ হওয়ার আগেই।
  এখন "cleanup শুরু হয়েছে" আর "cleanup সম্পূর্ণ হয়েছে" — দুটি আলাদা
  অবস্থা: প্রথম caller কাজ করে আর `CountDownLatch` count down করে;
  অন্য সব caller একই latch-এর জন্য অপেক্ষা করে। `stop()` latch-এর জন্য
  অপেক্ষা করে ফেরে, আর `run()`-এর finally-তে IDLE করার আগেও আরেকবার
  অপেক্ষা করা হয়। তাই cleanup সত্যিই শেষ না হওয়া পর্যন্ত state
  FINISHING-ই থাকে, আর IDLE হওয়ার পরেই নতুন RUN অনুমোদিত হয়। একই
  Policy একাধিকবার unregister হয় না (registeredPolicies map থেকে সরিয়ে
  ফেলা হয়)। ৮ সেকেন্ড timeout + ৩০ সেকেন্ড অপেক্ষা, UNKNOWN policy-কে
  না জেনে unregister না করা, আর LEAK WARNING — সব অক্ষত আছে।
  Version: versionCode 11 → 12, versionName "1.9 Capture Test v5"।

### v6 সংশোধন (শুধু দুটি সমস্যা — STOP race + late registration)

- **Fix 14 — STOP বনাম AudioTrack creation race:** Phase B-তে STOP যাচাই,
  AudioTrack তৈরি, `currentTrack`-এ সংরক্ষণ আর tone চালুর সিদ্ধান্ত এখন
  একটাই `toneArmLock`-এর অধীনে atomic। Cleanup একই lock নিয়ে তবেই
  `currentTrack` পড়ে/খালি করে। STOP আগে এলে track তৈরি হয় না; তৈরি
  হওয়ার সময় STOP এলে তৈরি হওয়া track সঙ্গে সঙ্গে release হয়; tone
  চালুর ঠিক আগেও আরেকবার STOP যাচাই করা হয় (`playToneLoop`-এর শুরুতে)।
  Cleanup শেষ হওয়ার পরে কোনো অবস্থাতেই নতুন track তৈরি বা tone চালু হয় না।
- **Fix 15 — Late registration:** `RegisterOutcome`-এ নতুন `usable` flag
  যোগ করা হয়েছে — `true` শুধু তখনই, যখন code 0 **এবং** উত্তর ৮ সেকেন্ডের
  ভেতরে এসেছে। দেরিতে register সফল হলেও policy সঙ্গে সঙ্গে unregister
  করা হয়, তাই সেটা usable নয়: Phase A ওই preset-কে candidate ধরে না,
  Phase B ওই policy দিয়ে AudioTrack তৈরি করে না (RESULT FAIL লগ হয়)।
  Register-এর ফলাফল আর policy lifecycle এখন লগে স্পষ্টভাবে আলাদা করে
  লেখা হয় ("REGISTER OK" / "REGISTER OK but LATE" / "LATE REGISTER")।
  Version: versionCode 12 → 13, versionName "1.9 Capture Test v6"।

### v7 সংশোধন (শুধু একটি race — STOP বনাম `track.play()`)

- **Fix 16 — STOP বনাম `track.play()` atomic করা:** v6-এ `playToneLoop()`-এ
  `stopRequested` যাচাই (আগের লাইন ৯২৫) আর `track.play()` (আগের লাইন
  ৯৩৬)-এর মাঝে কোনো lock ছিল না — STOP ঠিক ওই ফাঁকে এলে tone এক
  মুহূর্তের জন্য চালু হয়ে যেতে পারত। এখন যাচাই + `play()` একটাই
  `toneArmLock`-এর ভেতরে atomic। Lock শুধু যাচাই + `play()` পর্যন্ত ধরা
  হয় (কয়েক মিলিসেকেন্ড), পুরো write loop-এর জন্য নয় — তাই STOP কখনো
  দীর্ঘ সময় আটকে থাকে না: STOP চাপলে cleanup সর্বোচ্চ একটি `play()`
  call (মিলিসেকেন্ড) শেষ হওয়ার জন্য অপেক্ষা করে, তারপর track release
  করে। Loop নিজে প্রতি chunk-এ (~৮৫ ms) `stopRequested` দেখে, আর release
  করা track-এ write করলে exception হয়ে loop থামে।
  Version: versionCode 13 → 14, versionName "1.9 Capture Test v7"।

### v8 সংশোধন (শুধু একটি race — `stop()`-এর flag write)

- **Fix 17 — STOP-এর `stopRequested` write-ও একই lock-এর ভেতরে:** v7-এ
  `stop()` ২৪০ নম্বর লাইনে `stopRequested = true` করত `toneArmLock`
  ছাড়া। তাই এই interleaving সম্ভব ছিল: worker lock নেয় → `false`
  দেখে → STOP thread flag `true` করে → worker তবুও `play()` ডাকে →
  cleanup lock-এর জন্য অপেক্ষা করে। অর্থাৎ STOP অনুরোধের পরে
  `track.play()` কল হতে পারত। এখন `stop()` flag সেট করে
  `synchronized(toneArmLock)`-এর ভেতরে (startLock ব্লকের মধ্যে) — যে
  একই lock `playToneLoop`-এর check + `play()` ধরে। তাই flag write আর
  check + play এখন একই lock দিয়ে serialize হয়: STOP আগে lock পেলে
  worker `true` দেখে `play()` ডাকে না; worker আগে lock পেলে `play()`
  শেষ হওয়ার পর STOP-এর cleanup track release করে। Lock order:
  `startLock` → `toneArmLock` → `policyLock` (আর cleanupLock →
  `toneArmLock` → `policyLock`) — কোথাও উল্টো order নেই, তাই deadlock
  নেই। Write loop কখনো `toneArmLock` ধরে না, তাই STOP loop-এর জন্য
  অপেক্ষা করে না। Version: versionCode 14 → 15, versionName
  "1.9 Capture Test v8"।

## Race scenario execution orders (v8)

Thread চিহ্ন: **W** = worker thread (probe run), **S** = STOP-এর Binder
thread (`stopTest()`), **U** = UI thread (MainActivity)। এগুলো কোড
পড়ে বের করা নির্দিষ্ট execution order — ফোনে চালিয়ে পরীক্ষা নয়
(নিচে "সত্যিকারের অবস্থা" দেখুন)। v7-এর scenario-গুলো এখনো প্রযোজ্য;
নিচে v8-এর fix-এর জন্য নতুন order-গুলো দেওয়া হলো।

### 0. v7-এর বাগ — যে interleaving এখন আর সম্ভব নয়

| ধাপ | Thread | v7-এ যা ঘটত |
|---|---|---|
| 1 | W | `toneArmLock` নেয় |
| 2 | W | `stopRequested = false` দেখে |
| 3 | S | `stopRequested = true` করে — **কোনো lock ছাড়া** |
| 4 | W | তবুও `track.play()` ডাকে |
| 5 | S | Cleanup `toneArmLock`-এর জন্য অপেক্ষা করে |

**v7-এর ফলাফল:** STOP অনুরোধের পরেও tone চালু হতো। **v8-এ ধাপ 3
আর সম্ভব নয়** — `stop()` flag সেট করে `toneArmLock`-এর ভেতরে, আর
W ধাপ 1-এ সেই lock ধরে আছে বলে S-এর flag write ধাপ 4-এর আগে ঘটতে
পারে না। নিচের order-গুলোতে শুধু দুটি সম্ভাব্য ফলই থাকে।

### 1. STOP আগে lock পেলে worker `play()` কল করতে পারবে না

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | S | STOP চাপা → `stop()` → `synchronized(startLock)` → `synchronized(toneArmLock) { stopRequested = true }` → state = FINISHING → lock ছাড়ে |
| 2 | S | `awaitCleanupDone()` → `cleanupOnce()` → `toneArmLock` নিয়ে `currentTrack` নিয়ে null করে → `track.release()` → policy unregister → latch = 0 |
| 3 | W | `playToneLoop()`-এর `synchronized(toneArmLock)` ব্লকে ঢুকে `stopRequested = true` দেখে → "stop was requested before the tone started — not playing" লগ → `play()` না ডেকেই ফেরে |

**ফলাফল:** একটুও tone বাজে না।

### 2. Worker আগে lock পেলে `play()` শেষ হওয়ার পর STOP cleanup করে track release করবে

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | `synchronized(toneArmLock)`-এর ভেতরে `stopRequested = false` দেখে `track.play()` ডাকে → সফল → lock ছাড়ে → write loop-এ ঢোকে (loop কোনো lock ধরে না) |
| 2 | S | `stop()` → `synchronized(startLock)` → `toneArmLock`-এর জন্য অপেক্ষা করে — W ব্লক ছাড়া পর্যন্ত, অর্থাৎ শুধু `play()` call-টুকু (কয়েক মিলিসেকেন্ড) |
| 3 | S | `toneArmLock` পেয়ে `stopRequested = true` করে → state = FINISHING → `cleanupOnce()` → `currentTrack` release করে → tone সঙ্গে সঙ্গে থামে → latch = 0 |
| 4 | W | Loop-এর পরের iteration-এ `stopRequested = true` দেখে (বা released track-এ write করতে গিয়ে exception পেয়ে) থামে |

**ফলাফল:** Tone শুধু `play()` থেকে cleanup-এর release পর্যন্ত বাজে (কয়েক মিলিসেকেন্ড); তারপর থামে, আর চালু হয় না (`play()` একবারই ডাকা হয়)।

### 3. STOP পুরো PCM write loop-এর জন্য অপেক্ষা করবে না

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | Write loop-এ chunk লিখছে — **কোনো lock ধরে নেই** |
| 2 | S | `stop()` → `toneArmLock` খালি থাকায় সঙ্গে সঙ্গে flag সেট করে (loop-এর জন্য অপেক্ষা নেই) → `cleanupOnce()` → `currentTrack` release করে → latch = 0 → `stop()` ফেরে |
| 3 | W | পরের chunk-এ `stopRequested = true` দেখে বা write-এ exception পেয়ে loop থেকে বেরিয়ে যায় |

**ফলাফল:** `stop()` loop শেষ হওয়ার জন্য অপেক্ষা করে না — cleanup
শেষ হয় track release + unregister-এর মধ্যেই। Service-এর
`stopTest()` এরপর worker-এর জন্য সর্বোচ্চ ৫ সেকেন্ড join করে
(STOPPED/STOPPING সিদ্ধান্তের জন্য), কিন্তু সেটা cleanup-এর অপেক্ষা
নয়।

### 4. Lock ordering একই থাকবে এবং deadlock হবে না

| Lock নেওয়ার জায়গা | Order |
|---|---|
| `stop()` (flag সেট + state বদল) | `startLock` → `toneArmLock` |
| `tryStart()` (state বদল + flag reset + latch reset) | `startLock` → `cleanupLock` / `policyLock` (toneArmLock নেয় না) |
| `cleanupOnce()` (`currentTrack` নেওয়া) | `cleanupLock` → `toneArmLock` → `policyLock` |
| Arming (track তৈরি + `currentTrack` সংরক্ষণ) | `toneArmLock` → `policyLock` |
| Play ব্লক (যাচাই + `play()`) | `toneArmLock` (শুধু এটাই) |

- কোথাও `toneArmLock` নিয়ে `startLock` নেওয়া হয় না; কোথাও
  `policyLock` নিয়ে `toneArmLock` নেওয়া হয় না; `startLock` আর
  `cleanupLock` কখনো একসঙ্গে ধরা হয় না — তাই wait-for cycle নেই।
- Latch-এর জন্য অপেক্ষা করা thread কখনো সেই thread-কে আটকায় না যে
  latch count down করে (cleanup-এর কাজ worker-এর জন্য অপেক্ষা করে না)।
- **STOP কতক্ষণ আটকে থাকতে পারে:** `toneArmLock` ধরা হয় শুধু যাচাই
  + `play()` (মিলিসেকেন্ড), flag সেট (মাইক্রোসেকেন্ড), track তৈরির
  একটা Binder call (মিলিসেকেন্ড), আর `currentTrack` নেওয়া-খালি করা
  (মাইক্রোসেকেন্ড — release/unregister lock-এর বাইরে হয়)।

### 5. Cleanup শেষ হলে পুরোনো run থেকে নতুন Track বা Tone শুরু হওয়া অসম্ভব

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | S | `stop()` → cleanup শেষ, latch = 0 |
| 2 | W | `run()`-এর finally → `stop()` (state ইতিমধ্যে FINISHING, তাই flag আবার সেট হয় না — প্রথম `stop()`-এই সেট হয়েছে) → `awaitCleanupDone()` (সঙ্গে সঙ্গে ফেরে) → state = IDLE |
| 3 | — | পুরোনো worker মৃত; `playToneLoop()` ডাকার আর কোনো পথ নেই — একমাত্র `play()` call site ওই worker-এর ভেতরেই ছিল, আর তা ইতিমধ্যে ফিরে গেছে |
| 4 | U | নতুন RUN চাপলে `tryStart()` শুধু state = IDLE দেখে তবেই অনুমোদন করে; FINISHING অবস্থায় `ALREADY_RUNNING` ফেরে, RUN বোতামও disabled থাকে |

**ফলাফল:** Cleanup-এর পরে পুরোনো run থেকে কোনো track/tone শুরু হতে
পারে না। নতুন tone শুধু নতুন, স্পষ্টভাবে শুরু করা run থেকেই আসতে
পারে — আর সেই run শুরু হওয়ার আগে `tryStart()` flag reset করে
(`stopRequested = false`)।

### v9 সংযোজন (Floating Player Auto Next + Infinite Loop — Capture Test অপরিবর্তিত)

- **Auto Next:** একটি ভয়েস শেষ হলে Completion Listener পরের ভয়েস
  চালু করে। শেষ ভয়েস শেষ হলে প্রথম ভয়েস থেকে আবার শুরু হয় (Infinite
  Loop)। Playlist-এ একটি ভয়েস থাকলেও সেটি শেষ হলে আবার বাজে।
- **Shuffle:** ⇄ বোতাম এখন Shuffle চালু/বন্ধ করে (আগে প্রতিবার চাপলে
  random ভয়েস বাজত)। চালু করলে সঙ্গে সঙ্গে একটি random ভয়েস বাজে
  (আগের মতোই); বন্ধ করলে বর্তমান ভয়েস চলতে থাকে। Auto Next Shuffle
  চালু থাকলে random ভয়েস নেয় (যেটি এইমাত্র শেষ হলো সেটি নয়, যখন
  Playlist-এ একাধিক ভয়েস আছে), বন্ধ থাকলে Playlist-এর ক্রম অনুসরণ
  করে। Manual Next / Previous আগের মতোই Playlist-এর ক্রম অনুসরণ করে।
- **Pause:** Pause করলে Auto Next হয় না; Play করলে বর্তমান ভয়েস
  থেকেই চলে।
- **Stop / Close:** Close বা Playlist চাপলে প্যানেল লুকানো থাকে — তখন
  clip শেষ হলে Auto Next হয় না, হঠাৎ নতুন ভয়েস বাজবে না।
- **Stale Listener:** প্রতিটি Player-এর নিজের generation আছে;
  Completion Listener পরিচয় (player instance) + generation — দুটোই
  মিলিয়ে তবে Auto Next করে। পুরোনো Listener নতুন Player-কে release
  বা পরিবর্তন করতে পারে না।
- বিস্তারিত আচরণ ও execution scenario:
  `FLOATING_PLAYER_AUTO_NEXT.md` দেখুন। CaptureTestProbe.kt,
  STOP synchronization, CountDownLatch, Late Registration ও Shizuku
  diagnostics — সব v8-এর মতোই অপরিবর্তিত।

### v10 সংযোজন (দুটি Voice Folder — Music playlist / Fun one-shot)

- **Music:** Playlist হিসেবে চলে — ভয়েস শেষ হলে Auto Next, শেষ ভয়েস
  শেষ হলে প্রথম থেকে আবার (Infinite Loop)। Shuffle শুধু Music-এর
  ভয়েস থেকে random নেয়।
- **Fun:** একটি ভয়েসে ক্লিক করলে শুধু সেটি বাজে; শেষ হলে Playback
  সম্পূর্ণ বন্ধ হয় — কোনো Auto Next / Loop নেই।
- **Import:** খোলা Folder-এই Import হয় (Audio / ZIP / Recording)।
  প্রতিটি Folder-এর নিজের তালিকা (`clips_music` / `clips_fun`) — একই
  নামের ফাইল দুই Folder-এ আলাদা থাকে। পুরোনো v9-এর `clips` একবার
  Music-এ migrate হয় (v9-এর আচরণ playlist + loop ছিল, যা Music-এর নিয়ম)।
- **Playback State:** Floating Player-এ `playingFolder` ধরা থাকে;
  Completion Listener Music-এ Auto Next করে, Fun-এ থামে। Folder
  বদলালে পুরোনো Listener নতুন Folder-এ Auto Play শুরু করতে পারে না
  (playerVisible guard + playingFolder যাচাই + generation/identity)।
- **ZIP Import নতুন:** v1.9/v9-এ ZIP Import ছিল না; v10-এ যোগ করা
  হয়েছে — ZIP-এর audio ফাইলগুলো খোলা Folder-এ extract হয়।
- বিস্তারিত আচরণ ও execution scenario: `VOICE_FOLDERS.md` দেখুন।
  CaptureTestProbe.kt, STOP synchronization, CountDownLatch, Late
  Registration ও Shizuku diagnostics — সব v9-এর মতোই অপরিবর্তিত।

### v11 সংশোধন (শুধু v10-এর চারটি সমস্যা)

- **Shuffle শুধু Music-এ:** Fun Player-এ Shuffle বোতাম আর নেই;
  `toggleShuffle()` ও `next(true)` Fun-এ কিছু করে না। `pickNextIndex()`
  ও Random selection শুধু `musicClips` ব্যবহার করে (আগে থেকেই তাই ছিল)।
- **Live folder sync:** শুধু একই Key রাখা যথেষ্ট নয় — এখন দুই দিকেই
  `OnSharedPreferenceChangeListener` আছে। MainActivity থেকে Folder
  বদলালে Floating Panel-এর লাইব্রেরি সঙ্গে সঙ্গে নতুন Folder দেখায়;
  Floating Panel থেকে বদলালে MainActivity-র state + তালিকা আপডেট হয়।
  Player panel চলতে থাকলে সেটি সরানো হয় না।
- **Recording folder capture:** `startRecording()`-এর সময়
  `recordingFolder` ধরা হয়; `stopRecording()` সেই Folder-এই save করে
  — চলাকালে Folder বদলালেও ভুল Folder-এ যায় না।
- **ZIP safety:** Entry সর্বোচ্চ ১০০টি, প্রতিটি ফাইল সর্বোচ্চ ৫০ MB,
  মোট সর্বোচ্চ ২০০ MB — copy করার সময়ই মাপা হয়। সীমা ভাঙলে বা ZIP
  পড়া না গেলে Import বাতিল হয় আর আংশিক extract হওয়া সব ফাইল মুছে
  ফেলা হয়। কাজ IO thread-এ হয়, UI freeze হয় না।
- বিস্তারিত আচরণ ও execution scenario: `V11_FIXES.md` দেখুন।
  CaptureTestProbe.kt, STOP synchronization, CountDownLatch, Late
  Registration ও Shizuku diagnostics — সব v10-এর মতোই অপরিবর্তিত।

### v12 সংশোধন (শুধু ZIP Safety-এর একটি ফাঁক)

- **v11-এর ফাঁক:** Non-Audio Entry-এর জন্য সরাসরি `closeEntry()`
  হতো — বাকি decompressed data যাচাই ছাড়াই পড়া হতো। Non-Audio
  Entry-তে লুকানো ZIP bomb (যেমন শূন্যে ভরা বিশাল .txt) কোনো সীমা
  ছাড়াই decompress হতো।
- **সংশোধন:** প্রতিটি Entry-র decompressed data — audio হোক বা না
  হোক — byte ধরে গোনা হয়। Non-Audio Entry boundedভাবে skip করা হয়।
  কোনো Entry ৫০ MB ছাড়ালে, সব Entry মিলিয়ে ২০০ MB ছাড়ালে, বা
  Entry সংখ্যা ১০০-এর বেশি হলে Import বাতিল হয়। বাতিলের পর
  `closeEntry()` ডাকা হয় না (সেটি বাকি data আবার যাচাই ছাড়াই পড়ত)
  — stream `.use` দিয়ে বন্ধ হয়। বাতিল হলে আংশিক extract হওয়া সব
  ফাইল মুছে ফেলা হয়। কাজ আগের মতো IO thread-এ হয়।
- বিস্তারিত ও execution scenario: `V12_ZIP_SAFETY.md` দেখুন।
  CaptureTestProbe.kt, STOP synchronization, CountDownLatch, Late
  Registration, Shizuku diagnostics, Shuffle, Folder Sync, Recording
  Folder Capture — সব v11-এর মতোই অপরিবর্তিত।

### v13 সংশোধন (Final Audit-এ পাওয়া তিনটি নির্দিষ্ট Bug — কোনো ফিচার বদলানো হয়নি)

1. **Binder death-এ Capture Test state reset হয় না (MainActivity.kt, binderDeadListener):**
   Shizuku binder মারা গেলে শুধু diagnostic bridge-এর state reset হতো;
   Capture Test-এর `testBridge`/`testConnected` মৃত binder ধরে থাকত।
   পরের RUN মৃত binder-এ call করত। এখন binder death-এ Capture Test-এর
   state-ও reset হয় — পরের RUN আবার bind করে।
2. **STOP main thread-এ ৫ সেকেন্ড পর্যন্ত আটকে থাকত (MainActivity.kt, stopCaptureTest):**
   `stopTest()` worker-কে ৫ সেকেন্ড পর্যন্ত join করে। Register wait-এর
   মাঝখানে STOP চাপলে UI ৫ সেকেন্ড freeze হতো (ANR edge)। এখন STOP-এর
   Binder call worker thread-এ চলে, ফলাফল main thread-এ post হয়।
3. **audioManager-এর visibility (CaptureTestProbe.kt):** worker thread-এ
   লেখা `audioManager` cleanupOnce() Binder thread থেকে পড়া হতো
   `@Volatile` ছাড়া — তাত্ত্বিকভাবে stale null পড়ে unregister skip
   হতে পারত। এখন `@Volatile`।
- বিস্তারিত, যাচাই ও যা ঠিক করা হয়নি (কারণসহ): `V13_AUDIT_FIXES.md`
  দেখুন। CaptureTestProbe-এর race fix, STOP synchronization,
  CountDownLatch, Late Registration, Shizuku diagnostics, Shuffle,
  Folder Sync, Recording Folder Capture — সব v12-এর মতোই অপরিবর্তিত।

### 6. Late registration কখনো Phase B-তে ব্যবহার হবে না (v6 থেকে অপরিবর্তিত)

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | Phase B: `registerWithTimeout(policy_B)` → ৮ সেকেন্ড timeout → আরও ৩০ সেকেন্ড অপেক্ষা → দেরিতে ফল code 0 |
| 2 | W | `resolvePendingRegistration` ওই policy সঙ্গে সঙ্গে unregister করে → `RegisterOutcome(code=0, usable=false)` ফেরত যায় |
| 3 | W | Phase B `if (!outcome.usable)` দেখে → "RESULT: FAIL — preset X registered LATE … no AudioTrack can be created from it" লগ → `createAudioTrackSource` না ডেকেই ফেরে |

**ফলাফল:** Unregister হয়ে যাওয়া policy দিয়ে কখনো AudioTrack তৈরি হয় না। Phase A-তেও late preset candidate ধরা হয় না।

Thread চিহ্ন: **W** = worker thread (probe run), **S** = STOP-এর Binder
thread (`stopTest()`), **U** = UI thread (MainActivity)। এগুলো কোড
পড়ে বের করা নির্দিষ্ট execution order — ফোনে চালিয়ে পরীক্ষা নয়
(নিচে "সত্যিকারের অবস্থা" দেখুন)।

### 1. STOP আগে এলে কোনো Tone শুরু হবে না

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | Phase B arming শেষ — `currentTrack` সেট, `playToneLoop()` ডাকতে যাচ্ছে |
| 2 | S | STOP চাপা → `stop()` → `stopRequested = true` → state = FINISHING → `cleanupOnce()` (starter) → `toneArmLock` নিয়ে `currentTrack` নিয়ে null করে → `track.release()` → policy unregister → latch = 0 |
| 3 | W | `playToneLoop()`-এর `synchronized(toneArmLock)` ব্লকে ঢুকে `stopRequested = true` দেখে → "stop was requested before the tone started — not playing" লগ → `play()` না ডেকেই ফেরে |

**ফলাফল:** একটুও tone বাজে না। STOP আরও আগে এলে (arming-এর আগে) arming-ই track তৈরি করে না।

### 2. Tone শুরু হওয়ার সময় STOP এলে cleanup Track release করবে

**2a — W আগে `play()` ব্লকে ঢুকেছে:**
| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | `synchronized(toneArmLock)`-এর ভেতরে `stopRequested = false` দেখে `track.play()` ডাকে → সফল → lock ছাড়ে |
| 2 | S | `stop()` → `stopRequested = true` → `cleanupOnce()` → `toneArmLock` নিয়ে `currentTrack` release করে → tone সঙ্গে সঙ্গে থামে |
| 3 | W | Loop-এর পরের iteration-এ `stopRequested = true` দেখে (বা released track-এ write করতে গিয়ে exception পেয়ে) থামে |

**ফলাফল:** Tone শুধু `play()` থেকে cleanup-এর release পর্যন্ত বাজে (কয়েক মিলিসেকেন্ড); তারপর থামে, আর চালু হয় না (`play()` একবারই ডাকা হয়)।

**2b — S আগে cleanup শেষ করেছে:**
| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | S | `stopRequested = true`; cleanup `currentTrack` release করে, latch = 0 |
| 2 | W | play ব্লকে `stopRequested = true` দেখে → `play()` ডাকে না |

**ফলাফল:** কোনো tone বাজে না (scenario 1-এর মতোই)।

**2c — একই মুহূর্তে (STOP চাপা হয়েছে W ব্লকের ভেতরে থাকতে):**
W ইতিমধ্যে যাচাই পেরিয়ে গেছে, তাই `play()` হয়; S-এর cleanup `toneArmLock`-এর জন্য কয়েক মিলিসেকেন্ড অপেক্ষা করে, তারপর track release করে।
**ফলাফল:** 2a-এর মতো — tone শুরু হয়, তারপর সঙ্গে সঙ্গে থামে। Order কঠোর: হয় play সম্পূর্ণ হয় cleanup-এর release-এর আগে, নয়তো cleanup-এর release সম্পূর্ণ হয় play-এর সিদ্ধান্তের আগে — মাঝামাঝি কোনো interleaving নেই, কারণ যাচাই + `play()` একই lock-এর ভেতরে।

### 3. Cleanup সম্পন্ন হওয়ার পরে নতুন Track বা Tone শুরু হবে না

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | S | `stop()` → cleanup শেষ, latch = 0 |
| 2 | W | `run()`-এর finally → `stop()` → `awaitCleanupDone()` (সঙ্গে সঙ্গে ফেরে) → state = IDLE |
| 3 | U | RUN চাপলে `tryStart()` শুধু state = IDLE দেখে তবেই নতুন run অনুমোদন করে; FINISHING অবস্থায় `ALREADY_RUNNING` ফেরে, RUN বোতামও disabled থাকে |

**ফলাফল:** পুরোনো run-এর কোনো track/tone আর শুরু হতে পারে না — পুরোনো worker মৃত, `currentTrack` null, track released। নতুন tone শুধু নতুন, স্পষ্টভাবে শুরু করা run থেকেই আসতে পারে।

### 4. Lock ordering সর্বত্র একই থাকবে এবং deadlock হবে না

| Lock নেওয়ার জায়গা | Order |
|---|---|
| Arming (track তৈরি + `currentTrack` সংরক্ষণ) | `toneArmLock` → `policyLock` |
| Play ব্লক (যাচাই + `play()`) | `toneArmLock` (শুধু এটাই) |
| `cleanupOnce()` (`currentTrack` নেওয়া) | `cleanupLock` → `toneArmLock` → `policyLock` |
| `stop()` (state বদল) | `startLock` — তারপর lock ছাড়াই latch-এর জন্য অপেক্ষা |

- কোথাও `policyLock` নিয়ে `toneArmLock` নেওয়া হয় না; কোথাও `startLock` ধরে অন্য lock নেওয়া হয় না — তাই wait-for cycle নেই।
- Latch-এর জন্য অপেক্ষা করা thread কখনো সেই thread-কে আটকায় না যে latch count down করে (cleanup-এর কাজ worker-এর জন্য অপেক্ষা করে না)।
- **STOP কতক্ষণ আটকে থাকতে পারে:** `toneArmLock` ধরা হয় শুধু যাচাই + `play()` (মিলিসেকেন্ড), track তৈরির একটা Binder call (মিলিসেকেন্ড), আর `currentTrack` নেওয়া-খালি করা (মাইক্রোসেকেন্ড — release/lock-এর বাইরে হয়)। Write loop কখনো এই lock ধরে না। তাই STOP সর্বোচ্চ কয়েক মিলিসেকেন্ড অপেক্ষা করে।

### 5. Late registration কখনো Phase B-তে ব্যবহার হবে না

| ধাপ | Thread | যা ঘটে |
|---|---|---|
| 1 | W | Phase B: `registerWithTimeout(policy_B)` → ৮ সেকেন্ড timeout → আরও ৩০ সেকেন্ড অপেক্ষা → দেরিতে ফল code 0 |
| 2 | W | `resolvePendingRegistration` ওই policy সঙ্গে সঙ্গে unregister করে → `RegisterOutcome(code=0, usable=false)` ফেরত যায় |
| 3 | W | Phase B `if (!outcome.usable)` দেখে → "RESULT: FAIL — preset X registered LATE … no AudioTrack can be created from it" লগ → `createAudioTrackSource` না ডেকেই ফেরে |

**ফলাফল:** Unregister হয়ে যাওয়া policy দিয়ে কখনো AudioTrack তৈরি হয় না। Phase A-তেও late preset candidate ধরা হয় না ("REGISTER OK but LATE" লগ হয়, `lateCount++`) — সব preset late হলে "no USABLE preset registered" ফল আসে।
- **Fix 7 — baseline-এ RMS যাচাই:** baseline recording-এ RMS silence
  floor (৫০)-এর নিচে থাকলে baseline ধরা হয় না (ratio অর্থহীন), আবার
  করতে হয়। শুধু ratio দেখে পরিবেশ নিরাপদ বলা হয় না।
- **Fix 8 — tone/policy lifecycle:** Phase B-তে প্রতিটি ধীর ধাপের
  (build / register / track তৈরি) পরে `stopRequested` যাচাই করা হয় —
  STOP TEST চাপলে কোনো অবস্থাতেই tone চালু থাকবে না বা policy
  registered থাকবে না। `run()`-এর finally-তে `stop()` আছেই, আর tone-এর
  সর্বোচ্চ ১২০ সেকেন্ডের safety limit আছে — অ্যাপ বন্ধ হয়ে গেলেও tone
  চিরকাল বাজবে না।
