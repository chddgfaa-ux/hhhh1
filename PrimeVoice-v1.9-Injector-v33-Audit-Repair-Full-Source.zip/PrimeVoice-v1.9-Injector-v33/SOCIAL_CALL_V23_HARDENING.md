# Prime Voice v1.9 Injector v23 — Social Call hardening

## Changes from v22

1. **Privileged-side call-mode gate**: `ShizukuAudioUserService` independently checks `AudioManager.MODE_IN_COMMUNICATION` before registering the Social Call AudioPolicy. The app-side check is no longer the only gate.
2. **Post-registration recheck**: the service checks the mode again immediately after policy/track creation. If the call ended during setup, it unregisters the policy and rejects the session.
3. **Pipe-start gate**: a Social Call PCM pipe cannot start if Android is no longer in `MODE_IN_COMMUNICATION`.
4. **Write-time gate**: the privileged PCM pipe worker checks the communication mode before writing each received PCM block and refuses further writes after call mode ends.
5. **Pipe health gate**: `getPipeStatus()` reports `SOCIAL_CALL_MODE_ENDED` and closes the pipe input if the global communication mode has ended.
6. **Master-switch enforcement**: the decoder checks the persisted Social Call switch while streaming. Turning Social Call OFF stops an active Social Call stream; the floating-panel switch also requests stop immediately.
7. **Diagnostics**: Shizuku diagnostics now include the observed audio mode and whether a Social Call-only policy is active.

## Important limitations

- `MODE_IN_COMMUNICATION` is a **global Android audio mode**, not proof that WhatsApp, Messenger, or IMO is the foreground/call owner. This profile may be active during another VoIP app that uses the same mode.
- This code does not guarantee that any particular call app consumes the injected capture route. Each app must be tested with a remote participant.
- SIM/telephony calls (`MODE_IN_CALL`) remain unsupported. No attempt is made to bypass telephony privacy/security restrictions.
- The route uses capture preset `VOICE_COMMUNICATION` only; it does not fall back to MIC, CAMCORDER, VOICE_RECOGNITION, or VOICE_CALL.
- These are source-level hardening changes. No Android APK build or Redmi 14C runtime test has been completed in this environment.

## Suggested validation

1. Clean Gradle build and inspect the complete build log.
2. Social Call OFF: verify no Social Call profile starts.
3. Social Call ON with no VoIP call: route must be rejected.
4. Start each supported candidate app separately (WhatsApp, Messenger, IMO); confirm whether Android reports `MODE_IN_COMMUNICATION`.
5. During playback, end the call or turn Social Call OFF; verify the PCM pipe stops and AudioPolicy unregisters.
6. Place a normal SIM call; Social Call profile must remain rejected.
7. Have the remote participant verify whether audio is actually received.
