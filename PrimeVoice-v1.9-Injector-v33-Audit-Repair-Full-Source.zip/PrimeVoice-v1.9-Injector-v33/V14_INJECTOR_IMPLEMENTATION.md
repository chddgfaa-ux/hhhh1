# Prime Voice v1.9 Injector v14 — implementation notes

## What changed from v13

- `IShizukuAudioBridge` now exposes route start/stop, PCM pipe start, and service log methods in addition to diagnostics.
- `ShizukuAudioUserService` now attempts the AudioPolicy injector route using hidden API bypass, `MIX_ROLE_INJECTOR`, a capture-preset rule, loopback route flags, `registerAudioPolicy()`, and `createAudioTrackSource()`.
- The Shizuku service accepts a `ParcelFileDescriptor` pipe and forwards received PCM16 bytes into the injector `AudioTrack`.
- `PcmClipStreamer` decodes an imported audio URI using `MediaExtractor`/`MediaCodec`, converts multichannel PCM16 to mono, and streams it through the pipe.
- The floating menu has a persistent output selector: `ME ONLY` uses the existing local MediaPlayer path; `TEAMMATES ONLY` uses the Shizuku PCM injection path.
- TEAMMATES ONLY currently exposes pause/resume, previous/next, stop, playlist, and close-panel controls. The injected player does not yet have a seek bar or elapsed-time reporting.
- Music auto-next/loop and Fun one-shot behavior are retained. ZIP import safety and folder isolation are untouched.

## Important limitations

- This is an experimental implementation based on the supplied Prime Zerox static report and the existing v13 capture-probe reflection code. It is not a copy of Prime Zerox's source code.
- AudioPolicy injector APIs are hidden and device/OEM/build dependent. A `ROUTE_READY` response only means registration and AudioTrack-source creation returned successfully; it does **not** prove Free Fire or another app is consuming the injected audio.
- The code has not been built in this environment because no Android SDK / Android Gradle Plugin installation / Gradle executable is present. It has not been installed or tested on the Redmi 14C.
- First device validation must use headphones and a second player/teammate. Test `ME ONLY` and `TEAMMATES ONLY` separately. Do not use local speaker playback as proof because acoustic pickup can create a false positive.
- The first decoder path currently requires PCM16 output from the Android decoder. If a codec returns another PCM encoding, the stream reports an explicit failure instead of silently corrupting audio.
- In TEAMMATES ONLY, seek is not implemented yet; pause/resume gates PCM writes. A later revision should add sample-accurate position tracking and seek/restart support after the basic route is verified.

## Cleanup behavior

- The injector policy is registered when a clip starts and unregistered when the clip ends or is stopped.
- The PCM read descriptor is closed on stop; the service stops and releases the AudioTrack, then unregisters the known policy.
- The pipe worker is interrupted and joined before a new route resets the stop flag, preventing an old pipe worker from writing into a newly created route.
- If `unregisterAudioPolicy()` fails, the service records the failure in its log. The platform's actual policy state remains uncertain and may require a Shizuku service restart or device reboot.
