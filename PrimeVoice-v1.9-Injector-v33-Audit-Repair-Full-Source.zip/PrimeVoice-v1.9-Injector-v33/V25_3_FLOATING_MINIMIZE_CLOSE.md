# v25.3 Floating Minimize / Close behavior

- The `-` header control removes only the expanded panel. The PV bubble remains.
- Playback continues while minimized; tapping the bubble reopens the current player/library.
- The `x` header control calls `releasePlayer()` (stopping MediaPlayer and PCM streamer), removes the bubble, and stops FloatingMenuService.
- The old player-panel close action is now labeled Minimize and uses the same non-destructive behavior.
- This is a source-only patch. Android build and on-device verification are still required.
