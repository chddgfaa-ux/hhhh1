# Prime Voice v31 — Source Audit & Compile/Lifecycle Repair

## Confirmed v30 findings
- `FloatingMenuService.kt` referenced `pcmStreamer`, `injectedStatusText`, `injectedDurationMs`, and `injectedPlaybackFailed` without declarations. Explicitly typed fields are now declared.
- `MainActivity.kt` used `Icons.Default.GraphicEq` without importing `androidx.compose.material.icons.filled.GraphicEq`. The missing import is now present.
- MainActivity diagnostics and FloatingMenuService playback used the same Shizuku UserService component and process suffix (`audio`). MainActivity disposal unbound with `remove=true`, risking removal of the service instance used by playback. Diagnostics now uses a distinct `audio_diagnostic` process suffix and UserService version 3.
- Pause/resume previously called a remote Shizuku Binder transaction from the floating UI thread. The button now uses a worker-thread wrapper and posts the result to the UI.
- Capture Test ServiceConnection now handles `onBindingDied` and `onNullBinding`.

## Clarification about UserService classes
Both `ShizukuAudioUserService` and `CaptureTestUserService` extend Android `Service` and return an `IBinder` from `onBind()`. This is the expected Android binding contract for a Shizuku UserService; the service class itself does not need to implement `IBinder`.

## Verification limits
- Full Android Gradle compilation has not been run in this environment.
- No APK has been produced or inspected.
- No Redmi 14C runtime tests have been performed.
- AudioPolicy injection, teammate reception, BOTH routing, and Social Call remain device-dependent and unverified.
