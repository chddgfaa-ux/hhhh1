# Prime Voice v25 — Log-Driven PCM Writer Stall Guard

## Basis
Reviewed the supplied `Prime_Zerox_Log.txt` and v24 source ZIP.

The Prime Zerox log contains:
- `pz-pcm-writer` samples inside `AudioPolicyInjector.startPipeSession...` with `stopClipStream()` in the sampled contention chain.
- One explicit `Long monitor contention` warning at 21:23:10.616, reporting 356 ms while `stopClipStream()` contended with the PCM writer; a Binder transaction also took 358 ms.
- Repeated SELinux denials for `pz-pcm-writer` doing `getattr` on `/data/user/0/com.primezerox.voice` while running in `u:r:shell:s0`. This is a private-app-directory access denial; the log does not establish that it caused PCM delivery failure.
- The supplied log does not contain a Prime Zerox `ROUTE_READY` marker or a direct PCM-write success/failure record. The user's external teammate test remains the evidence that TEAMMATES ONLY audio was heard.

## v25 source change
- Added an interrupt-aware PCM writer loop in `ShizukuAudioUserService`.
- Added a 750 ms fail-closed timeout when non-blocking `AudioTrack.write()` repeatedly returns zero for the current PCM chunk.
- On timeout the pipe records a writer failure and exits through its existing cleanup path, rather than spinning indefinitely.
- Interrupted writer sleep now restores the interrupt flag before exiting.
- Bumped Android versionCode to 30 and versionName to `1.9 Injector v25 PCM Writer Stall Guard`.

## Intentionally unchanged
- ME ONLY / TEAMMATES ONLY / BOTH routing design.
- Social Call gating and VOICE_COMMUNICATION preset restriction.
- Bluetooth route validation.
- Capture Test implementation and v24 cleanup hardening.
- Music/Fun folder and playback behavior.

## Verification status
- Source-level patch assertions: PASS.
- ZIP integrity: PASS.
- Android Gradle/Kotlin compilation: NOT RUN in this environment.
- Redmi 14C / Android 16 / HyperOS device test: NOT RUN.
- End-to-end teammate audio test: NOT RUN for v25.

A 750 ms timeout is a deliberate fail-closed threshold, not proof that every device's AudioTrack will behave identically. If a device legitimately stalls longer than this under load, the clip will stop with a clear pipe failure rather than hang.
