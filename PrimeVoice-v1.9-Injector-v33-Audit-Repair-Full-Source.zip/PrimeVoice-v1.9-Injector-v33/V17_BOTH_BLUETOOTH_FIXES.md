# Prime Voice v1.9 Injector v17 — BOTH Bluetooth fixes

This revision is based on the uploaded v16 source ZIP. It addresses the source-level defects identified in the v16 review.

## Changes

1. **Kotlin scope / cleanup:** `monitorTrack` and the PCM output stream are now declared in the worker scope that encloses `try/finally`, so cleanup can release the Bluetooth AudioTrack without an out-of-scope reference.
2. **Bluetooth permission:** declares `BLUETOOTH_CONNECT`; the main activity requests it on Android 12+ and the floating menu warns when BOTH is selected without it. The streamer fails with an explicit permission message rather than silently falling back.
3. **Bluetooth route safety:** BOTH still requires a connected A2DP device, explicitly selects it as the preferred output, waits for route confirmation, and aborts if the routed device is not A2DP. No speaker fallback is implemented.
4. **Pause / Resume:** pauses/resumes the Bluetooth AudioTrack as well as suspending PCM submission. A seek while paused keeps the monitor track paused.
5. **Seek queue synchronization:** seek flushes the Bluetooth AudioTrack and tears down/recreates the Shizuku AudioPolicy route and PCM pipe before decoding from the requested position. This discards stale queued PCM on the virtual-mic path instead of leaving the old pipe active.
6. **Version:** versionCode 23, versionName `1.9 Injector v17 BOTH Fix`.

## Verification status

- ZIP integrity: checked after packaging.
- Source-level checks: checked for the previous out-of-scope monitorTrack reference, permission declaration/request path, and route/pipe recreation on seek.
- Android Gradle build: **not run**. This environment has no Android SDK / Gradle installation.
- Runtime: **not tested** on Redmi 14C / Android 16, Bluetooth A2DP, Shizuku, or Free Fire. A2DP + AudioPolicy concurrency and actual teammate reception remain device-dependent and must be tested on the phone.

This source ZIP must not be described as a compiled or runtime-verified APK.
