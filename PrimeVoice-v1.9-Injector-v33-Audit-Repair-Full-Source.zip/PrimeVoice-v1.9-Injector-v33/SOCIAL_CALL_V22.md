# Social Call v22 — experimental Internet-call profile

## UI
- Persistent `social_call_enabled` preference.
- Switch appears in Settings and floating library panel.
- When enabled, playback requires TEAMMATES ONLY or BOTH.

## Routing
- The app checks `AudioManager.mode == MODE_IN_COMMUNICATION` before starting.
- AIDL exposes `startSocialCallRouteSession(sampleRate)`.
- Shizuku service uses only capture preset 7 (`VOICE_COMMUNICATION`) for this route. It never falls back to generic MIC / CAMCORDER / VOICE_RECOGNITION / VOICE_CALL presets.
- Decoder worker checks communication mode while streaming and stops if the mode ends.

## Important limits
- This does not identify WhatsApp, Messenger, or IMO by package name. It detects only Android's global communication mode. Other VoIP apps using that mode may also be affected.
- Even when `MODE_IN_COMMUNICATION` is active, the call app may use a different capture path or Android/OEM policy may deny injection. No per-app guarantee is possible from this source alone.
- SIM calls use telephony mode and protected uplink paths; not supported without system/telephony privilege.
- This is source-level experimental code. No APK build or device test has been completed.

## Test plan
1. Build and install on Redmi 14C Android 16 with Shizuku.
2. Verify Social Call OFF leaves normal Game output behavior unchanged.
3. For each WhatsApp, Messenger, and IMO call separately, confirm Android enters `MODE_IN_COMMUNICATION`; try TEAMMATES ONLY and BOTH.
4. Ask the remote participant to confirm receipt; check local Bluetooth monitor in BOTH.
5. End the call during playback and verify the streamer stops.
6. Confirm SIM call does not activate the Social Call profile.
