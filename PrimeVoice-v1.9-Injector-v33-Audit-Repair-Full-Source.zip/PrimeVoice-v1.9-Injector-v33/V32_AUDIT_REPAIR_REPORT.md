# Prime Voice v32 — Audit Repair Report

Date: 2026-11-28

## Applied changes
- Bumped app versionCode to 39 and versionName to 1.9 Injector v32 Audit Repair.
- Kept the existing declarations for pcmStreamer, injectedStatusText, injectedDurationMs and injectedPlaybackFailed; they are already present in the supplied v31 FloatingMenuService.
- Kept the GraphicEq import; it is already present in the supplied v31 MainActivity.
- Added explicit destroy() methods to both AIDL contracts and implemented cleanup entry points in both UserServices.
- Added an API-level guard for the AudioPolicy injector path, which the source itself documents as requiring Android API 33+; older devices now get a clear unsupported result instead of attempting hidden APIs.
- Aligned both audio UserService version values to 4.
- Bounded automatic reconnect attempts to five in the diagnostic and floating audio connection paths, avoiding an endless retry loop.
- Extended APK DEX verification to require the Capture Test UserService and bridge classes.
- Updated CI artifact name to Prime-Voice-v32-debug-apk.

## Corrections to the supplied v30 audit
- R1 is not supported by the supplied v31 source: both Shizuku UserService classes extend android.app.Service and return an IBinder from onBind(). This is the normal Shizuku UserService component pattern; the class itself is not expected to extend IBinder.
- R2 is not supported as written: Android Service inherits ContextWrapper and receives its base Context before onCreate()/onBind(); getSystemService() is valid after attachment. CaptureTestProbe is passed a Context explicitly.
- C1 and C2 are already fixed in the supplied v31 source: the four FloatingMenuService fields are declared, and GraphicEq is imported.

## Not yet fixed / requires additional review
- R5 floating panel scroll/height constraints.
- R9 foreground-service policy and Android 14+ foreground service type/permission requirements.
- R12 PcmClipStreamer controlLock and blocking I/O design.
- B2 recorder error-path/thread cleanup needs device/compiler testing.
- B3 ZIP import rotation/orphan handling.
- B6 MainActivity MediaPlayer.prepare() should be moved off the main thread.
- S3 stable release signing requires user-managed keystore secrets; CI currently produces a debug APK.
- S4 GitHub Actions third-party actions are tag-pinned, not immutable commit-SHA pinned.
- S5 APK verification is improved but remains a static marker check, not proof of runtime operation.
- Other low-priority findings (R8, R10-R13, S1-S2, S6-S7, B1, B4-B5, B7) are not all resolved by this update.

## Validation performed
- ZIP integrity, XML parse, source-level marker checks, and shell syntax checks.
- No Android Gradle build was run in this environment (no Gradle executable and no Gradle wrapper in the project).
- No APK was produced or DEX inspected.
- No Redmi 14C / Shizuku / game / call runtime test was performed.

This is a source-level repair package, not a verified working APK.
