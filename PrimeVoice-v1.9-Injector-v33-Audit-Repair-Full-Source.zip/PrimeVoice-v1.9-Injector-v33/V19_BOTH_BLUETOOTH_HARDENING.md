# Prime Voice v1.9 Injector v19 — BOTH Bluetooth hardening

## Fixes applied over v18

1. **Mute-before-route confirmation:** the Bluetooth AudioTrack starts at volume 0 while Android negotiates the selected A2DP route. PCM is not sent until `routedDevice` matches the selected A2DP device ID. The track is unmuted only after confirmation.
2. **Seek route revalidation:** seek mutes and flushes Bluetooth output, silently re-establishes/validates the A2DP route, restores the previous paused/playing state, then recreates the Shizuku PCM pipe and route.
3. **Fail-closed dual pause/resume:** remote Shizuku pause/resume responses are checked. If either destination cannot transition, both outputs are stopped rather than continuing out of sync.
4. **Frame-level synchronization:** one control lock serializes each PCM frame across Bluetooth and Shizuku. Pause/Resume cannot split a frame between sinks; Seek is serialized against a frame commit.
5. **Cancellable Bluetooth writes:** Bluetooth uses non-blocking writes with route validation and stop/seek checks between chunks.
6. **Disconnect/route-change handling:** selected A2DP removal or a route change stops both destinations and mutes local output.
7. **Version:** versionCode 25, versionName `1.9 Injector v19 BOTH Hardened`.

## Remaining limitations / required verification

- `AudioTrack.setPreferredDevice()` is a preferred route, not a universal hardware-level routing lock. The track is muted while routing is negotiated and playback fails closed if the route is not the selected A2DP device, but OEM audio-policy behavior must be physically tested on the Redmi 14C.
- A2DP devices are supported by this implementation; BLE-only audio devices are not guaranteed.
- The Android project has no Gradle wrapper in this ZIP and this environment has no Android SDK/Gradle installation. No APK compilation is claimed.
- Runtime checks still required: Clean Build; install on Redmi 14C / Android 16; Bluetooth A2DP + Shizuku + Free Fire simultaneous output; disconnect and device-switch tests; pause/resume; seek while playing and paused; Stop/Next/Previous; Music/Fun regression tests.

## Static checks performed for v19

- Confirmed versionCode/versionName updated.
- Confirmed PCM dual-output writes are serialized under the control lock.
- Confirmed Shizuku pause/resume responses are checked and failures stop both outputs.
- Confirmed Bluetooth is muted before route confirmation and route is validated before PCM writes.
- Confirmed seek revalidates Bluetooth route and recreates the remote PCM pipe.
- Confirmed disconnect and route-change callbacks invoke fail-closed cleanup.
- ZIP integrity is checked separately after packaging.
