# v13 — Final Audit Fixes (v12 base, no feature changed)

> **সংস্করণ:** v13 — versionCode **20**, versionName **"1.9 Capture Test v13"**
> (v12 ছিল versionCode 19 / "1.9 Capture Test v12")।
> এই version-ই Android SDK দিয়ে build করা হয়েছে — build report
> `FINAL_BUILD_REPORT.md`-তে আছে।

## Audit-এর পরিধি

সব ফাইল পড়া হয়েছে: ৯টি Kotlin ফাইল (২,৯১১ লাইন), ২টি AIDL,
`AndroidManifest.xml`, root + app `build.gradle.kts`,
`settings.gradle.kts`, `gradle.properties`, GitHub Actions workflow।
খোঁজা হয়েছে: compilation error, runtime crash, Null Pointer,
threading, lifecycle, Shizuku bind/unbind/permission/binder-death,
STOP বনাম AudioTrack race, ZIP সীমা ও partial cleanup।

## ঠিক করা হয়েছে — ৬টি নির্দিষ্ট Bug

> প্রথম ৩টি static audit-এ পাওয়া; পরের ৩টি আসল build চালিয়ে পাওয়া
> (v12-এর মূল source-এ আগে কেউ compile করেনি বলে এগুলো ধরা পড়েনি)।
> কোনোটিই ফিচার বদলায় না — শুধু build-এ বাধা দেওয়া ত্রুটি ঠিক করা হয়েছে।

### ১. Binder death-এ Capture Test state reset হয় না
- **ফাইল:** `app/src/main/java/com/primevoice/app/MainActivity.kt`,
  `binderDeadListener` (~লাইন ২৮৯)
- **সমস্যা:** Shizuku binder মারা গেলে শুধু diagnostic bridge-এর
  state (`bridgeConnected`/`bridgeBindRequested`) reset হতো। Capture
  Test-এর `testBridge`, `testConnected`, `testBindRequested` মৃত
  binder ধরে থাকত — পরের RUN মৃত binder-এ call করত, `runCatching`
  null ফেরত দিত, status হতো "Capture Test null"।
- **সংশোধন:** binder-death listener এখন Capture Test-এর state-ও
  reset করে (`testBridge = null`, `testConnected = false`,
  `testBindRequested = false`, status আপডেট) — পরের RUN আবার bind করে।

### ২. STOP main thread-এ ৫ সেকেন্ড পর্যন্ত আটকে থাকত
- **ফাইল:** `app/src/main/java/com/primevoice/app/MainActivity.kt`,
  `stopCaptureTest()` (~লাইন ১৯৩)
- **সমস্যা:** `stopTest()` worker thread-কে ৫ সেকেন্ড পর্যন্ত join
  করে। Register wait-এর (সর্বোচ্চ ৩৮ সেকেন্ড) মাঝখানে STOP চাপলে
  main thread ৫ সেকেন্ড block হতো — ANR threshold-এর ঠিক ধারে।
- **সংশোধন:** Binder `stopTest()` এখন worker thread-এ চলে
  (`kotlin.concurrent.thread`), ফলাফল `Handler(Looper.getMainLooper())`
  দিয়ে main thread-এ post হয়। STOP বোতামের আচরণ একই থাকে।

### ৩. audioManager-এর visibility
- **ফাইল:** `app/src/main/java/com/primevoice/app/CaptureTestProbe.kt`
  (~লাইন ১৮৫)
- **সমস্যা:** worker thread-এ লেখা `audioManager` cleanupOnce() থেকে
  (STOP-এর Binder thread) `@Volatile` ছাড়া পড়া হতো। তাত্ত্বিকভাবে
  stale null পড়ে unregister skip হয়ে false LEAK report হতে পারত।
- **সংশোধন:** এক শব্দ — `@Volatile` যোগ করা হয়েছে।

### ৪. AIDL task তৈরি হতো না — Stub generate হতো না
- **ফাইল:** `app/build.gradle.kts`, `buildFeatures` ব্লক
- **সমস্যা:** `src/main/aidl/`-এ দুটি AIDL ফাইল থাকা সত্ত্বেও AGP
  8.7.3 `:app:compileDebugAidl` task তৈরি করত না
  ("Task 'compileDebugAidl' not found")। ফলে
  `IShizukuAudioBridge.Stub` ও `ICaptureTestBridge.Stub` generate
  হতো না, Kotlin compilation ব্যর্থ হতো "unresolved reference"
  দিয়ে — MainActivity, CaptureTestUserService ও
  ShizukuAudioUserService-এর সব AIDL reference ভেঙে যেত।
- **সংশোধন:** `buildFeatures { compose = true; aidl = true }` —
  AIDL feature স্পষ্টভাবে চালু করা হয়েছে। AIDL ফাইলগুলো
  অপরিবর্তিত আছে; শুধু task তৈরি হয় এখন।

### ৫. collection-ktx:1.2.0 ও collection-jvm:1.4.4-এর duplicate class
- **ফাইল:** `app/build.gradle.kts`, `configurations.all` ব্লক
- **সমস্যা:** `ui-unit-android:1.7.6` (ui ও ui-tooling দুই দিক
  থেকেই আসে) `collection-ktx:1.2.0` টানে; `runtime-android:1.7.6`
  `collection:1.4.4` হয়ে `collection-jvm:1.4.4` টানে। দুটি jar-এই
  `ArrayMapKt`/`ArraySetKt`/`LongSparseArrayKt` আছে —
  `:app:checkDebugDuplicateClasses` ব্যর্থ হতো। compose-bom
  collection manage করে না, তাই কোনো alignment হয় না। একটি
  dependency-তে exclude দিলে হয় না — ui-tooling (debug) দিয়েও
  একই jar আসে।
- **সংশোধন:** সব configuration থেকে `collection-ktx` exclude করা
  হয়েছে। -ktx-এর API 1.4.0 থেকে collection-এর ভেতরেই আছে, আর
  collection-ktx:1.4.4 একটি খালি jar (শুধু manifest, ২৬১ byte) —
  তাই কোনো API হারায় না। App-এর নিজের কোড
  `androidx.collection` import-ই করে না (grep করে যাচাই করা)।

### ৬. KMP metadata ফাইলের duplicate resource
- **ফাইল:** `app/build.gradle.kts`, `android { packaging { ... } }`
- **সমস্যা:** Kotlin-multiplatform jar-গুলো (`lifecycle-common:2.8.3`,
  `annotation:1.8.1`, `collection:1.4.0`) একই metadata ফাইল
  byte-identical ভাবে ship করে — `commonMain/` ও `nonJvmMain/`
  linkdata (`0_androidx.knm`, `module`, `manifest`) এবং
  `META-INF/kotlin-project-structure-metadata.json`। ফলে
  `:app:mergeDebugJavaResource` ব্যর্থ হতো, একটা করে ফাইল ধরে।
- **সংশোধন:** packaging-এ `commonMain/**`, `nonJvmMain/**` ও
  `META-INF/kotlin-project-structure-metadata.json` exclude করা
  হয়েছে। এগুলো শুধু Kotlin/Native metadata — Android JVM app
  কখনো পড়ে না (JVM class-গুলো jar-এর root-এ থাকে)।

## পরীক্ষা করা হয়েছে, ঠিক আছে বলে পাওয়া গেছে — বদলানো হয়নি

- **STOP বনাম AudioTrack race (v6–v8):** `stopRequested` write
  `toneArmLock`-এর মধ্যে (stop), check + `track.play()` একই lock-এ
  (playToneLoop), arming এক atomic step-এ (Phase B), cleanup-এ
  take-and-null একই lock-এ। Lock order সর্বত্র
  startLock → toneArmLock → policyLock; কোথাও উল্টো order নেই —
  deadlock-এর পথ নেই।
- **Cleanup synchronization (v5):** `cleanupStarted` বনাম `cleanupDone`
  latch আলাদা; IDLE শুধু worker-এর finally-তে, দ্বিতীয় wait-এর পরে।
- **Late registration (v6):** `usable` শুধু code == 0 ও ৮ সেকেন্ডের
  মধ্যে এলে true; late success সঙ্গে সঙ্গে unregister হয়, Phase B-তে
  ব্যবহার হয় না।
- **ZIP সীমা (v11–v12):** ১০০ entry / ৫০ MB প্রতি entry / ২০০ MB
  মোট — audio ও non-audio দুই শাখাতেই copy করার সময় মাপা হয়;
  abort-এর পর `closeEntry()` ডাকা হয় না; abort হলে আংশিক ফাইল মুছে
  ফেলা হয়; কাজ IO thread-এ হয়।
- **Music/Fun logic (v9–v11):** completion listener ধরা folder দেখে
  শাখা নেয় (Music → autoNext, Fun → stop); `pickNextIndex()` শুধু
  `musicClips` ব্যবহার করে; Shuffle বোতাম শুধু Music player-এ;
  `toggleShuffle()`/`next(true)` Fun-এ কিছু করে না; folder sync দুই
  দিকে listener দিয়ে live; `recordingFolder` start-এ ধরা হয়।
- **Shizuku bind/unbind:** bind-এ duplicate guard আছে; দুটি
  `DisposableEffect`-এ unbind হয় (test service ও diagnostic bridge);
  permission-result ও binder-received/dead listener register/unregister
  হয়। AIDL method-গুলো service-এ implement করা আছে।
- **Manifest:** সব component-এ `android:exported` সেট আছে (targetSdk
  ৩৫-এর জন্য বাধ্যতামূলক); UserService দুটি exported=true (Shizuku-র
  জন্য দরকার); RECORD_AUDIO ও SYSTEM_ALERT_WINDOW permission আছে।

## পাওয়া গেছে কিন্তু ঠিক করা হয়নি — কারণসহ

- **LiveAudioEngine.start() double-start race (তাত্ত্বিক):** `running`
  worker thread-এর ভেতরে true হয়। কিন্তু UI থেকে দুবার start করা
  যায় না — বোতামের handler main thread-এ synchronous (`liveOn`
  একই handler-এ true হয়)। Reachable failure নেই, তাই মূল v1.9
  ফাইল বদলানো হয়নি।
- **PcmWavRecorder stop() join timeout (তাত্ত্বিক):** header লেখা
  loop শেষে হয়; `recorder.stop()` read-কে সঙ্গে সঙ্গে unblock করে,
  তাই ১৫০০ ms join বাস্তবে যথেষ্ট। Reachable failure নেই।
- **playClip-এ setDataSource ব্যর্থ হলে নতুন MediaPlayer instance-টি
  release ছাড়া পড়ে থাকে:** `release()` দুবার ডাকা safe, আর
  instance-টি GC-তে যায়। Crash নয়; বদলানো হয়নি।
- **Floating service foreground নয়:** v1.9-এর ডিজাইন — activity থেকে
  start হয় (foreground), START_STICKY। ব্যাকগ্রাউন্ডে সিস্টেম চাপে
  kill করতে পারে, কিন্তু এটা crash নয়; ফিচার বদলানো হয়নি।

## সত্যিকারের অবস্থা

- Kotlin compilation ও APK build: এই environment-এ Android SDK
  বসিয়ে আসল build চালানো হয়েছে — **BUILD SUCCESSFUL** (৪৭ সেকেন্ড),
  APK যাচাই করা হয়েছে (`FINAL_BUILD_REPORT.md`-তে বিস্তারিত)।
  উপরের ৪–৬ নম্বর fix ছাড়া build সফল হতো না — এগুলো আসল
  compilation error, অনুমান নয়।
- Device test: এখানে কোনো ফোন নেই — Feature Regression, Capture
  Test ও Free Fire Teammate Audio ফোনে পরীক্ষা করা বাকি। Static
  trace-কে device result হিসেবে দেখানো হয়নি।
