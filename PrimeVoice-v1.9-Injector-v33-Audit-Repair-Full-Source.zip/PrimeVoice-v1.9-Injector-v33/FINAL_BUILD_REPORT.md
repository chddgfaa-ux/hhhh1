# Historical report notice (important)

This file is a **historical v13 report**, not a build report for v27. Its v13 APK details and PASS statuses do not verify the v27 source or a v27 APK. For v27, run the GitHub Actions workflow `.github/workflows/build-apk.yml` and inspect the resulting build logs and APK separately.

---

# Final Build Report — Prime Voice v1.9 Capture Test v13

> **সংস্করণ:** versionCode **20**, versionName **"1.9 Capture Test v13"**
> (base v12: versionCode 19 / "1.9 Capture Test v12")
> **Build ফলাফল: BUILD SUCCESSFUL** — Debug APK তৈরি ও যাচাই করা হয়েছে।

## APK

| বিষয় | মান |
|---|---|
| ফাইল | `app-debug.apk` (এই ZIP-এর বাইরে আলাদাভাবে দেওয়া হয়েছে) |
| Package | `com.primevoice.app` |
| versionCode / versionName | **20 / "1.9 Capture Test v13"** |
| minSdk / targetSdk / compileSdk | 26 / 35 / 35 |
| আকার | 16,494,928 byte (~15.7 MB) |
| SHA-256 | `59b013a36042c05b29b86a420e7898b6011099a71edc03813b10f92b931f922b` |
| Permission | RECORD_AUDIO, SYSTEM_ALERT_WINDOW |
| Dex-এ যাচাই করা class | CaptureTestProbe, MainActivity, FloatingMenuService, ShizukuAudioUserService, CaptureTestUserService, ICaptureTestBridge Stub, IShizukuAudioBridge Stub, VoiceFolders, LiveAudioEngine — সব আছে |

`aapt dump badging` দিয়ে যাচাই করা হয়েছে; `output-metadata.json`-এও
একই versionCode/versionName আছে।

## Build পরিবেশ (এই environment-এ)

- JDK: Eclipse Temurin **17.0.21.1+2** (`~/workspace/tools/jdk-17`)
- Gradle: **8.9**, Android Gradle Plugin **8.7.3**, Kotlin **2.0.21**
- Android SDK: `~/Android` — platform **android-35**, build-tools
  **34.0.0** (AGP 8.7.3-এর default; 35.0.0-ও বসানো আছে) ও **35.0.0**,
  platform-tools r37.0.3
- Build command: `:app:assembleDebug` (in-process Gradle, `--no-daemon`
  `--offline`, init script দিয়ে local Maven mirror)
- Build সময়: ৪৭ সেকেন্ড (সফল run)। Build log:
  `~/workspace/tools/gradle-build-v13-offline17.log`

## Sandbox বাধা ও workaround (সত্য কথা)

এই sandbox-এ Java process TCP socket খুলতে পারে না — sandbox
"muse: Other TCP connections is turned off" বার্তা দিয়ে Java-র
connection আটকে দেয় (curl/Python-এর network ঠিক চলে)। তাই:

1. **Gradle daemon চলে না** (daemon socket-এ Java TCP লাগে) — JVM
   সরাসরি চালিয়ে Gradle in-process চালানো হয়েছে (daemon fork নেই)।
2. **Gradle dependency download করতে পারে না** (Java TCP ব্লক) —
   সব dependency curl দিয়ে local Maven mirror-এ নামানো হয়েছে
   (`~/workspace/tools/maven-repo`, ~৫০০+ artifact) এবং init script
   (`~/.gradle/init.gradle.kts`, `-I` দিয়ে দেওয়া) + `--offline`
   দিয়ে সেখান থেকে resolve করা হয়েছে।
3. Mirror-এ **.module ফাইল রাখা হয়নি ইচ্ছা করে**: আংশিক .module
   থাকলে Gradle একই module দুই পথে resolve করে (POM artifact +
   .module variant artifact) এবং duplicate class-এ build ভাঙে।
   POM-only resolution এখানে consistent।
4. Java-র `user.home` `/root`, কিন্তু home `/home/hatch` — init
   script `-I` দিয়ে স্পষ্টভাবে দেওয়া হয়েছে, নইলে Gradle সেটা
   লোডই করত না।

এই workaround-গুলো শুধু এই environment-এর build-এর জন্য; source
ZIP-এ এগুলোর কিছু নেই — project ফাইলে কোনো mirror/init-script
reference নেই। সাধারণ PC-তে (বা GitHub Actions-এ) project-টি
স্বাভাবিকভাবে build হবে।

## Audit-এ পাওয়া fix (v13) — সংক্ষেপে

Static audit-এর ৩টি (V13_AUDIT_FIXES.md-তে বিস্তারিত):
1. Binder death-এ Capture Test state reset (MainActivity)।
2. STOP worker thread-এ (MainActivity) — main thread block নয়।
3. `audioManager` `@Volatile` (CaptureTestProbe)।

আসল build চালিয়ে পাওয়া আরও ৩টি (এগুলো ছাড়া build সফল হতো না;
v12-এর source আগে কেউ compile করেনি বলে ধরা পড়েনি):
4. **AIDL task তৈরি হতো না** — `buildFeatures { aidl = true }` যোগ
   করা হয়েছে; নইলে Stub generate হতো না।
5. **collection-ktx:1.2.0 duplicate class** — সব configuration থেকে
   exclude (এর API collection-এই আছে; app-এর কোড collection
   import করে না)।
6. **KMP metadata duplicate resource** — packaging-এ
   `commonMain/**`, `nonJvmMain/**`,
   `META-INF/kotlin-project-structure-metadata.json` exclude।

এই ৬টি ছাড়া আর কোনো ফাইল বদলানো হয়নি। v12-এর সঙ্গে diff:
বদলেছে ৪টি ফাইল (CAPTURE_TEST.md, app/build.gradle.kts,
CaptureTestProbe.kt, MainActivity.kt), নতুন ২টি
(V13_AUDIT_FIXES.md, এই রিপোর্ট), বাকি ২২টি byte-identical।
মূল v1.9-এর বদলানো ফাইল এখনো ঠিক ৪টি (আগের মতোই)।

## আসলে যে test-গুলো হয়েছে (এখানে)

| Test | ফলাফল |
|---|---|
| Source Code Audit (সব Kotlin/AIDL/Gradle/Manifest পড়া) | **PASS** — ৬টি bug পাওয়া গেছে ও ঠিক করা হয়েছে |
| Kotlin Compilation (আসল kotlinc, SDK দিয়ে) | **PASS** — সব ৯টি Kotlin ফাইল + ২টি AIDL Stub compile হয়েছে |
| APK Build (`:app:assembleDebug`) | **PASS** — BUILD SUCCESSFUL, APK যাচাই করা হয়েছে |
| SHA-256 যাচাই (v12-এর সঙ্গে + মূল v1.9-এর সঙ্গে) | **PASS** — উপরের diff অনুযায়ী |
| APK content যাচাই (aapt badging + dex class check) | **PASS** |

## ফোনে পরীক্ষা করা বাকি (এখানে করা যায়নি — ফোন নেই)

| Test | অবস্থা |
|---|---|
| Feature Regression (Music Auto Next/Loop, Fun one-shot, Shuffle Music-only, Import folder, Recording folder, Folder Sync, Play/Pause/Seek/Prev/Next/Close) | **NOT TESTED** |
| Capture Test Phase A (preset-by-preset register) — Redmi 14C, Android 16 / HyperOS | **NOT VERIFIED** |
| Capture Test Phase B (880 Hz tone + AudioTrack playback) | **NOT VERIFIED** |
| External Recorder test (অন্য app-এর AudioRecord(MIC)-এ 880 Hz tone) | **NOT TESTED** — এটা ছাড়া injection সফল বলা যাবে না |
| Free Fire Teammate Audio (TEAMMATES ONLY routing) | **NOT TESTED** |

## সতর্কতা (আগের নিয়মই বহাল)

- নিজের app-এর MIC-এ TONE_DETECTED পাওয়া গেলেই injection সফল
  বলা যাবে না — অন্য app-এর recording-এ 880 Hz tone নিশ্চিত করতে হবে।
- AudioTrack-এ tone শোনা গেলেই Free Fire-এ microphone injection
  সফল বলা যাবে না — External Recorder ও Free Fire Teammate Test
  ছাড়া এই feature VERIFIED ঘোষণা করা যাবে না।
- এই রিপোর্টে কোনো device test-কে সফল লেখা হয়নি; যা করা হয়নি তা
  উপরে NOT TESTED / NOT VERIFIED হিসেবে স্পষ্ট লেখা আছে।

## Verdict

- Source Code Audit: **PASS**
- Kotlin Compilation: **PASS**
- APK Build: **PASS**
- Feature Regression: **NOT TESTED**
- Capture Test: **NOT VERIFIED**
- Free Fire Teammate Audio: **NOT TESTED**
