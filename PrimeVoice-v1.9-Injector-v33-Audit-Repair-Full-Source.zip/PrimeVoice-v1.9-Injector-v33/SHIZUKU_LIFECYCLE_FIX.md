# Prime Voice v1.9 — Shizuku lifecycle fix

This update improves the Shizuku diagnostic bridge lifecycle.

## Changes
- Prevents duplicate UserService bind requests while a connection is active or pending.
- Handles Shizuku permission results automatically; after approval, the app attempts to bind the diagnostic service without requiring another tap.
- Listens for Shizuku binder received/dead events and updates the visible status.
- Unregisters listeners and requests UserService unbind when the Compose app screen is disposed.
- Displays CONNECTED / CONNECTING / DISCONNECTED separately from diagnostic text.
- Bumps Android version to 1.9 (versionCode 10).

## Still not implemented
This is lifecycle management for a diagnostics-only Shizuku service. It does not implement AudioPolicy injection, a PCM transport into an AudioMix, or a verified route into Free Fire's microphone. A successful Shizuku bind does not establish those capabilities.

## Validation
Source-level checks only. This environment has no Android SDK/Gradle installation available for a real APK build, and no Redmi 14C runtime test has been performed.
