# v21 additional hardening (source-level only)

## Changes over v20

1. Added a 250 ms Bluetooth A2DP route watchdog. It checks both `AudioTrack.routedDevice` and whether the originally selected A2DP device remains in Android's output-device list. It continues while playback is paused, complementing routing callbacks and the per-write route validation.
2. The watchdog is cancelled during Bluetooth routing cleanup to avoid retaining the streamer after Stop/finish.
3. `PcmClipStreamer.start()` is synchronized so rapid/re-entrant start requests cannot create parallel decoder workers and competing AudioPolicy sessions on one bridge.

## Limits

- The watchdog is best-effort and polling-based; a route can change between checks. Android does not expose a universal hard lock preventing OEM routing changes.
- This does not provide sample-accurate Bluetooth/Shizuku synchronization. A2DP transport latency and independent AudioTrack queues remain.
- This change has not been Android-compiled or run on Redmi 14C. The project still has no Gradle wrapper and this environment has no Android SDK/Gradle installation.

## Required tests

1. Clean Debug build and install.
2. BOTH start with A2DP connected; confirm route status and local audio.
3. Pause playback, disconnect Bluetooth, and verify watchdog stops the injector.
4. Switch between two A2DP devices while playing and while paused.
5. Rapidly tap Play twice and confirm only one decoder/session starts.
6. Seek, pause/resume, Stop, Next/Previous, and verify both outputs stop or resume together.
