# v12 ZIP Safety — Every Entry Bounded (Audio and Non-Audio)

> **সংস্করণ:** v12 — versionCode **19**, versionName **"1.9 Capture Test v12"**
> (v11-এর Capture Test, Shuffle, Folder Sync ও Recording কোড অপরিবর্তিত।)
> বদলানো ফাইল: শুধু `MainActivity.kt`-এর ZIP extraction loop
> (+ version-এর জন্য `build.gradle.kts` ও লেবেল)।

## v11-এর ফাঁক

v11-এ audio entry-র decompressed size copy করার সময় মাপা হতো —
কিন্তু non-audio entry-র জন্য সরাসরি `zin.closeEntry()` হতো।
`closeEntry()` entry-র বাকি data পড়ে শেষ করে, যাচাই ছাড়াই। তাই
non-audio entry-তে লুকানো ZIP bomb — যেমন শূন্যে ভরা ১০ GB-এর .txt,
যা compress করলে কয়েক KB হয় — কোনো সীমা ছাড়াই decompress হতো
(CPU সময় নষ্ট, কোনো আকারের হিসাব নেই)।

## সংশোধন

- **প্রতিটি Entry-র decompressed size গোনা হয়** — audio হোক বা না
  হোক। কোনো entry-ই যাচাই ছাড়া পড়া হয় না।
- **Non-audio entry boundedভাবে skip করা হয়:** ৮ KB chunk-এ পড়া
  হয়, প্রতিটি byte গোনা হয়; সীমা ছাড়ালে Import বাতিল হয়।
- **কোনো entry ৫০ MB ছাড়ালে** Import বাতিল হয়
  ("entry too large (limit 50 MB per file)")।
- **সব entry মিলিয়ে ২০০ MB ছাড়ালে** Import বাতিল হয়
  ("ZIP too large (limit 200 MB total)")।
- **Entry সংখ্যা ১০০-এর বেশি হলে** Import বাতিল হয়
  ("too many files (limit 100)")।
- **বাতিল হলে আংশিক extract করা সব ফাইল মুছে ফেলা হয়** — কিছুই
  save হয় না।
- **বাতিলের পর `closeEntry()` ডাকা হয় না** — সেটি বাকি data আবার
  যাচাই ছাড়াই পড়ত। Stream `.use` দিয়ে বন্ধ হয়।
- **UI freeze হয় না:** পুরো কাজ আগের মতো `Dispatchers.IO`-তে হয়;
  শুধু status আপডেট Main thread-এ হয়।
- **Malformed ZIP:** ভাঙা ZIP (খারাপ CRC, মাঝখানে কাটা, ভুল header)
  পড়ার সময় exception ফেলে → ধরা পড়ে → "could not read this ZIP"
  বলে Import বাতিল হয়, আংশিক ফাইল মুছে ফেলা হয়।

## Execution scenario (কোড পড়ে বের করা order — ফোনে চালিয়ে নয়)

### A. ZIP bomb — Non-Audio Entry-তে লুকানো (v11-এর ফাঁক)

| ধাপ | যা ঘটে |
|---|---|
| 1 | ZIP-এ আছে: একটি ছোট song.mp3 + একটি notes.txt যার decompressed size ১০ GB (শূন্যে ভরা, compress করলে কয়েক KB) |
| 2 | song.mp3 extract হয় (সীমার মধ্যে) |
| 3 | notes.txt আসে → non-audio শাখা: ৮ KB chunk-এ পড়া শুরু, প্রতিটি byte গোনা হয় |
| 4 | entry ৫০ MB ছাড়াতেই `abortReason = "entry too large (limit 50 MB per file)"` → লুপ থামে |
| 5 | `closeEntry()` ডাকা হয় না; stream বন্ধ হয়; Main thread-এ song.mp3-সহ আংশিক extract হওয়া সব ফাইল মুছে ফেলা হয় → status: "Import cancelled: entry too large (limit 50 MB per file). Partial files removed." |

**ফলাফল:** v11-এ এই ZIP-এর পুরো ১০ GB যাচাই ছাড়াই decompress
হতো; v12-এ ৫০ MB-তেই থামে।

### B. ZIP bomb — Audio Entry-তে লুকানো

| ধাপ | যা ঘটে |
|---|---|
| 1 | ZIP-এ একটি big.mp3 যার decompressed size ৩০০ MB |
| 2 | Copy চলছে → ৫০ MB ছাড়াতেই `abortReason = "entry too large (limit 50 MB per file)"` → copy থামে |
| 3 | আংশিক লেখা big.mp3 মুছে ফেলা হয়, কিছুই save হয় না |

**ফলাফল:** কোনো audio entry-ই ৫০ MB ছাড়াতে পারে না।

### C. মোট আকারের bomb — অনেক ছোট ছোট entry

| ধাপ | যা ঘটে |
|---|---|
| 1 | ZIP-এ ৫০টি করে ৫ MB-এর audio (প্রতিটি সীমার মধ্যে) — মোট ২৫০ MB |
| 2 | প্রতিটি entry ৫০ MB-এর নিচে বলে per-file সীমা ভাঙে না, কিন্তু `totalBytes` বাড়তে থাকে |
| 3 | মোট ২০০ MB ছাড়াতেই `abortReason = "ZIP too large (limit 200 MB total)"` → লুপ থামে |
| 4 | আগের entry-গুলো থেকে extract হওয়া সব ফাইল মুছে ফেলা হয় |

**ফলাফল:** অনেক ছোট entry দিয়েও মোট সীমা পার করা যায় না।

### D. বেশি Entry

| ধাপ | যা ঘটে |
|---|---|
| 1 | ZIP-এ ১৫০টি ছোট entry |
| 2 | ১০১তম entry-তে `abortReason = "too many files (limit 100)"` → লুপ থামে |
| 3 | আংশিক ফাইল মুছে ফেলা হয়, কিছুই save হয় না |

**ফলাফল:** Entry সংখ্যার সীমা আগের মতোই কাজ করে।

### E. Malformed ZIP

| ধাপ | যা ঘটে |
|---|---|
| 1 | ভাঙা ZIP Import করা হলো (মাঝখানে কাটা / খারাপ CRC / ভুল header) |
| 2 | পড়ার সময় `ZipException` / `IOException` ফেলে → outer `catch` ধরে → `abortReason = "could not read this ZIP"` |
| 3 | আংশিক extract হওয়া ফাইল থাকলে মুছে ফেলা হয়, কিছুই save হয় না |

**ফলাফল:** ভাঙা ZIP নিরাপদে বাতিল হয়, আংশিক ফাইল থাকে না।

### F. সাধারণ ZIP (সব ঠিক আছে)

| ধাপ | যা ঘটে |
|---|---|
| 1 | ZIP-এ ৩টি ছোট mp3 + ১টি ছোট readme.txt (কয়েক KB) |
| 2 | mp3-গুলো extract হয় (প্রতিটি সীমার মধ্যে); readme.txt bounded skip-এ একবারে পড়া শেষ হয় (সীমার অনেক নিচে) |
| 3 | ৩টি clip খোলা Folder-এ save হয় → status: "Added 3 clip(s) to Music" |

**ফলাফল:** সাধারণ ZIP আগের মতোই কাজ করে — non-audio skip-এ
কোনো অতিরিক্ত খরচ নেই (ছোট entry এক chunk-এই শেষ হয়)।

## সত্যিকারের অবস্থা

- Kotlin compilation: এখানে যাচাই হয়নি (Android SDK / kotlinc নেই) —
  শুধু static syntax scan করা হয়েছে। GitHub Actions-এ build করে
  ফোনে চালিয়ে উপরের scenario-গুলো বাস্তবে মেলাতে হবে।
- Capture Test-এর কোড (CaptureTestProbe.kt, STOP synchronization,
  CountDownLatch, Late Registration, Shizuku diagnostics) v11-এর মতোই
  অপরিবর্তিত — SHA-256 `VERIFICATION.md`-তে আছে।
