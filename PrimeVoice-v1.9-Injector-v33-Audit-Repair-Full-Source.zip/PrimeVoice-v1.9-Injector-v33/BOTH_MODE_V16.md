# Prime Voice v1.9 Injector v16 — BOTH mode

## Behavior
- ME ONLY: existing local MediaPlayer output.
- TEAMMATES ONLY: Shizuku AudioPolicy PCM injection.
- BOTH: one MediaCodec-decoded PCM stream is written to the Shizuku injection pipe and to a local AudioTrack whose preferred output is a connected Bluetooth A2DP device.
- The phone speaker is not selected as a fallback. If the Bluetooth route is absent or the AudioTrack reports a non-A2DP routed device, playback fails/stops with a status message.
- Playback controls, seek, Music auto-next/loop, and Fun one-shot behavior continue to use the existing injected-player path.

## Important limitations
- Bluetooth A2DP output and hidden AudioPolicy injection are independent Android routes. Their simultaneous operation is not guaranteed on every OEM/firmware.
- A2DP introduces latency; the local headphone audio may lag behind the teammate stream.
- Bluetooth route loss is detected during PCM writes, not guaranteed instantaneously.
- `routedDevice` may report null briefly during route establishment; if so the stream may stop rather than risk speaker playback.
- This source has not been compiled or tested on the Redmi 14C or in Free Fire. A successful compile or `ROUTE_READY` is not proof that teammates receive the audio.

## Device test
1. Connect Bluetooth A2DP headphones before selecting BOTH.
2. Start Shizuku and grant Prime Voice permission.
3. Select BOTH and play a short clip.
4. Confirm the user hears it only in Bluetooth headphones and a second player confirms teammate audibility.
5. Disconnect Bluetooth while playing; verify playback stops and does not switch to the phone speaker.
6. Test pause/resume, seek, next/previous, Music loop, and Fun one-shot.
