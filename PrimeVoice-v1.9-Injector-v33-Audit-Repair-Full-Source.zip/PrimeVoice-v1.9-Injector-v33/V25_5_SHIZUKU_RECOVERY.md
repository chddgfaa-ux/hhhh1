# v25.5 — Shizuku lifecycle and PCM fallback hardening

## Based on Prime Zerox APK inspection
The supplied Prime Zerox APK DEX contains symbols for `ShizukuConnectionManager`, `startHeartbeatIfNeeded`, `startMonitoring`, `evaluateAndConnect`, `bindAudioUserServiceIfNeeded`, `startPcmPipeSession`, and `writeInputPcm`. This update implements comparable concepts in Prime Voice; it does not copy Prime Zerox code.

## Changes
- Shizuku UserService connection handshake is checked before the UI marks the bridge connected.
- A 10-second Binder diagnostics heartbeat detects a dead/unresponsive bridge.
- Bounded exponential reconnect backoff is used after bridge disconnect or bind failure.
- Shizuku Binder-received events automatically retry binding when permission is already granted.
- PCM transport is pipe-first. If pipe creation/start fails, the app attempts a Binder byte-array PCM fallback.
- Binder PCM writes are non-blocking, bounded to 750 ms, serialized with route cleanup, and re-check the Social Call gate.
- Existing Bluetooth monitor output remains in the same synchronized PCM frame path for BOTH mode.
- App versionCode bumped to 32.

## Important verification limits
This is source-level implementation. Android Gradle build and Redmi 14C runtime tests have not been run in this environment. In particular, TEAMMATES ONLY, BOTH, call routing, Shizuku reconnect, and crash-free startup must be tested on-device before treating this as release-ready.
