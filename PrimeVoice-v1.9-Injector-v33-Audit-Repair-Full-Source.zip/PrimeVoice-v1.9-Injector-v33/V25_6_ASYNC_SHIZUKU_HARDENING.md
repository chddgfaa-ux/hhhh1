# v25.6 — Shizuku asynchronous lifecycle hardening

## Changes from v25.5
- Shizuku UserService handshake (`getDiagnostics`) now runs on a daemon worker thread; UI state is updated on the main Handler.
- The 10-second heartbeat checks `IBinder.isBinderAlive` and runs the remote diagnostics transaction off the main thread. An atomic in-flight guard prevents overlapping heartbeat transactions.
- Stale handshake/heartbeat results are ignored after the active bridge changes or disconnects.
- A bind request that receives no ServiceConnection callback within 8 seconds is marked timed out and enters the existing bounded reconnect path.
- `onBindingDied` and `onNullBinding` are handled using the same disconnect/recovery path.
- VersionCode 33 / versionName 1.9 Injector v25.6.

## Preserved
- No changes to PCM encoding, AudioPolicy route creation, output mode selection, Bluetooth BOTH routing, Music/Fun folders, or floating menu behavior.
- Pipe-first / Binder fallback and existing PCM write guards remain unchanged.

## Verification limits
- Source archive integrity and targeted source assertions checked.
- No Android Gradle build was run in this environment (no Gradle executable/wrapper available).
- No Redmi 14C runtime test was possible.
- TEAMMATES ONLY, BOTH, Social Call, and Shizuku disconnect/reconnect must be tested on-device.
