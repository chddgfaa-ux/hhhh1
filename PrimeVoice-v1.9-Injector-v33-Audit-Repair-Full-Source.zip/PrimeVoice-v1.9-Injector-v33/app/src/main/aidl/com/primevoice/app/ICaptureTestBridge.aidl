package com.primevoice.app;

/**
 * Capture Test bridge ONLY.
 *
 * Separate from the existing diagnostics bridge (IShizukuAudioBridge).
 * This interface exists only to answer one question on the target phone:
 * does AudioPolicy.registerAudioPolicy() + createAudioTrackSource()
 * deliver PCM into AudioRecord(MIC)?
 *
 * Nothing in this file changes the Floating Player or the Voice Pack /
 * Soundboard code. Those paths do not call this bridge.
 */
interface ICaptureTestBridge {
    /**
     * Starts the probe in a background thread. Returns "STARTED" or "ALREADY_RUNNING".
     * Phase A tests register() preset by preset (no tone). Phase B plays the 880 Hz
     * tone CONTINUOUSLY on the first preset that registered, until stopTest()
     * is called or maxHoldSeconds (max 120) is reached — so CHECK MIC never
     * arrives too late.
     */
    String runCaptureTest(int sampleRate, int maxHoldSeconds);
    /** Full timestamped probe log so far. Poll with the REFRESH LOG button. */
    String getTestLog();
    /**
     * Asks the probe to stop and waits up to 5 s for the worker thread to
     * finish. Returns "STOPPED" when the worker is actually dead (tone off,
     * track released, policy unregistered) or "STOPPING" if it is still
     * finishing cleanup — a new RUN is refused until it reaches IDLE.
     */
    String stopTest();
    /** True while a run is active OR still finishing its cleanup. */
    boolean isTestRunning();
    /** The UserService process UID. UID only — not proof of privileged permission. */
    int getProcessUid();
    /** Stop the probe and release its worker/resources before service removal. */
    void destroy();
}
