package com.primevoice.app;

import android.os.ParcelFileDescriptor;

/** Shizuku-hosted PCM injector control bridge. */
interface IShizukuAudioBridge {
    int getProcessUid();
    String getDiagnostics();
    String startInputRouteSession(int sampleRate);
    String startSocialCallRouteSession(int sampleRate);
    String startPcmPipeSession(in ParcelFileDescriptor readEnd);
    String startBinderPcmSession();
    int writeInputPcm(in byte[] pcm);
    String setInputRoutePaused(boolean paused);
    void stopInputRouteSession();
    /** Explicitly release route resources before the UserService is removed. */
    void destroy();
    String getLog();
    String getPipeStatus();
}
