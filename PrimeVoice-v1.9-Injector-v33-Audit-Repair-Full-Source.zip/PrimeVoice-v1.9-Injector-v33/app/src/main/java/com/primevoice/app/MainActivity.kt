package com.primevoice.app

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.BufferedInputStream
import java.io.File
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku
import java.util.concurrent.atomic.AtomicBoolean

private val Bg = Color(0xFF080D13)
private val Panel = Color(0xFF111B25)
private val Cyan = Color(0xFF20DDF5)
private val Muted = Color(0xFF8FA3B5)

data class SoundClip(val name: String, val uri: Uri)

// v10: audio file names accepted by ZIP import.
private fun isAudioFileName(name: String): Boolean {
    val lower = name.lowercase()
    return lower.endsWith(".mp3") || lower.endsWith(".wav") || lower.endsWith(".m4a") ||
        lower.endsWith(".ogg") || lower.endsWith(".flac") || lower.endsWith(".aac") || lower.endsWith(".opus")
}

// v11 ZIP import safety limits: at most 100 entries, at most 50 MB per
// file, at most 200 MB extracted in total. A ZIP that breaks a limit is
// cancelled safely and every partially extracted file is deleted.
private const val MAX_ZIP_ENTRIES = 100
private const val MAX_ZIP_FILE_BYTES = 50L * 1024 * 1024
private const val MAX_ZIP_TOTAL_BYTES = 200L * 1024 * 1024

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeVoiceApp() }
    }
}

@Composable
fun PrimeVoiceApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Soundboard") }
    var socialCallEnabled by remember { mutableStateOf(context.getSharedPreferences(VoiceFolders.PREFS, android.content.Context.MODE_PRIVATE).getBoolean("social_call_enabled", false)) }
    var status by remember { mutableStateOf("Ready") }
    var shizukuStatus by remember { mutableStateOf("Not checked") }
    var bridgeDiagnostics by remember { mutableStateOf("Audio bridge not connected") }
    var bridgeConnected by remember { mutableStateOf(false) }
    var bridgeBindRequested by remember { mutableStateOf(false) }
    var bridgeApi by remember { mutableStateOf<IShizukuAudioBridge?>(null) }
    var bridgeDeathBinder by remember { mutableStateOf<IBinder?>(null) }
    var bridgeDeathRecipient by remember { mutableStateOf<IBinder.DeathRecipient?>(null) }
    var reconnectAttempt by remember { mutableIntStateOf(0) }
    var bridgeReconnectScheduled by remember { mutableStateOf(false) }
    val shizukuHandler = remember { Handler(Looper.getMainLooper()) }
    val bridgeProbeInFlight = remember { AtomicBoolean(false) }
    lateinit var bindDiagnosticBridge: () -> Unit
    lateinit var scheduleBridgeReconnect: () -> Unit
    lateinit var unbindDiagnosticBridge: () -> Unit
    lateinit var bridgeReconnectTask: Runnable
    val bridgeArgs = remember(context) {
        Shizuku.UserServiceArgs(ComponentName(context, ShizukuAudioUserService::class.java))
            .daemon(false)
            // Isolate diagnostics from the live FloatingMenuService playback process.
            .processNameSuffix("audio_diagnostic")
            .debuggable(BuildConfig.DEBUG)
            .version(4)
    }
    val bridgeBindTimeout = remember {
        Runnable {
            if (bridgeBindRequested && !bridgeConnected) {
                // The timeout covers BOTH initial bind and Binder handshake.
                // onServiceConnected alone does not prove the remote service responds.
                bridgeBindRequested = false
                bridgeConnected = false
                bridgeApi = null
                bridgeDiagnostics = "Shizuku UserService bind/handshake timed out (8s)"
                runCatching { unbindDiagnosticBridge() }
                scheduleBridgeReconnect()
            }
        }
    }
    val bridgeConnection = remember {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                // Keep timeout armed until getDiagnostics() completes; a connected
                // Binder may still be unresponsive on some OEM builds.
                if (service == null) {
                    bridgeDiagnostics = "Shizuku returned a null audio Binder"
                    bridgeConnected = false
                    bridgeBindRequested = false
                    scheduleBridgeReconnect()
                    return
                }
                // Track the remote UserService Binder itself, not only Shizuku's
                // manager Binder. This catches a service-process death promptly.
                runCatching {
                    val oldBinder = bridgeDeathBinder
                    val oldRecipient = bridgeDeathRecipient
                    if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
                }
                val deathRecipient = IBinder.DeathRecipient {
                    shizukuHandler.post {
                        if (bridgeDeathBinder === service) {
                            bridgeDeathBinder = null
                            bridgeDeathRecipient = null
                            bridgeApi = null
                            bridgeConnected = false
                            bridgeBindRequested = false
                            shizukuHandler.removeCallbacks(bridgeBindTimeout)
                            bridgeDiagnostics = "Shizuku audio UserService Binder died"
                            runCatching { unbindDiagnosticBridge() }
                            scheduleBridgeReconnect()
                        }
                    }
                }
                try {
                    service.linkToDeath(deathRecipient, 0)
                    bridgeDeathBinder = service
                    bridgeDeathRecipient = deathRecipient
                } catch (dead: android.os.RemoteException) {
                    bridgeDiagnostics = "Shizuku audio UserService died during bind"
                    bridgeConnected = false
                    bridgeBindRequested = false
                    scheduleBridgeReconnect()
                    return
                }
                val api = IShizukuAudioBridge.Stub.asInterface(service)
                bridgeApi = api
                bridgeBindRequested = true
                // Never perform a synchronous Binder transaction on the UI thread.
                thread(name = "PrimeVoiceShizukuHandshake", isDaemon = true) {
                    val diagnostics = runCatching { api.getDiagnostics() }
                    shizukuHandler.post {
                        if (bridgeApi !== api || !bridgeBindRequested) return@post
                        diagnostics.onSuccess {
                            shizukuHandler.removeCallbacks(bridgeBindTimeout)
                            bridgeConnected = true
                            bridgeBindRequested = true
                            reconnectAttempt = 0
                            shizukuHandler.removeCallbacks(bridgeReconnectTask)
                            bridgeReconnectScheduled = false
                            bridgeDiagnostics = it
                        }.onFailure {
                            shizukuHandler.removeCallbacks(bridgeBindTimeout)
                            bridgeApi = null
                            bridgeConnected = false
                            bridgeBindRequested = false
                            runCatching {
                                val oldBinder = bridgeDeathBinder
                                val oldRecipient = bridgeDeathRecipient
                                if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
                            }
                            bridgeDeathBinder = null
                            bridgeDeathRecipient = null
                            bridgeDiagnostics = "Bridge handshake failed: ${it.message ?: it.javaClass.simpleName}"
                            runCatching { unbindDiagnosticBridge() }
                            scheduleBridgeReconnect()
                        }
                    }
                }
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                shizukuHandler.removeCallbacks(bridgeBindTimeout)
                runCatching {
                    val oldBinder = bridgeDeathBinder
                    val oldRecipient = bridgeDeathRecipient
                    if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
                }
                bridgeDeathBinder = null
                bridgeDeathRecipient = null
                bridgeApi = null
                bridgeConnected = false
                bridgeBindRequested = false
                bridgeDiagnostics = "Shizuku UserService disconnected; reconnect scheduled"
                scheduleBridgeReconnect()
            }
            override fun onBindingDied(name: ComponentName?) {
                onServiceDisconnected(name)
            }
            override fun onNullBinding(name: ComponentName?) {
                onServiceDisconnected(name)
            }
        }
    }
    bridgeReconnectTask = remember {
        Runnable {
            bridgeReconnectScheduled = false
            if (!bridgeConnected && !bridgeBindRequested && Shizuku.pingBinder() &&
                runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)) {
                bindDiagnosticBridge()
            }
        }
    }
    unbindDiagnosticBridge = {
        runCatching { Shizuku.unbindUserService(bridgeArgs, bridgeConnection, true) }
    }
    scheduleBridgeReconnect = reconnect@{
        if (!Shizuku.pingBinder()) {
            shizukuStatus = "Shizuku service unavailable"
            return@reconnect
        }
        if (runCatching { Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED }.getOrDefault(true)) {
            shizukuStatus = "Shizuku permission required"
            return@reconnect
        }
        if (bridgeConnected || bridgeBindRequested || bridgeReconnectScheduled) return@reconnect
        if (reconnectAttempt >= 5) {
            shizukuStatus = "Reconnect paused after 5 attempts; retry by reopening the app"
            return@reconnect
        }
        val delayMs = (1000L shl reconnectAttempt.coerceIn(0, 4)).coerceAtMost(16000L)
        reconnectAttempt += 1
        bridgeReconnectScheduled = true
        shizukuStatus = "Shizuku reconnecting…"
        shizukuHandler.removeCallbacks(bridgeReconnectTask)
        shizukuHandler.postDelayed(bridgeReconnectTask, delayMs)
    }
    val bridgeHeartbeat = remember {
        object : Runnable {
            override fun run() {
                val api = bridgeApi
                if (bridgeConnected && api != null && bridgeProbeInFlight.compareAndSet(false, true)) {
                    // Binder diagnostics may stall on OEM builds. Probe off-main and
                    // ignore stale results after a disconnect/rebind.
                    thread(name = "PrimeVoiceShizukuHeartbeat", isDaemon = true) {
                        val live = runCatching {
                            if (!api.asBinder().isBinderAlive) null else api.getDiagnostics()
                        }.getOrNull()
                        bridgeProbeInFlight.set(false)
                        shizukuHandler.post {
                            if (bridgeApi !== api || !bridgeConnected) return@post
                            if (live.isNullOrBlank()) {
                                runCatching {
                                    val oldBinder = bridgeDeathBinder
                                    val oldRecipient = bridgeDeathRecipient
                                    if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
                                }
                                bridgeDeathBinder = null
                                bridgeDeathRecipient = null
                                bridgeApi = null
                                bridgeConnected = false
                                bridgeBindRequested = false
                                bridgeDiagnostics = "Shizuku heartbeat failed; reconnecting"
                                runCatching { unbindDiagnosticBridge() }
                                scheduleBridgeReconnect()
                            } else bridgeDiagnostics = live
                        }
                    }
                }
                shizukuHandler.postDelayed(this, 10000L)
            }
        }
    }
    // ------------------------------------------------------------------
    // ADDITIVE ONLY — CAPTURE TEST (v1.9 test). Nothing below changes the
    // Floating Player, Soundboard / Voice Pack, or Recorder code.
    // It only adds a separate Shizuku test service + a Settings section.
    // ------------------------------------------------------------------
    var testStatus by remember { mutableStateOf("Not run yet") }
    var testLog by remember { mutableStateOf("") }
    // v4: true while a Capture Test run is active OR still finishing cleanup.
    // The RUN button is disabled while this is true — a new RUN is only
    // allowed after the previous worker fully finished (state=IDLE).
    var testRunning by remember { mutableStateOf(false) }
    var testConnected by remember { mutableStateOf(false) }
    var testBindRequested by remember { mutableStateOf(false) }
    var testBridge by remember { mutableStateOf<ICaptureTestBridge?>(null) }
    var micCheckResult by remember { mutableStateOf("Mic check not run yet") }
    // Baseline (no tone) 880 Hz ratio. -1.0 = not measured yet. Used to stop
    // speaker/room sound from giving a false TONE_DETECTED (review point 4).
    var baselineRatio by remember { mutableStateOf(-1.0) }
    var baselineStatus by remember { mutableStateOf("Baseline not measured yet — run it BEFORE the capture test, with no tone playing.") }
    val testRecorder = remember { CaptureTestRecorder() }
    val testArgs = remember(context) {
        Shizuku.UserServiceArgs(ComponentName(context, CaptureTestUserService::class.java))
            .daemon(false)
            .processNameSuffix("capture_test")
            .debuggable(BuildConfig.DEBUG)
            .version(1)
    }
    val testConnection = remember {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                testBridge = ICaptureTestBridge.Stub.asInterface(service)
                testConnected = true
                testBindRequested = true
                testStatus = "Capture Test service connected (uid=${runCatching { testBridge?.getProcessUid() }.getOrNull()})"
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                testBridge = null
                testConnected = false
                testBindRequested = false
                testStatus = "Capture Test service disconnected"
            }
            override fun onBindingDied(name: ComponentName?) {
                testBridge = null
                testConnected = false
                testBindRequested = false
                testStatus = "Capture Test binding died; reconnect required"
            }
            override fun onNullBinding(name: ComponentName?) {
                testBridge = null
                testConnected = false
                testBindRequested = false
                testStatus = "Capture Test returned a null Binder"
            }
        }
    }
    fun bindCaptureTestService() {
        if (testConnected || testBindRequested) {
            testStatus = if (testConnected) "Capture Test already connected" else "Capture Test connection is pending"
            return
        }
        try {
            Shizuku.bindUserService(testArgs, testConnection)
            testBindRequested = true
            testStatus = "Capture Test bind requested…"
        } catch (e: Exception) {
            testBindRequested = false
            testStatus = "Capture Test bind failed: ${e.message ?: "unknown error"}"
        }
    }
    fun runCaptureTest() {
        if (!Shizuku.pingBinder()) { testStatus = "Shizuku is not running. Start Shizuku first."; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            testStatus = "Shizuku permission is not granted. Use CHECK / REQUEST SHIZUKU above first."
            return
        }
        if (!testConnected) { bindCaptureTestService(); testStatus = "Connecting Capture Test service — tap RUN CAPTURE TEST again once connected."; return }
        // v4: refuse locally if a run is still active/finishing — the service
        // refuses too (ALREADY_RUNNING), but the button should not even try.
        if (runCatching { testBridge?.isTestRunning() }.getOrNull() == true) {
            testStatus = "A Capture Test is still running/finishing — wait for it to reach IDLE (tap REFRESH LOG), then RUN again."
            return
        }
        // Second param = max seconds the tone is HELD on the best preset (max 120).
        // Phase A tests register() preset by preset; Phase B holds the tone until STOP TEST.
        val result = runCatching { testBridge?.runCaptureTest(48000, 120) }.getOrNull()
        if (result == "STARTED") testRunning = true
        testStatus = "Capture Test $result — Phase A tests register() preset by preset, then Phase B HOLDS the 880 Hz tone on the best preset until STOP TEST. Tap REFRESH LOG to follow it, and CHECK MIC while the tone plays."
    }
    fun refreshTestLog() {
        testLog = runCatching { testBridge?.getTestLog() }.getOrNull() ?: "No test log yet (service not connected)"
        testRunning = runCatching { testBridge?.isTestRunning() }.getOrNull() ?: false
    }
    fun stopCaptureTest() {
        testRecorder.stop()
        testStatus = "Stopping Capture Test…"
        // v13: stopTest() joins the worker up to 5 s, so it must NOT run
        // on the main thread — tapping STOP during a register wait froze
        // the UI for up to 5 s (ANR edge). Run it on a worker thread and
        // post the result back to the main thread.
        kotlin.concurrent.thread(name = "PrimeVoiceStopTest") {
            val result = runCatching { testBridge?.stopTest() }.getOrNull()
            Handler(Looper.getMainLooper()).post {
                testStatus = result ?: "Capture Test stop requested"
                refreshTestLog()
            }
        }
    }
    fun runBaselineCheck() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            baselineStatus = "Microphone permission needed — grant microphone permission in Android app settings, then tap BASELINE CHECK again."
            return
        }
        baselineStatus = "Recording MIC for 10s with NO tone playing — stay quiet…"
        testRecorder.checkMic(10, baselineRatio = 0.0) { result ->
            // FIX (review point 3): ratio alone is not enough. If the baseline
            // recording captured almost nothing (RMS below the silence floor),
            // its ratio is meaningless — a quiet room is not the same as a
            // verified-quiet baseline. Do NOT store it; re-run in normal room
            // conditions (do not cover the mic, do not test in dead silence).
            if (result.rms < 50.0) {
                baselineRatio = -1.0
                baselineStatus = "Baseline INCONCLUSIVE — almost no sound captured (rms=${"%.0f".format(result.rms)}), " +
                    "so the ratio is meaningless. Re-run in normal room conditions (mic uncovered, normal ambient sound)."
            } else {
                baselineRatio = result.ratio
                baselineStatus = "Baseline 880Hz ratio=${"%.1f".format(result.ratio)} (rms=${"%.0f".format(result.rms)}). " +
                    if (result.ratio >= 4.0) "Too high — room is noisy or speaker is leaking. Use headphones / quiet room and re-run."
                    else "OK — room is quiet at 880 Hz with real sound captured. Now run the Capture Test."
            }
        }
    }
    fun runMicCheck() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            // NOTE: do not launch the mic permission request from here — that
            // launcher is declared later in this function. Grant Microphone
            // in Android app settings, then come back.
            micCheckResult = "Microphone permission needed — grant it in Android app settings, then tap CHECK MIC again."
            return
        }
        micCheckResult = "Recording MIC for 10s — the Capture Test tone should be playing (Phase B holds it)…"
        testRecorder.checkMic(10, baselineRatio = if (baselineRatio >= 0.0) baselineRatio else 0.0) { result ->
            micCheckResult = "${result.message} (rms=${"%.0f".format(result.rms)} peak=${result.peak} 880Hz ratio=${"%.1f".format(result.ratio)})"
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            if (testBindRequested || testConnected) {
                runCatching { Shizuku.unbindUserService(testArgs, testConnection, true) }
            }
            testRecorder.stop()
            testConnected = false
            testBindRequested = false
        }
    }
    bindDiagnosticBridge = bind@{
        if (bridgeConnected || bridgeBindRequested) {
            bridgeDiagnostics = if (bridgeConnected) "Bridge already connected" else "Bridge connection is pending"
            return@bind
        }
        try {
            Shizuku.bindUserService(bridgeArgs, bridgeConnection)
            bridgeBindRequested = true
            bridgeDiagnostics = "Shizuku UserService bind requested…"
            shizukuHandler.removeCallbacks(bridgeBindTimeout)
            shizukuHandler.postDelayed(bridgeBindTimeout, 8000L)
        } catch (e: Exception) {
            bridgeBindRequested = false
            bridgeDiagnostics = "Bridge bind failed: ${e.message ?: "unknown error"}"
            scheduleBridgeReconnect()
        }
    }
    val permissionResultListener = remember {
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == 4106) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    shizukuStatus = "Permission granted • connecting bridge…"
                    reconnectAttempt = 0
                    bindDiagnosticBridge()
                } else {
                    shizukuStatus = "Shizuku permission denied"
                    bridgeDiagnostics = "Permission is required before binding the diagnostic service"
                }
            }
        }
    }
    val binderReceivedListener = remember {
        Shizuku.OnBinderReceivedListener {
            shizukuStatus = "Shizuku service detected • connecting…"
            shizukuHandler.postDelayed({
                if (!bridgeConnected && !bridgeBindRequested) bindDiagnosticBridge()
            }, 500L)
        }
    }
    val binderDeadListener = remember {
        Shizuku.OnBinderDeadListener {
            runCatching {
                val oldBinder = bridgeDeathBinder
                val oldRecipient = bridgeDeathRecipient
                if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
            }
            bridgeDeathBinder = null
            bridgeDeathRecipient = null
            bridgeApi = null
            bridgeConnected = false
            bridgeBindRequested = false
            reconnectAttempt = 0
            shizukuHandler.removeCallbacks(bridgeReconnectTask)
            bridgeReconnectScheduled = false
            bridgeDiagnostics = "Shizuku service stopped; waiting for Binder recovery"
            shizukuStatus = "Shizuku service disconnected"
            // v13: the Capture Test service runs in the same Shizuku
            // process space, so its binder is dead too. Reset its state
            // so the next RUN rebinds instead of calling a dead binder
            // (which only returned null and left a stale "connected").
            testBridge = null
            testConnected = false
            testBindRequested = false
            testStatus = "Capture Test service disconnected (Shizuku died)"
        }
    }
    DisposableEffect(Unit) {
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        shizukuHandler.removeCallbacks(bridgeHeartbeat)
        shizukuHandler.postDelayed(bridgeHeartbeat, 10000L)
        // On app open, automatically bind the app's Shizuku bridge when
        // Shizuku is already running and permission has already been granted.
        runCatching {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuStatus = "Shizuku detected • connecting app bridge…"
                bindDiagnosticBridge()
            } else if (!Shizuku.pingBinder()) {
                shizukuStatus = "Shizuku not running"
            } else {
                shizukuStatus = "Shizuku permission required"
            }
        }.onFailure {
            shizukuStatus = "Shizuku unavailable: ${it.message ?: "check setup"}"
        }
        onDispose {
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            shizukuHandler.removeCallbacks(bridgeHeartbeat)
            shizukuHandler.removeCallbacks(bridgeBindTimeout)
            shizukuHandler.removeCallbacks(bridgeReconnectTask)
            bridgeReconnectScheduled = false
            shizukuHandler.removeCallbacksAndMessages(null)
            val shouldUnbindBridge = bridgeBindRequested || bridgeConnected
            runCatching {
                val oldBinder = bridgeDeathBinder
                val oldRecipient = bridgeDeathRecipient
                if (oldBinder != null && oldRecipient != null) oldBinder.unlinkToDeath(oldRecipient, 0)
            }
            bridgeDeathBinder = null
            bridgeDeathRecipient = null
            bridgeApi = null
            bridgeConnected = false
            bridgeBindRequested = false
            if (shouldUnbindBridge) {
                runCatching { Shizuku.unbindUserService(bridgeArgs, bridgeConnection, true) }
            }
            bridgeConnected = false
            bridgeBindRequested = false
        }
    }
    var selectedEffect by remember { mutableStateOf("Deep") }
    // v10: two voice folders. `folder` is the open folder (shared with
    // the floating panel through prefs); `clips` is ONLY that folder's
    // list. Import (audio / ZIP / recording) and delete always target
    // the open folder — a folder's files never appear in the other
    // folder's list, and the same file name in both stays separate.
    // v11: `prefs` is kept for the folder-sync listener below.
    val prefs = remember { context.getSharedPreferences(VoiceFolders.PREFS, android.content.Context.MODE_PRIVATE) }
    var folder by remember { mutableStateOf(VoiceFolders.selectedFolder(context)) }
    var clips by remember {
        VoiceFolders.migrateIfNeeded(context)
        mutableStateOf(VoiceFolders.loadClips(context, folder))
    }
    fun saveLibrary(items: List<SoundClip>) {
        VoiceFolders.saveClips(context, folder, items)
    }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var currentPosition by remember { mutableIntStateOf(0) }
    var trackDuration by remember { mutableIntStateOf(0) }
    var activeClip by remember { mutableStateOf<SoundClip?>(null) }
    var recorder by remember { mutableStateOf<PcmWavRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    // v11: the folder where the CURRENT recording started. Captured in
    // startRecording() so a folder change mid-recording can never send
    // the file to the wrong folder.
    var recordingFolder by remember { mutableStateOf<VoiceFolder?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var pendingRecordStart by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        onDispose {
            try { player?.release() } catch (_: Exception) {}
        }
    }

    val importAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val name = it.lastPathSegment?.substringAfterLast(':') ?: "Imported audio"
            try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val updated = clips + SoundClip(name, it)
            clips = updated
            saveLibrary(updated)
            status = "Added to soundboard"
        }
    }
    // v10 ZIP import (new — v1.9/v9 had Audio Import only). Extracts the
    // audio files from a ZIP into the folder that is open right now.
    // Runs on IO so a big ZIP cannot freeze the UI; the target folder is
    // captured up front, so switching folders mid-import cannot send the
    // files to the wrong folder. State is updated on Main.
    // v11 safety: entry count, per-file size and total size are limited
    // WHILE copying (not after). A ZIP that breaks a limit, or cannot be
    // read, is cancelled safely and every partially extracted file is
    // deleted — nothing half-imported is ever saved.
    // v12: the SAME limits now cover NON-AUDIO entries too. v11 skipped
    // them with a bare closeEntry(), which reads the rest of the entry
    // unchecked — a ZIP bomb hidden in a non-audio entry (e.g. a huge
    // .txt of zeros) would be decompressed with no limit. Every byte
    // of every entry is now counted, audio or not.
    val scope = rememberCoroutineScope()
    val importZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { zipUri ->
            val targetFolder = folder
            scope.launch(Dispatchers.IO) {
                val added = mutableListOf<SoundClip>()
                val createdFiles = mutableListOf<File>()
                var totalBytes = 0L
                var abortReason: String? = null
                try {
                    context.contentResolver.openInputStream(zipUri)?.use { raw ->
                        ZipInputStream(BufferedInputStream(raw)).use { zin ->
                            var entry = zin.nextEntry
                            var entries = 0
                            while (entry != null && abortReason == null) {
                                entries++
                                if (entries > MAX_ZIP_ENTRIES) {
                                    abortReason = "too many files (limit $MAX_ZIP_ENTRIES)"
                                    break
                                }
                                val name = entry.name.substringAfterLast('/').trim()
                                if (!entry.isDirectory && isAudioFileName(name)) {
                                    val outFile = File(context.getExternalFilesDir(null), "prime_voice_${System.currentTimeMillis()}_${added.size}_$name")
                                    createdFiles += outFile
                                    var fileBytes = 0L
                                    var tooBig = false
                                    outFile.outputStream().use { out ->
                                        val buffer = ByteArray(8192)
                                        while (true) {
                                            val read = zin.read(buffer)
                                            if (read == -1) break
                                            fileBytes += read
                                            totalBytes += read
                                            if (fileBytes > MAX_ZIP_FILE_BYTES) {
                                                abortReason = "entry too large (limit ${MAX_ZIP_FILE_BYTES / (1024 * 1024)} MB per file)"
                                                tooBig = true
                                                break
                                            }
                                            if (totalBytes > MAX_ZIP_TOTAL_BYTES) {
                                                abortReason = "ZIP too large (limit ${MAX_ZIP_TOTAL_BYTES / (1024 * 1024)} MB total)"
                                                tooBig = true
                                                break
                                            }
                                            out.write(buffer, 0, read)
                                        }
                                    }
                                    if (tooBig) break
                                    if (outFile.length() > 0) added += SoundClip(name, Uri.fromFile(outFile))
                                } else {
                                    // v12: non-audio entries (and directories) are
                                    // consumed BOUNDEDLY too — counted byte by
                                    // byte, never skipped unchecked. A ZIP bomb
                                    // in a non-audio entry aborts the import
                                    // exactly like one in an audio entry.
                                    var entryBytes = 0L
                                    val buffer = ByteArray(8192)
                                    while (true) {
                                        val read = zin.read(buffer)
                                        if (read == -1) break
                                        entryBytes += read
                                        totalBytes += read
                                        if (entryBytes > MAX_ZIP_FILE_BYTES) {
                                            abortReason = "entry too large (limit ${MAX_ZIP_FILE_BYTES / (1024 * 1024)} MB per file)"
                                            break
                                        }
                                        if (totalBytes > MAX_ZIP_TOTAL_BYTES) {
                                            abortReason = "ZIP too large (limit ${MAX_ZIP_TOTAL_BYTES / (1024 * 1024)} MB total)"
                                            break
                                        }
                                    }
                                }
                                // v12: after an abort, do NOT call closeEntry()
                                // — it would read the rest of the aborted
                                // entry unchecked. The stream is closed by
                                // .use instead.
                                if (abortReason != null) break
                                zin.closeEntry()
                                entry = zin.nextEntry
                            }
                        }
                    }
                } catch (_: Exception) {
                    if (abortReason == null) abortReason = "could not read this ZIP"
                }
                withContext(Dispatchers.Main) {
                    if (abortReason != null) {
                        createdFiles.forEach { runCatching { if (it.exists()) it.delete() } }
                        status = "Import cancelled: $abortReason. Partial files removed."
                    } else if (added.isNotEmpty()) {
                        val updated = VoiceFolders.loadClips(context, targetFolder) + added
                        VoiceFolders.saveClips(context, targetFolder, updated)
                        if (folder == targetFolder) clips = updated
                        status = "Added ${added.size} clip(s) to ${targetFolder.label}"
                    } else {
                        status = "No audio files found in this ZIP"
                    }
                }
            }
        }
    }
    val bluetoothPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) "Bluetooth permission granted" else "Bluetooth permission denied. BOTH mode requires Bluetooth access; enable it in App permissions."
    }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            bluetoothPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (tab == "Recorder") pendingRecordStart = true
            else status = "Microphone permission granted"
        } else status = "Microphone permission denied"
    }

    var mediaGeneration by remember { mutableIntStateOf(0) }
    fun playClip(clip: SoundClip) {
        val generation = ++mediaGeneration
        runCatching { player?.release() }
        player = null
        currentPosition = 0
        trackDuration = 0
        activeClip = clip
        status = "Preparing: ${clip.name}"
        try {
            val next = MediaPlayer()
            player = next
            next.setDataSource(context, clip.uri)
            next.setOnPreparedListener { prepared ->
                if (generation != mediaGeneration || player !== prepared) { prepared.release(); return@setOnPreparedListener }
                trackDuration = prepared.duration.coerceAtLeast(0)
                currentPosition = 0
                prepared.start()
                status = "Playing: ${clip.name}"
            }
            next.setOnCompletionListener { completed ->
                if (generation == mediaGeneration && player === completed) {
                    completed.release(); player = null; currentPosition = 0; status = "Finished"
                }
            }
            next.setOnErrorListener { failed, what, extra ->
                if (generation == mediaGeneration && player === failed) {
                    runCatching { failed.release() }; player = null
                    status = "Playback error ($what/$extra)"
                }
                true
            }
            next.prepareAsync()
        } catch (e: Exception) {
            runCatching { player?.release() }; player = null
            status = "Cannot play this file: ${e.message ?: e.javaClass.simpleName}"
        }
    }
    fun stopAudio() {
        mediaGeneration++
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        currentPosition = 0
        activeClip = null
        status = "Stopped"
    }
    // v10: switching folder stops the old folder's clip (separate
    // playback state) and shows the new folder's list. The choice is
    // saved in prefs, so the floating panel opens the same folder.
    fun switchFolder(newFolder: VoiceFolder) {
        if (newFolder == folder) return
        stopAudio()
        folder = newFolder
        VoiceFolders.setSelectedFolder(context, newFolder)
        clips = VoiceFolders.loadClips(context, newFolder)
        status = "Folder: ${newFolder.label}"
    }
    // v11: live folder sync. The floating panel writes selected_folder
    // too; sharing the key alone does NOT update this Compose state.
    // This listener updates the folder + list the moment it changes
    // anywhere, so the app and the floating panel always show the same
    // folder and Import/Delete always target the same folder in both
    // places. Changes this screen makes itself are ignored (the state
    // already matches). State is touched on the main thread only.
    DisposableEffect(Unit) {
        val mainHandler = Handler(Looper.getMainLooper())
        val folderListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == VoiceFolders.KEY_SELECTED) {
                mainHandler.post {
                    val newFolder = VoiceFolders.selectedFolder(context)
                    if (newFolder != folder) {
                        stopAudio()
                        folder = newFolder
                        clips = VoiceFolders.loadClips(context, newFolder)
                        status = "Folder: ${newFolder.label}"
                    }
                }
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(folderListener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(folderListener) }
    }
    fun startRecording() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) { micPermission.launch(Manifest.permission.RECORD_AUDIO); return }
        // v11: capture the folder NOW. stopRecording() saves to this
        // folder even if the user switches folders while recording.
        recordingFolder = folder
        try {
            val file = File(context.getExternalFilesDir(null), "prime_voice_${System.currentTimeMillis()}.wav")
            val r = PcmWavRecorder(file)
            r.start()
            recorder = r
            recordingFile = file
            isRecording = true
            status = "Recording WAV…"
        } catch (e: Exception) { status = "Recorder could not start: ${e.message ?: "unknown error"}" }
    }
    fun stopRecording() {
        val error = recorder?.stop()
        val file = recordingFile
        // v11: the recording goes to the folder where it STARTED, even
        // if the folder was changed while recording. Never the folder
        // open at stop time. The list on screen only changes when the
        // saved folder is the open one.
        val targetFolder = recordingFolder ?: folder
        if (error == null && file != null && file.exists() && file.length() > 48) {
            val updated = VoiceFolders.loadClips(context, targetFolder) + SoundClip(file.name, Uri.fromFile(file))
            VoiceFolders.saveClips(context, targetFolder, updated)
            if (folder == targetFolder) clips = updated
            status = "Recording saved and added to ${targetFolder.label}."
        } else {
            status = "Recording failed: ${error ?: "clip was too short"}"
        }
        recorder = null
        recordingFile = null
        recordingFolder = null
        isRecording = false
    }

    LaunchedEffect(pendingRecordStart) {
        if (pendingRecordStart) {
            pendingRecordStart = false
            startRecording()
        }
    }

    LaunchedEffect(player) {
        while (player != null) {
            try { currentPosition = player?.currentPosition ?: 0 } catch (_: Exception) {}
            delay(250)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Soundboard", "Recorder", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) {
                            "Soundboard" -> Icons.Default.LibraryMusic
                            "Recorder" -> Icons.Default.Mic
                            else -> Icons.Default.Tune
                        }, contentDescription = item) },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF183642), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PRIME VOICE", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("FREE FIRE EDITION • GAMING AUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Text("● READY", color = Cyan, fontSize = 11.sp)
                }
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("AUDIO STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Text(status, fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                    status = "Allow display over other apps, then tap WINDOW START again."
                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                } else {
                                    runCatching {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(Intent(context, FloatingMenuService::class.java)) else context.startService(Intent(context, FloatingMenuService::class.java))
                                    }.onSuccess {
                                        status = "Floating window started"
                                    }.onFailure {
                                        status = "Floating window could not start: ${it.message ?: "unknown error"}"
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("WINDOW START")
                        }
                    }
                }
                when (tab) {
                    "Soundboard" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SOUND PACKS", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Button(onClick = { importAudio.launch(arrayOf("audio/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("IMPORT AUDIO") }
                        }
                        Text("Import MP3, WAV, M4A or other Android-supported audio files.", color = Muted, fontSize = 12.sp)
                        // v10: two voice folders. Music = playlist (Auto Next
                        // + Loop in the floating player); Fun = one-shot.
                        // Import (audio / ZIP) and recordings always go to
                        // the open folder only; each folder keeps its own
                        // list — the same file name in both stays separate.
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { switchFolder(VoiceFolder.MUSIC) },
                                colors = ButtonDefaults.buttonColors(containerColor = if (folder == VoiceFolder.MUSIC) Cyan else Panel, contentColor = if (folder == VoiceFolder.MUSIC) Bg else Color.White)) { Text("♪ MUSIC") }
                            Button(onClick = { switchFolder(VoiceFolder.FUN) },
                                colors = ButtonDefaults.buttonColors(containerColor = if (folder == VoiceFolder.FUN) Cyan else Panel, contentColor = if (folder == VoiceFolder.FUN) Bg else Color.White)) { Text("☺ FUN") }
                            Button(onClick = { importZip.launch(arrayOf("application/zip")) },
                                colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) { Text("IMPORT ZIP") }
                        }
                        Text("Open folder: ${folder.label} — imports and recordings are saved here only.", color = Muted, fontSize = 12.sp)
                        if (activeClip != null) {
                            Surface(color = Color(0xFF102630), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.GraphicEq, null, tint = Cyan)
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(activeClip?.name ?: "Now playing", color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text(if (player != null) "NOW PLAYING" else "PLAYBACK FINISHED", color = Cyan, fontSize = 10.sp, letterSpacing = 1.3.sp)
                                        }
                                        IconButton(onClick = { stopAudio() }) { Icon(Icons.Default.Stop, "Stop", tint = Cyan) }
                                    }
                                    Slider(
                                        value = if (trackDuration > 0) currentPosition.coerceIn(0, trackDuration).toFloat() else 0f,
                                        onValueChange = { value ->
                                            currentPosition = value.toInt()
                                            try { player?.seekTo(currentPosition) } catch (_: Exception) {}
                                        },
                                        valueRange = 0f..(trackDuration.coerceAtLeast(1).toFloat()),
                                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF36515C))
                                    )
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(formatTime(currentPosition), color = Muted, fontSize = 11.sp)
                                        Text(formatTime(trackDuration), color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        Button(onClick = { stopAudio() }, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) { Icon(Icons.Default.Stop, null); Text("  STOP PLAYBACK") }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(clips) { clip ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(start = 15.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Row(Modifier.weight(1f).clickable { playClip(clip) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.LibraryMusic, null, tint = Cyan)
                                            Spacer(Modifier.width(12.dp))
                                            Text(clip.name, modifier = Modifier.weight(1f), maxLines = 1)
                                            Text("PLAY", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        IconButton(onClick = {
                                            val updated = clips.filterNot { it == clip }
                                            clips = updated
                                            saveLibrary(updated)
                                            if (activeClip == clip) stopAudio()
                                            val stillUsed = VoiceFolders.loadClips(context, VoiceFolder.MUSIC).any { it.uri == clip.uri } ||
                                                VoiceFolders.loadClips(context, VoiceFolder.FUN).any { it.uri == clip.uri }
                                            if (!stillUsed && clip.uri.scheme == "file") runCatching { File(clip.uri.path ?: "").delete() }
                                            status = "Clip removed"
                                        }) { Icon(Icons.Default.Delete, "Remove clip", tint = Muted) }
                                    }
                                }
                            }
                        }
                        if (clips.isEmpty()) Text("No clips yet. Import an audio file or record your own.", color = Muted)
                    }
                    "Recorder" -> {
                        Text("VOICE RECORDER", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Record a voice clip and it will be added to your Soundboard.", color = Muted, fontSize = 13.sp)
                        Button(onClick = { if (isRecording) stopRecording() else startRecording() }, colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color(0xFF9E3445) else Cyan, contentColor = Color.White)) {
                            Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, null)
                            Text(if (isRecording) "  STOP & SAVE" else "  START RECORDING")
                        }

                    }
                    else -> {
                        Text("SETTINGS", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("No expiry timer • No mandatory access key • Local audio library", color = Color.White)
                        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text("SOCIAL CALL", color = Cyan, fontWeight = FontWeight.Bold)
                                    Text("Experimental Internet-call route for apps that use Android VOICE_COMMUNICATION. Requires TEAMMATES ONLY or BOTH.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                                }
                                Switch(checked = socialCallEnabled, onCheckedChange = { enabled ->
                                    socialCallEnabled = enabled
                                    context.getSharedPreferences(VoiceFolders.PREFS, android.content.Context.MODE_PRIVATE).edit().putBoolean("social_call_enabled", enabled).apply()
                                    status = if (enabled) "Social Call ON — supported Internet-call mode only" else "Social Call OFF"
                                })
                            }
                        }
                        Text("Compatibility note: Social Call checks Android MODE_IN_COMMUNICATION and uses only the VOICE_COMMUNICATION capture preset. It does not identify or guarantee WhatsApp, Messenger or IMO individually. SIM calls (MODE_IN_CALL) are not supported without system/telephony privileges.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                        Text("FLOATING MENU", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Allow display over other apps, then start the small Prime Voice bubble.", color = Muted, fontSize = 12.sp)
                        Button(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                            } else {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(Intent(context, FloatingMenuService::class.java)) else context.startService(Intent(context, FloatingMenuService::class.java))
                                status = "Floating menu started"
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Text("ENABLE / START FLOATING MENU")
                        }
                        OutlinedButton(onClick = {
                            context.stopService(Intent(context, FloatingMenuService::class.java))
                            status = "Floating menu stopped"
                        }) { Text("STOP FLOATING MENU", color = Cyan) }
                        Text(
                            "SHIZUKU",
                            color = if (bridgeConnected) Color(0xFF39D66F) else Color(0xFFFF6B6B),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (bridgeConnected) "● CONNECTED" else "● NOT CONNECTED",
                            color = if (bridgeConnected) Color(0xFF39D66F) else Color(0xFFFF6B6B),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text("Status: $shizukuStatus", color = Color.White, fontSize = 13.sp)
                        Button(onClick = {
                            try {
                                if (!Shizuku.pingBinder()) {
                                    shizukuStatus = "Shizuku service not running. Start Shizuku app and try again."
                                } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                                    shizukuStatus = "Connected • permission granted"
                                    bindDiagnosticBridge()
                                } else {
                                    Shizuku.requestPermission(4106)
                                    shizukuStatus = "Permission request sent. Approve it in Shizuku. The app will continue automatically."
                                }
                            } catch (e: Exception) {
                                shizukuStatus = "Unavailable: ${e.message ?: "check Shizuku setup"}"
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Text("CHECK / REQUEST SHIZUKU")
                        }
                        Text(
                            "BRIDGE STATUS: ${if (bridgeConnected) "CONNECTED" else if (bridgeBindRequested) "CONNECTING" else "DISCONNECTED"}",
                            color = if (bridgeConnected) Color(0xFF39D66F) else if (bridgeBindRequested) Color(0xFFFFC857) else Color(0xFFFF6B6B),
                            fontSize = 11.sp
                        )
                        Text("BRIDGE DIAGNOSTICS: $bridgeDiagnostics", color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                        // ADDITIVE ONLY — CAPTURE TEST section. Existing Settings text below is unchanged.
                        Text("CAPTURE TEST v13 — SEPARATE, v1.9 TEST ONLY", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Tests on this phone whether AudioPolicy.registerAudioPolicy() + createAudioTrackSource() delivers PCM into AudioRecord(MIC). Plays an 880 Hz tone, preset by preset. Existing Floating Player / Soundboard code is not used by this test.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Text("TEST STATUS: $testStatus", color = Color.White, fontSize = 12.sp)
                        Button(onClick = { runCaptureTest() }, enabled = !testRunning, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Text("RUN CAPTURE TEST")
                        }
                        Button(onClick = { stopCaptureTest() }, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) {
                            Text("STOP TEST")
                        }
                        Button(onClick = { refreshTestLog() }, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) {
                            Text("REFRESH LOG")
                        }
                        Button(onClick = { runMicCheck() }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Text("CHECK MIC (10s)")
                        }
                        Button(onClick = { runBaselineCheck() }, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) {
                            Text("BASELINE CHECK (no tone, 10s)")
                        }
                        Text("BASELINE: $baselineStatus", color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                        Text("MIC CHECK: $micCheckResult", color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                        Text("False-positive warning: speaker sound can reach the mic and fake a TONE_DETECTED. Always run BASELINE CHECK first (no tone), use headphones so the speaker is silent, and confirm with another app's recording.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                        Text(testLog.takeLast(3000), color = Color.White, fontSize = 10.sp, lineHeight = 14.sp)
                        Text("Important: the Shizuku AudioPolicy PCM injector is experimental. A successful route registration is not proof that a game or call app receives the clip; verify with a second participant on the target device.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}


@Composable
private fun formatTime(milliseconds: Int): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0) / 1000)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
