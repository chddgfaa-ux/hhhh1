package com.primevoice.app

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Process
import android.util.Log

/**
 * Capture Test UserService — Shizuku-hosted, separate from the existing
 * diagnostics service (ShizukuAudioUserService). v4.
 *
 * It only runs CaptureTestProbe. It does not play soundboard clips, does
 * not touch the Floating Player, and does not change any Voice Pack /
 * Soundboard state.
 *
 * runCaptureTest() starts the probe on a worker thread and returns
 * immediately, so the Binder call never blocks. Read the result with
 * getTestLog().
 *
 * Concurrency rule (v4): exactly ONE worker at a time. A new RUN is
 * refused ("ALREADY_RUNNING") until the previous worker thread has fully
 * finished AND its cleanup is done (probe state back to IDLE). STOP only
 * ASKS the worker to stop — stopTest() returns "STOPPING" while the
 * worker is still finishing and "STOPPED" once it is actually dead.
 * `running = false` alone never means "done".
 */
class CaptureTestUserService : Service() {

    private val probe by lazy { CaptureTestProbe(this) }
    private val workerLock = Any()
    private var worker: Thread? = null

    private val binder = object : ICaptureTestBridge.Stub() {
        override fun runCaptureTest(sampleRate: Int, maxHoldSeconds: Int): String {
            synchronized(workerLock) {
                val w = worker
                if (w != null && w.isAlive) return "ALREADY_RUNNING"
                if (!probe.tryStart()) return "ALREADY_RUNNING"
                worker = Thread {
                    try {
                        probe.run(sampleRate, maxHoldSeconds)
                    } catch (t: Throwable) {
                        Log.e("PrimeVoiceCaptureTest", "probe crashed", t)
                    } finally {
                        synchronized(workerLock) { worker = null }
                    }
                }.apply { name = "PrimeVoiceCaptureTest"; start() }
                return "STARTED"
            }
        }

        override fun getTestLog(): String = probe.log()

        override fun stopTest(): String {
            probe.stop()
            val w: Thread? = synchronized(workerLock) { worker }
            try { w?.join(5000) } catch (_: InterruptedException) {}
            val alive = w?.isAlive == true
            return if (alive) {
                "STOPPING — stop was requested but the worker is still finishing cleanup. Wait a few seconds, then tap REFRESH LOG."
            } else {
                "STOPPED — worker finished. Tone off, AudioTrack released, AudioPolicy unregistered (see the cleanup lines in the log)."
            }
        }

        /** True while a run is active OR still finishing its cleanup. */
        override fun isTestRunning(): Boolean = probe.isRunning()

        /** UID only — not proof of privileged permission. */
        override fun getProcessUid(): Int = Process.myUid()

        override fun destroy() { probe.stop() }
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.i("PrimeVoiceCaptureTest", "Capture Test service bound, uid=${Process.myUid()}")
        return binder
    }

    override fun onDestroy() {
        // Releases the track and unregisters known policies immediately
        // (cleanupOnce). The worker thread then exits on its own; we do
        // not join it here — onDestroy must not block.
        probe.stop()
        super.onDestroy()
    }
}
