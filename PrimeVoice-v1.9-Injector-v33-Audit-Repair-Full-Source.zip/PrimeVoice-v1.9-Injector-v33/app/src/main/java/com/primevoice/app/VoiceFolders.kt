package com.primevoice.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Two voice folders (v10). The folders differ by PLAYBACK LOGIC, not
 * just by name:
 *
 * - MUSIC: a playlist. A clip ending auto-plays the next one; after
 *   the last clip it wraps to the first (Infinite Loop). Shuffle picks
 *   only from Music.
 * - FUN: one-shot. A tapped clip plays once and stops completely — no
 *   Auto Next, no Loop. The user taps a clip to play the next one.
 *
 * Storage: one SharedPreferences file ("prime_voice_library"), one
 * StringSet per folder ("clips_music" / "clips_fun"). A file with the
 * same name in both folders is two different entries, because the sets
 * are separate. The selected folder ("selected_folder") is shared by
 * MainActivity and FloatingMenuService, so the folder open in the app
 * is the folder the floating panel shows and imports into.
 */
enum class VoiceFolder(val key: String, val label: String) {
    MUSIC("music", "Music"),
    FUN("fun", "Fun");

    companion object {
        fun fromKey(key: String?): VoiceFolder = if (key == FUN.key) FUN else MUSIC
    }
}

object VoiceFolders {
    const val PREFS = "prime_voice_library"
    const val KEY_SELECTED = "selected_folder"
    private const val KEY_MIGRATED = "folders_migrated_v10"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun clipsKey(folder: VoiceFolder): String = "clips_" + folder.key

    fun selectedFolder(context: Context): VoiceFolder =
        VoiceFolder.fromKey(prefs(context).getString(KEY_SELECTED, VoiceFolder.MUSIC.key))

    fun setSelectedFolder(context: Context, folder: VoiceFolder) {
        prefs(context).edit().putString(KEY_SELECTED, folder.key).apply()
    }

    private fun orderedKey(folder: VoiceFolder) = clipsKey(folder) + "_ordered_v1"

    fun loadClips(context: Context, folder: VoiceFolder): List<SoundClip> {
        val p = prefs(context)
        val ordered = p.getString(orderedKey(folder), null)
        if (ordered != null) {
            return runCatching {
                val array = JSONArray(ordered)
                buildList {
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        add(SoundClip(item.getString("name"), Uri.parse(item.getString("uri"))))
                    }
                }
            }.getOrDefault(emptyList())
        }
        // Backward-compatible reader for v10-v32 StringSet libraries.
        return p.getStringSet(clipsKey(folder), emptySet()).orEmpty().mapNotNull { raw ->
            val parts = raw.split("|", limit = 2)
            if (parts.size == 2) runCatching { SoundClip(parts[0], Uri.parse(parts[1])) }.getOrNull() else null
        }.sortedBy { it.name.lowercase(java.util.Locale.ROOT) }
    }

    fun saveClips(context: Context, folder: VoiceFolder, items: List<SoundClip>) {
        val array = JSONArray()
        items.forEach { clip ->
            array.put(JSONObject().put("name", clip.name).put("uri", clip.uri.toString()))
        }
        // Keep legacy set updated for downgrade compatibility; JSON is authoritative.
        prefs(context).edit()
            .putString(orderedKey(folder), array.toString())
            .putStringSet(clipsKey(folder), items.map { it.name + "|" + it.uri.toString() }.toSet())
            .apply()
    }

    /**
     * One-time migration: v9 and older stored every clip under the
     * single key "clips". Those clips move into Music — v9's behaviour
     * was playlist + loop, which is Music's rule — so existing users
     * lose nothing. Runs once; afterwards the old key is gone.
     */
    fun migrateIfNeeded(context: Context) {
        val p = prefs(context)
        if (p.getBoolean(KEY_MIGRATED, false)) return
        val old = p.getStringSet("clips", emptySet()).orEmpty()
        val edit = p.edit()
        if (old.isNotEmpty()) {
            val music = p.getStringSet(clipsKey(VoiceFolder.MUSIC), emptySet()).orEmpty().toMutableSet()
            music.addAll(old)
            edit.putStringSet(clipsKey(VoiceFolder.MUSIC), music).remove("clips")
        }
        edit.putBoolean(KEY_MIGRATED, true).apply()
    }
}
