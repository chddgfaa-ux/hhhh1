package com.primevoice.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * In-app MIC capture check for the Capture Test.
 *
 * While the test tone (880 Hz sine) is playing through the injector, this
 * records AudioRecord(MIC) for a few seconds and checks whether the 880 Hz
 * tone is present in what the microphone input received.
 *
 * How it decides:
 *  - RMS / peak level: is anything being captured at all?
 *  - Goertzel magnitude at 880 Hz vs. the average magnitude at nearby
 *    frequencies (660 Hz and 1100 Hz): a real 880 Hz tone stands out
 *    clearly from background noise.
 *  - TONE_DETECTED = tone energy is at least 4x the nearby average AND
 *    the peak level is above the silence floor AND (when a baseline was
 *    measured) the ratio is at least 3x the baseline ratio.
 *
 * LIMITATION (review point 4): sound coming out of the phone speaker can
 * be picked up by the microphone acoustically and produce TONE_DETECTED
 * even with NO digital injection. That is why this check alone NEVER
 * proves injection. Always do the BASELINE CHECK first (same recording,
 * NO tone playing) and compare ratios, use headphones so the speaker is
 * silent, and confirm with a recording from ANOTHER app while the tone
 * plays. See CAPTURE_TEST.md.
 *
 * This file does not change LiveAudioEngine, PcmWavRecorder, the Floating
 * Player, or the Soundboard.
 */
class CaptureTestRecorder {

    data class CaptureCheckResult(
        val toneDetected: Boolean,
        val rms: Double,
        val peak: Int,
        val toneMagnitude: Double,
        val neighbourMagnitude: Double,
        val ratio: Double,
        val message: String
    )

    private val stateLock = Any()
    @Volatile private var running = false
    @Volatile private var activeRecorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null

    fun isRunning(): Boolean = running || worker?.isAlive == true

    /** Request cancellation and stop the active recorder to unblock a blocking read.
     * The worker remains the sole owner responsible for releasing AudioRecord.
     */
    fun stop() {
        val current: Thread?
        synchronized(stateLock) {
            running = false
            current = worker
            runCatching { activeRecorder?.stop() }
        }
        if (current != null && current !== Thread.currentThread()) {
            try { current.join(1500) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }
        synchronized(stateLock) {
            if (worker === current && current?.isAlive != true) worker = null
        }
    }

    /**
     * Records [seconds] of MIC input and calls [onResult] on a worker thread.
     * Caller must hold RECORD_AUDIO permission.
     *
     * @param baselineRatio the 880 Hz ratio measured by a BASELINE CHECK with
     *   NO tone playing (0.0 = no baseline measured). When a baseline exists,
     *   TONE_DETECTED additionally requires the tone ratio to be at least 3x
     *   the baseline ratio, so a tone that was already in the room (or
     *   leaking from the speaker) cannot produce a false positive.
     */
    fun checkMic(
        seconds: Int,
        toneHz: Double = 880.0,
        baselineRatio: Double = 0.0,
        onResult: (CaptureCheckResult) -> Unit
    ) {
        val durationSeconds = seconds.coerceIn(1, 15)
        synchronized(stateLock) {
            if (running || worker?.isAlive == true) return
            running = true // Claim the run BEFORE starting the worker; STOP cannot be overwritten.
            val task = Thread({
                var recorder: AudioRecord? = null
                fun deliver(result: CaptureCheckResult) {
                    runCatching { onResult(result) }
                }
                try {
                    val rate = 44100
                    val minBuffer = AudioRecord.getMinBufferSize(
                        rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                    )
                    if (minBuffer <= 0) {
                        deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Microphone is unavailable"))
                        return@Thread
                    }
                    val createdRecorder = AudioRecord(
                        MediaRecorder.AudioSource.MIC, rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        maxOf(minBuffer, 8192)
                    )
                    recorder = createdRecorder
                    synchronized(stateLock) { activeRecorder = createdRecorder }
                    if (createdRecorder.state != AudioRecord.STATE_INITIALIZED) {
                        deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Could not initialize microphone"))
                        return@Thread
                    }
                    val totalSamples = rate * durationSeconds
                    val captured = ShortArray(totalSamples)
                    var filled = 0
                    createdRecorder.startRecording()
                    val buffer = ShortArray(4096)
                    val endAt = System.currentTimeMillis() + durationSeconds * 1000L
                    while (running && filled < totalSamples && System.currentTimeMillis() < endAt) {
                        val n = createdRecorder.read(buffer, 0, minOf(buffer.size, totalSamples - filled))
                        if (n > 0) {
                            buffer.copyInto(captured, filled, 0, n)
                            filled += n
                        } else if (n < 0) {
                            throw IllegalStateException("AudioRecord.read=$n")
                        }
                    }
                    if (!running) {
                        deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Capture check stopped"))
                        return@Thread
                    }
                    if (filled < rate) {
                        deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Too little audio captured ($filled samples)"))
                        return@Thread
                    }
                    val samples = captured.copyOf(filled)
                    var sumSq = 0.0
                    var peak = 0
                    for (sample in samples) {
                        val value = sample.toDouble()
                        sumSq += value * value
                        if (kotlin.math.abs(sample.toInt()) > peak) peak = kotlin.math.abs(sample.toInt())
                    }
                    val rms = sqrt(sumSq / samples.size)
                    val toneMag = goertzel(samples, rate, toneHz)
                    val neighbourMag = (goertzel(samples, rate, toneHz - 220.0) +
                        goertzel(samples, rate, toneHz + 220.0)) / 2.0
                    val ratio = if (neighbourMag > 0) toneMag / neighbourMag else 0.0
                    val baselineOk = baselineRatio <= 0.0 || ratio >= baselineRatio * 3.0
                    val detected = ratio >= 4.0 && peak > 200 && baselineOk
                    val baselineText = if (baselineRatio > 0.0) " baseline=${"%.1f".format(baselineRatio)}" else " baseline=not measured"
                    val message = if (detected) {
                        "TONE_DETECTED — 880 Hz tone reached AudioRecord(MIC) (ratio ${"%.1f".format(ratio)},$baselineText). " +
                            "This is only an in-app signal — confirm with another app's recording before calling it injection."
                    } else if (baselineRatio >= 4.0) {
                        "BASELINE ALREADY HIGH — 880 Hz was strong even with NO tone (baseline ratio ${"%.1f".format(baselineRatio)}). " +
                            "The room is noisy or the speaker is leaking. Move to a quiet place / use headphones and re-run the baseline."
                    } else if (rms < 50) {
                        "SILENCE — almost nothing captured. Tone did not reach the mic input."
                    } else if (!baselineOk) {
                        "NO_TONE — ratio ${"%.1f".format(ratio)} is not clearly above the baseline ($baselineText). Cannot tell tone apart from what was already there."
                    } else {
                        "NO_TONE — audio was captured but no clear 880 Hz tone (ratio ${"%.1f".format(ratio)},$baselineText). Injection did not deliver the tone."
                    }
                    deliver(CaptureCheckResult(detected, rms, peak, toneMag, neighbourMag, ratio, message))
                } catch (e: SecurityException) {
                    deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Microphone permission is required"))
                } catch (e: Exception) {
                    deliver(CaptureCheckResult(false, 0.0, 0, 0.0, 0.0, 0.0, "Capture check error: ${e.message ?: "unknown"}"))
                } finally {
                    // Always release, including initialization/start/read failures.
                    runCatching { if (recorder?.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder?.stop() }
                    runCatching { recorder?.release() }
                    synchronized(stateLock) {
                        if (activeRecorder === recorder) activeRecorder = null
                        if (worker === Thread.currentThread()) worker = null
                        running = false
                    }
                }
            }, "PrimeVoiceCaptureCheck")
            worker = task
            task.start()
        }
    }

    /** Goertzel magnitude at one frequency for a block of PCM samples. */
    private fun goertzel(samples: ShortArray, rate: Int, freqHz: Double): Double {
        val k = (0.5 + (samples.size.toDouble() * freqHz / rate)).toInt()
        val w = 2.0 * PI * k / samples.size
        val cw = cos(w)
        val coeff = 2.0 * cw
        var s0 = 0.0
        var s1 = 0.0
        var s2 = 0.0
        for (s in samples) {
            s0 = s.toDouble() + coeff * s1 - s2
            s2 = s1
            s1 = s0
        }
        val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
        return sqrt(maxOf(power, 0.0)) / samples.size
    }
}
