package com.primevoice.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.AudioRouting
import android.os.Build
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.net.Uri
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/** Decodes a selected audio URI to mono PCM16 and streams it through the Shizuku pipe. */
class PcmClipStreamer(
    private val context: Context,
    private val bridge: IShizukuAudioBridge,
    private val onStatus: (String) -> Unit,
    private val onFinished: () -> Unit,
    private val onProgress: (positionMs: Int, durationMs: Int) -> Unit = { _, _ -> },
    private val monitorOnBluetooth: Boolean = false,
    private val socialCallMode: Boolean = false
) {
    private val stopped = AtomicBoolean(false)
    private val paused = AtomicBoolean(false)
    private val pendingSeekMs = AtomicLong(-1L)
    @Volatile private var bluetoothTrack: AudioTrack? = null
    @Volatile private var durationMs: Int = 0
    @Volatile private var worker: Thread? = null
    @Volatile private var writeEnd: ParcelFileDescriptor? = null
    @Volatile private var selectedBluetoothDeviceId: Int = -1
    @Volatile private var audioManagerForRouting: AudioManager? = null
    @Volatile private var deviceCallback: android.media.AudioDeviceCallback? = null
    @Volatile private var routingListener: AudioRouting.OnRoutingChangedListener? = null
    private val bluetoothRouteLost = AtomicBoolean(false)
    // Listener is armed before route negotiation; it only becomes fail-closed
    // after the selected A2DP device has been positively observed.
    private val bluetoothRouteConfirmed = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val controlLock = Any()
    // A periodic route check complements AudioRouting callbacks. Some OEM audio
    // stacks do not deliver every route transition callback while a track is paused.
    private val bluetoothRouteWatchdog = object : Runnable {
        override fun run() {
            if (!monitorOnBluetooth || stopped.get() || !bluetoothRouteConfirmed.get()) return
            val track = bluetoothTrack
            if (track == null) {
                failBluetoothRoute("Bluetooth monitor track disappeared; BOTH playback stopped")
                return
            }
            try {
                validateBluetoothRoute(track)
                val manager = audioManagerForRouting
                    ?: throw IllegalStateException("Bluetooth route monitor unavailable")
                val stillPresent = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
                    it.id == selectedBluetoothDeviceId && it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                }
                if (!stillPresent) throw IllegalStateException("Selected A2DP device is no longer connected")
                mainHandler.postDelayed(this, 250L)
            } catch (t: Throwable) {
                failBluetoothRoute("Bluetooth route watchdog: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }
    private val remoteRouteActive = AtomicBoolean(false)

    @Synchronized
    fun start(uri: Uri) {
        if (socialCallMode) {
            val socialEnabled = context.getSharedPreferences(VoiceFolders.PREFS, Context.MODE_PRIVATE)
                .getBoolean("social_call_enabled", false)
            if (!socialEnabled) {
                onStatus("Social Call is OFF. Enable it before starting a call clip.")
                onFinished()
                return
            }
            val mode = (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
            if (mode != AudioManager.MODE_IN_COMMUNICATION) {
                onStatus("Injection failed: Social Call is ON, but Android does not report an active Internet-call communication mode")
                onFinished()
                return
            }
        }
        // Prevent two rapid UI taps from creating parallel decoders and two
        // independent AudioPolicy/PCM sessions on the same bridge.
        if (worker?.isAlive == true) return
        stopped.set(false)
        worker = thread(name = "PrimeVoicePcmDecode") {
            var extractor: MediaExtractor? = null
            var codec: MediaCodec? = null
            var readEnd: ParcelFileDescriptor? = null
            var monitorTrack: AudioTrack? = null
            var out: FileOutputStream? = null
            try {
                extractor = MediaExtractor()
                extractor.setDataSource(context, uri, null)
                var audioTrack = -1
                var inputFormat: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                        audioTrack = i; inputFormat = f; break
                    }
                }
                require(audioTrack >= 0 && inputFormat != null) { "No audio track" }
                extractor.selectTrack(audioTrack)
                durationMs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION))
                    (inputFormat.getLong(MediaFormat.KEY_DURATION) / 1000L).coerceIn(0L, Int.MAX_VALUE.toLong()).toInt() else 0
                val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(inputFormat, null, null, 0)
                codec.start()
                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var pipeReady = false
                var binderFallback = false
                var routeReady = false
                var outputRate = 48000
                var channels = 1
                var pcmEncoding = 2
                var lastPipeHealthCheckMs = 0L
                while (!outputDone && !stopped.get()) {
                    if (socialCallMode) {
                        val callMode = (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
                        val socialEnabled = context.getSharedPreferences(VoiceFolders.PREFS, Context.MODE_PRIVATE)
                            .getBoolean("social_call_enabled", false)
                        if (!socialEnabled) {
                            throw IllegalStateException("Social Call was switched OFF; playback stopped")
                        }
                        if (callMode != AudioManager.MODE_IN_COMMUNICATION) {
                            throw IllegalStateException("Social Call route stopped: Android is no longer in MODE_IN_COMMUNICATION")
                        }
                    }
                    if (routeReady && pipeReady) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastPipeHealthCheckMs >= 500L) {
                            val pipeStatus = bridge.getPipeStatus()
                            if (pipeStatus != "PIPE_ACTIVE") {
                                throw IllegalStateException("Shizuku PCM pipe health check failed: $pipeStatus")
                            }
                            lastPipeHealthCheckMs = now
                        }
                    }
                    // Seeking is performed on the decoder thread so MediaExtractor,
                    // MediaCodec and the PCM pipe are never manipulated concurrently.
                    val seekTarget = pendingSeekMs.getAndSet(-1L)
                    if (seekTarget >= 0L) {
                        // Flush both destinations. Recreate the Shizuku pipe so stale
                        // queued PCM cannot leak past the new seek position.
                        if (monitorOnBluetooth) {
                            val bt = monitorTrack ?: throw IllegalStateException("Bluetooth monitor disappeared during seek")
                            // Mute before flushing/restarting: never expose a transient default-speaker route.
                            bt.setVolume(0f)
                            runCatching { bt.pause(); bt.flush() }.getOrElse { throw IllegalStateException("Bluetooth flush failed during seek", it) }
                            // Play silently during route confirmation even if user playback is paused.
                            bt.play()
                            awaitBluetoothRoute(bt)
                            validateBluetoothRoute(bt)
                            if (paused.get()) bt.pause() else bt.setVolume(1f)
                        }
                        runCatching { out?.flush(); out?.close() }; out = null
                        runCatching { writeEnd?.close() }; writeEnd = null
                        runCatching { readEnd?.close() }; readEnd = null
                        synchronized(controlLock) {
                            if (stopped.get()) throw InterruptedException("Playback stopped before seek route restart")
                            runCatching { bridge.stopInputRouteSession() }
                            remoteRouteActive.set(false)
                            val route = if (socialCallMode) bridge.startSocialCallRouteSession(outputRate) else bridge.startInputRouteSession(outputRate)
                            if (!route.startsWith("ROUTE_READY")) throw IllegalStateException("Seek route restart failed: $route")
                            remoteRouteActive.set(true)
                            if (stopped.get()) throw InterruptedException("Playback stopped during seek route restart")
                            if (paused.get()) {
                                val pauseResult = bridge.setInputRoutePaused(true)
                                if (pauseResult != "ROUTE_PAUSED") throw IllegalStateException("Could not preserve pause after seek: $pauseResult")
                            }
                        }
                        val pipe = runCatching { ParcelFileDescriptor.createPipe() }.getOrNull()
                        if (pipe != null) {
                            readEnd = pipe[0]; writeEnd = pipe[1]
                            val pipeResult = runCatching { bridge.startPcmPipeSession(readEnd!!) }.getOrElse { "PIPE_BINDER_ERROR:${it.message}" }
                            runCatching { readEnd?.close() }; readEnd = null
                            if (pipeResult == "PIPE_STARTED") {
                                out = FileOutputStream(writeEnd!!.fileDescriptor)
                                binderFallback = false
                            } else {
                                runCatching { writeEnd?.close() }; writeEnd = null
                                val fallback = runCatching { bridge.startBinderPcmSession() }.getOrElse { "BINDER_ERROR:${it.message}" }
                                if (fallback != "BINDER_PCM_READY") throw IllegalStateException("Seek pipe and Binder fallback failed: $pipeResult / $fallback")
                                binderFallback = true
                            }
                        } else {
                            val fallback = runCatching { bridge.startBinderPcmSession() }.getOrElse { "BINDER_ERROR:${it.message}" }
                            if (fallback != "BINDER_PCM_READY") throw IllegalStateException("Seek pipe creation and Binder fallback failed: $fallback")
                            binderFallback = true
                        }
                        extractor.seekTo(seekTarget * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                        codec.flush()
                        inputDone = false
                        outputDone = false
                        onProgress(seekTarget.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(), durationMs)
                    }
                    if (!inputDone) {
                        val inIndex = codec.dequeueInputBuffer(10000)
                        if (inIndex >= 0) {
                            val buffer = codec.getInputBuffer(inIndex)!!
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIndex = codec.dequeueOutputBuffer(info, 10000)
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val f = codec.outputFormat
                        outputRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmEncoding = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) f.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                        if (pcmEncoding != 2) throw IllegalStateException("Decoder PCM encoding $pcmEncoding is not PCM16")
                        if (!routeReady) {
                            if (monitorOnBluetooth) {
                                monitorTrack = createBluetoothMonitor(outputRate)
                                bluetoothTrack = monitorTrack
                                // Keep the track muted while Android negotiates the route.
                                // This prevents an audible speaker burst before A2DP is confirmed.
                                monitorTrack!!.setVolume(0f)
                                monitorTrack!!.play()
                                awaitBluetoothRoute(monitorTrack!!)
                                validateBluetoothRoute(monitorTrack!!)
                                if (paused.get()) monitorTrack!!.pause() else monitorTrack!!.setVolume(1f)
                            }
                            synchronized(controlLock) {
                                if (stopped.get()) throw InterruptedException("Playback stopped before injector start")
                                val route = if (socialCallMode) bridge.startSocialCallRouteSession(outputRate) else bridge.startInputRouteSession(outputRate)
                                if (!route.startsWith("ROUTE_READY")) throw IllegalStateException(route)
                                remoteRouteActive.set(true)
                                if (stopped.get()) throw InterruptedException("Playback stopped during injector start")
                                if (paused.get()) {
                                    val pauseResult = bridge.setInputRoutePaused(true)
                                    if (pauseResult != "ROUTE_PAUSED") throw IllegalStateException("Could not pause new route: $pauseResult")
                                }
                            }
                            val pipe = runCatching { ParcelFileDescriptor.createPipe() }.getOrNull()
                            if (pipe != null) {
                                readEnd = pipe[0]; writeEnd = pipe[1]
                                val pipeResult = runCatching { bridge.startPcmPipeSession(readEnd!!) }.getOrElse { "PIPE_BINDER_ERROR:${it.message}" }
                                runCatching { readEnd?.close() }; readEnd = null
                                if (pipeResult == "PIPE_STARTED") {
                                    out = FileOutputStream(writeEnd!!.fileDescriptor)
                                    binderFallback = false
                                } else {
                                    runCatching { writeEnd?.close() }; writeEnd = null
                                    val fallback = runCatching { bridge.startBinderPcmSession() }.getOrElse { "BINDER_ERROR:${it.message}" }
                                    if (fallback != "BINDER_PCM_READY") throw IllegalStateException("Pipe and Binder fallback failed: $pipeResult / $fallback")
                                    binderFallback = true
                                }
                            } else {
                                val fallback = runCatching { bridge.startBinderPcmSession() }.getOrElse { "BINDER_ERROR:${it.message}" }
                                if (fallback != "BINDER_PCM_READY") throw IllegalStateException("Pipe creation and Binder fallback failed: $fallback")
                                binderFallback = true
                            }
                            pipeReady = true
                            routeReady = true
                        }
                        onStatus(if (socialCallMode) "SOCIAL CALL • VOICE_COMMUNICATION route • ${outputRate}Hz" else if (monitorOnBluetooth) "BOTH • Bluetooth + Virtual Mic • ${outputRate}Hz" else "TEAMMATES ONLY • PCM route active • ${outputRate}Hz")
                    } else if (outIndex >= 0) {
                        val buffer = codec.getOutputBuffer(outIndex)
                        if (buffer != null && info.size > 0) {
                            if (!pipeReady) throw IllegalStateException("Decoder produced PCM before output format")
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size); buffer.get(bytes)
                            val mono = toMonoPcm16(bytes, channels)
                            while (paused.get() && !stopped.get() && pendingSeekMs.get() < 0L) Thread.sleep(25)
                            if (!stopped.get() && pendingSeekMs.get() < 0L) {
                                // One lock covers both destinations: Pause/Resume cannot split a
                                // PCM frame between Bluetooth and the Shizuku injector.
                                if (writeFrameToOutputs(mono, out, monitorTrack, binderFallback)) {
                                    val posMs = (info.presentationTimeUs / 1000L).coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
                                    onProgress(posMs, durationMs)
                                }
                            }
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        codec.releaseOutputBuffer(outIndex, false)
                    }
                }
                runCatching { out?.flush() }
                onStatus(if (stopped.get()) "Playback stopped" else "Clip finished")
            } catch (t: Throwable) {
                onStatus("Injection failed: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                runCatching { readEnd?.close() }
                runCatching { writeEnd?.close() }; writeEnd = null
                remoteRouteActive.set(false)
                runCatching { bridge.stopInputRouteSession() }
                cleanupBluetoothRouting(monitorTrack)
                runCatching { monitorTrack?.pause() }; runCatching { monitorTrack?.flush() }; runCatching { monitorTrack?.stop() }; runCatching { monitorTrack?.release() }
                bluetoothTrack = null
                runCatching { codec?.stop() }; runCatching { codec?.release() }
                runCatching { extractor?.release() }
                onFinished()
            }
        }
    }



    /** Wait briefly for Android to confirm that the preferred A2DP route is active. */
    private fun awaitBluetoothRoute(track: AudioTrack) {
        // Register first to close the gap where the route could change between
        // the first successful routedDevice read and listener registration.
        watchBluetoothRoute(track)
        val deadline = SystemClock.elapsedRealtime() + 5000L
        while (SystemClock.elapsedRealtime() < deadline) {
            val routed = track.routedDevice
            if (routed?.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP && routed.id == selectedBluetoothDeviceId) {
                bluetoothRouteConfirmed.set(true)
                validateBluetoothRoute(track)
                mainHandler.removeCallbacks(bluetoothRouteWatchdog)
                mainHandler.postDelayed(bluetoothRouteWatchdog, 250L)
                return
            }
            if (stopped.get()) throw IllegalStateException("Playback stopped")
            SystemClock.sleep(50L)
        }
        throw IllegalStateException("Bluetooth A2DP route did not become active; phone speaker fallback is disabled")
    }

    private fun validateBluetoothRoute(track: AudioTrack) {
        val routed = track.routedDevice
        if (bluetoothRouteLost.get() || routed == null ||
            routed.type != AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            routed.id != selectedBluetoothDeviceId) {
            throw IllegalStateException("Bluetooth route is not the selected A2DP headset; both outputs stopped")
        }
    }

    private fun awaitPlaybackGate() {
        while (paused.get() && !stopped.get() && pendingSeekMs.get() < 0L) Thread.sleep(15L)
        if (stopped.get()) throw InterruptedException("Playback stopped")
    }

    /** Serialize a PCM frame to both sinks against Pause/Resume and Seek controls. */
    private fun writeFrameToOutputs(pcm: ByteArray, remoteOut: FileOutputStream?, btTrack: AudioTrack?, binderFallback: Boolean): Boolean {
        while (true) {
            awaitPlaybackGate()
            val result = synchronized(controlLock) {
                if (stopped.get()) throw InterruptedException("Playback stopped")
                when {
                    pendingSeekMs.get() >= 0L -> -1
                    paused.get() -> 0
                    else -> {
                        if (monitorOnBluetooth) {
                            val bt = btTrack ?: throw IllegalStateException("Bluetooth monitor is unavailable")
                            validateBluetoothRoute(bt)
                            writeBluetoothPcmLocked(bt, pcm)
                        }
                        if (stopped.get()) throw InterruptedException("Playback stopped")
                        if (pendingSeekMs.get() >= 0L) -1 else {
                            if (binderFallback) {
                                val written = bridge.writeInputPcm(pcm)
                                if (written != pcm.size) throw IllegalStateException("Binder PCM write failed: $written/${pcm.size}")
                            } else {
                                (remoteOut ?: throw IllegalStateException("PCM pipe output is unavailable")).write(pcm)
                            }
                            1
                        }
                    }
                }
            }
            when (result) {
                1 -> return true
                0 -> continue // Pause won the race; wait outside the lock for Resume.
                else -> return false // Seek requested; discard this frame and let decoder flush.
            }
        }
    }

    /** Non-blocking, cancellable Bluetooth writes. Caller holds controlLock. */
    private fun writeBluetoothPcmLocked(track: AudioTrack, pcm: ByteArray) {
        var offset = 0
        val writeStartedAt = SystemClock.elapsedRealtime()
        while (offset < pcm.size) {
            if (stopped.get()) throw InterruptedException("Playback stopped during Bluetooth write")
            if (pendingSeekMs.get() >= 0L) return
            validateBluetoothRoute(track)
            val written = track.write(pcm, offset, pcm.size - offset, AudioTrack.WRITE_NON_BLOCKING)
            if (written < 0) throw IllegalStateException("Bluetooth AudioTrack.write=$written")
            if (written == 0) {
                // A stalled A2DP sink must not hold the dual-output control lock
                // forever. Fail closed instead of freezing Pause/Stop indefinitely.
                if (SystemClock.elapsedRealtime() - writeStartedAt > 750L) {
                    throw IllegalStateException("Bluetooth AudioTrack write stalled for 750 ms")
                }
                SystemClock.sleep(2L)
            } else offset += written
        }
    }

    /** Create a media AudioTrack explicitly pinned to a connected Bluetooth A2DP output. */
    private fun createBluetoothMonitor(sampleRate: Int): AudioTrack {
        require(Build.VERSION.SDK_INT >= 23) { "Bluetooth output routing requires Android 6.0 or newer" }
        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            throw SecurityException("Bluetooth permission missing. Open Prime Voice and allow Nearby devices / Bluetooth access.")
        }
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val device = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
            ?: throw IllegalStateException("No connected Bluetooth A2DP headset found")
        selectedBluetoothDeviceId = device.id
        bluetoothRouteLost.set(false)
        bluetoothRouteConfirmed.set(false)
        audioManagerForRouting = manager
        val callback = object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
                if (removedDevices.any { it.id == selectedBluetoothDeviceId }) {
                    failBluetoothRoute("Bluetooth headset disconnected; BOTH playback stopped")
                }
            }
        }
        deviceCallback = callback
        manager.registerAudioDeviceCallback(callback, mainHandler)
        val channelMask = AudioFormat.CHANNEL_OUT_MONO
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuffer > 0) { "Bluetooth AudioTrack buffer unsupported: $minBuffer" }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(channelMask)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build())
            .setBufferSizeInBytes((minBuffer * 2).coerceAtLeast(sampleRate / 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            cleanupBluetoothRouting(null)
            throw IllegalStateException("Bluetooth AudioTrack initialization failed")
        }
        if (!track.setPreferredDevice(device)) {
            track.release()
            cleanupBluetoothRouting(null)
            throw IllegalStateException("Android refused Bluetooth A2DP output selection")
        }
        return track
    }

    /** After initial route confirmation, fail closed on any subsequent route change. */
    private fun watchBluetoothRoute(track: AudioTrack) {
        routingListener?.let { old -> runCatching { track.removeOnRoutingChangedListener(old) } }
        val listener = AudioRouting.OnRoutingChangedListener { routing ->
            val routed = routing.routedDevice
            // During initial negotiation a null/non-A2DP route is expected.
            // Once A2DP is confirmed, any deviation is a hard failure.
            if (bluetoothRouteConfirmed.get() &&
                (routed == null || routed.type != AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    routed.id != selectedBluetoothDeviceId)) {
                failBluetoothRoute("Bluetooth output route changed; BOTH playback stopped")
            }
        }
        routingListener = listener
        track.addOnRoutingChangedListener(listener, mainHandler)
    }

    private fun failBluetoothRoute(message: String) {
        if (!bluetoothRouteLost.compareAndSet(false, true)) return
        onStatus("Injection failed: $message")
        // Stop both destinations; never redirect local monitoring to the speaker.
        stopped.set(true)
        runCatching { bluetoothTrack?.setVolume(0f) }
        runCatching { bluetoothTrack?.pause() }
        runCatching { bluetoothTrack?.flush() }
        runCatching { writeEnd?.close() }
        remoteRouteActive.set(false)
        // The decoder worker's finally block is the single owner of remote
        // AudioPolicy teardown. Avoid racing a Binder stop against seek/start.
        worker?.interrupt()
    }

    private fun cleanupBluetoothRouting(track: AudioTrack?) {
        mainHandler.removeCallbacks(bluetoothRouteWatchdog)
        val listener = routingListener
        if (listener != null && track != null) runCatching { track.removeOnRoutingChangedListener(listener) }
        routingListener = null
        val manager = audioManagerForRouting
        val callback = deviceCallback
        if (manager != null && callback != null) runCatching { manager.unregisterAudioDeviceCallback(callback) }
        deviceCallback = null
        audioManagerForRouting = null
        selectedBluetoothDeviceId = -1
        bluetoothRouteConfirmed.set(false)
    }

    private fun toMonoPcm16(bytes: ByteArray, channels: Int): ByteArray {
        if (channels <= 1) return bytes
        val input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val frames = bytes.size / (2 * channels)
        val output = ByteBuffer.allocate(frames * 2).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) {
            var sum = 0
            repeat(channels) { sum += input.short.toInt() }
            output.putShort((sum / channels).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort())
        }
        return output.array()
    }

    /** Request a decoder-thread seek. The active Shizuku route remains open. */
    fun seekTo(positionMs: Int) = synchronized(controlLock) {
        if (stopped.get() || worker?.isAlive != true) return@synchronized
        val upperBound = if (durationMs > 0) durationMs else Int.MAX_VALUE
        pendingSeekMs.set(positionMs.coerceIn(0, upperBound).toLong())
    }

    fun togglePause(): Boolean = synchronized(controlLock) {
        if (stopped.get()) return@synchronized paused.get()
        val targetPaused = !paused.get()
        val track = bluetoothTrack
        try {
            if (targetPaused) {
                track?.pause()
                if (remoteRouteActive.get()) {
                    val result = bridge.setInputRoutePaused(true)
                    if (result != "ROUTE_PAUSED") throw IllegalStateException("Shizuku pause failed: $result")
                }
            } else {
                if (monitorOnBluetooth && track != null) validateBluetoothRoute(track)
                if (remoteRouteActive.get()) {
                    val result = bridge.setInputRoutePaused(false)
                    if (result != "ROUTE_RESUMED") throw IllegalStateException("Shizuku resume failed: $result")
                }
                if (!stopped.get()) {
                    if (monitorOnBluetooth) track?.setVolume(1f)
                    track?.play()
                }
            }
            if (stopped.get()) throw InterruptedException("Playback stopped during pause/resume")
            paused.set(targetPaused)
            targetPaused
        } catch (t: Throwable) {
            failBluetoothRoute("Dual-output pause/resume failed: ${t.message ?: t.javaClass.simpleName}")
            paused.get()
        }
    }

    /** Keep potentially blocking remote Binder pause/resume calls off the UI thread. */
    fun togglePauseAsync(onResult: (Boolean) -> Unit) {
        thread(name = "PrimeVoicePauseResume", isDaemon = true) {
            val result = runCatching { togglePause() }.getOrDefault(paused.get())
            mainHandler.post { onResult(result) }
        }
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        runCatching { bluetoothTrack?.setVolume(0f) }
        runCatching { bluetoothTrack?.pause() }
        runCatching { bluetoothTrack?.flush() }
        runCatching { writeEnd?.close() }
        remoteRouteActive.set(false)
        // Remote teardown is centralized in the worker's finally block so it
        // cannot race an in-flight route start/rebuild Binder transaction.
        worker?.interrupt()
    }
}
