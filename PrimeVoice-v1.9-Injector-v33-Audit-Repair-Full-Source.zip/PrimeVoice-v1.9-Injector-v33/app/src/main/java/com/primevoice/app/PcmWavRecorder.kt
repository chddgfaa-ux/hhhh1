package com.primevoice.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.roundToInt

/**
 * Records mono 16-bit PCM into a standard WAV file so recordings can be
 * processed locally without a cloud service.
 */
class PcmWavRecorder(private val output: File, private val sampleRate: Int = 44100) {
    @Volatile private var running = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    @Volatile private var failure: String? = null

    @Synchronized fun start() {
        check(worker?.isAlive != true) { "Recorder is already running" }
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        require(minBuffer > 0) { "Microphone is unavailable (AudioRecord=$minBuffer)" }
        val bufferBytes = maxOf(minBuffer, 8192)
        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes
        )
        check(audioRecord.state == AudioRecord.STATE_INITIALIZED) { audioRecord.release(); "Could not initialize microphone" }
        recorder = audioRecord
        RandomAccessFile(output, "rw").use { file -> file.setLength(0); file.write(ByteArray(44)) }
        failure = null
        audioRecord.startRecording()
        running = true
        worker = Thread {
            try {
                RandomAccessFile(output, "rw").use { file ->
                    file.seek(44)
                    val buffer = ShortArray(bufferBytes / 2)
                    while (running) {
                        val count = audioRecord.read(buffer, 0, buffer.size)
                        when {
                            count > 0 -> {
                                val bytes = ByteArray(count * 2)
                                for (i in 0 until count) {
                                    val value = buffer[i].toInt()
                                    bytes[i * 2] = (value and 0xff).toByte()
                                    bytes[i * 2 + 1] = ((value shr 8) and 0xff).toByte()
                                }
                                file.write(bytes)
                            }
                            count == 0 -> {
                                if (running) Thread.sleep(8)
                            }
                            count < 0 -> {
                                if (running) failure = "AudioRecord.read error=$count"
                                break
                            }
                        }
                    }
                    val dataSize = (file.length() - 44).coerceAtLeast(0).coerceAtMost(Int.MAX_VALUE.toLong() - 36L).toInt()
                    writeWavHeader(file, dataSize, sampleRate)
                }
            } catch (t: Throwable) {
                if (running) failure = t.message ?: "Recording failed"
            } finally {
                running = false
                runCatching { audioRecord.stop() }
                runCatching { audioRecord.release() }
                if (recorder === audioRecord) recorder = null
            }
        }.apply { name = "PrimeVoiceRecorder"; start() }
    }

    @Synchronized fun stop(): String? {
        running = false
        val active = recorder
        try { active?.stop() } catch (_: Exception) {}
        val thread = worker
        try { thread?.join(3000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        if (thread?.isAlive == true) return "Recorder is still stopping; try again shortly"
        worker = null
        recorder = null
        return failure
    }

    private fun writeWavHeader(file: RandomAccessFile, dataSize: Int, rate: Int) {
        file.seek(0)
        file.writeBytes("RIFF")
        writeIntLE(file, dataSize + 36)
        file.writeBytes("WAVE")
        file.writeBytes("fmt ")
        writeIntLE(file, 16)
        writeShortLE(file, 1)
        writeShortLE(file, 1)
        writeIntLE(file, rate)
        writeIntLE(file, rate * 2)
        writeShortLE(file, 2)
        writeShortLE(file, 16)
        file.writeBytes("data")
        writeIntLE(file, dataSize)
    }

    private fun writeIntLE(file: RandomAccessFile, value: Int) {
        file.write(value and 0xff); file.write((value shr 8) and 0xff)
        file.write((value shr 16) and 0xff); file.write((value shr 24) and 0xff)
    }
    private fun writeShortLE(file: RandomAccessFile, value: Int) {
        file.write(value and 0xff); file.write((value shr 8) and 0xff)
    }
}
