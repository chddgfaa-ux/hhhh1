package com.primevoice.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.Process
import android.util.Log
import android.media.AudioFormat
import java.io.FileInputStream
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Shizuku-side AudioPolicy injector. This is an experimental, device-dependent
 * implementation modeled on the Prime Zerox static report and the v13 capture
 * probe. A successful policy registration is NOT proof that Free Fire receives
 * the PCM; that still requires the user's external teammate test.
 */
class ShizukuAudioUserService : Service() {
    private val lock = Any()
    @Volatile private var policy: Any? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var pipeThread: Thread? = null
    @Volatile private var pipeInput: ParcelFileDescriptor? = null
    @Volatile private var active = false
    private val stopping = AtomicBoolean(false)
    @Volatile private var pipeFailure: String? = null
    @Volatile private var binderPcmMode: Boolean = false
    @Volatile private var socialCallOnlyActive: Boolean = false
    private val logs = StringBuilder()

    private fun log(s: String) = synchronized(logs) {
        if (logs.length > 12000) logs.delete(0, logs.length - 9000)
        logs.append(System.currentTimeMillis()).append(" ").append(s).append('\n')
        Log.i("PrimeVoiceInjector", s)
    }

    private val binder = object : IShizukuAudioBridge.Stub() {
        override fun getProcessUid(): Int = Process.myUid()
        override fun getDiagnostics(): String {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            return "uid=${Process.myUid()}; sdk=${Build.VERSION.SDK_INT}; AudioPolicy=${has("android.media.AudioPolicy")}; AudioMix=${has("android.media.AudioMix")}; AudioMixingRule=${has("android.media.audiopolicy.AudioMixingRule")}; outputs=${runCatching { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).size }.getOrDefault(-1)}; audioMode=${runCatching { am.mode }.getOrDefault(-1)}; socialCallOnly=$socialCallOnlyActive; injectorActive=$active; pipeAlive=${pipeThread?.isAlive == true}; pipeFailure=${pipeFailure ?: "none"}"
        }
        override fun startInputRouteSession(sampleRate: Int): String {
            if (sampleRate !in 8000..96000) return "INVALID_SAMPLE_RATE:$sampleRate"
            return startRoute(sampleRate, socialCallOnly = false)
        }
        override fun startSocialCallRouteSession(sampleRate: Int): String {
            if (sampleRate !in 8000..96000) return "INVALID_SAMPLE_RATE:$sampleRate"
            return startRoute(sampleRate, socialCallOnly = true)
        }
        override fun startPcmPipeSession(readEnd: ParcelFileDescriptor): String = startPipe(readEnd)
        override fun startBinderPcmSession(): String = synchronized(lock) {
            if (!active || track == null) return "ROUTE_NOT_ACTIVE"
            if (pipeThread?.isAlive == true) return "PIPE_ALREADY_RUNNING"
            binderPcmMode = true
            pipeFailure = null
            "BINDER_PCM_READY"
        }
        override fun writeInputPcm(pcm: ByteArray): Int = synchronized(lock) {
            // PCM format is signed 16-bit mono: reject malformed or oversized
            // Binder payloads before touching AudioTrack. Normal chunks are small.
            if (pcm.isEmpty() || pcm.size > 65536 || pcm.size % 2 != 0) {
                pipeFailure = "INVALID_PCM_CHUNK:${pcm.size}"
                return -7
            }
            if (!active || !binderPcmMode) return -1
            if (socialCallOnlyActive && !isInternetCommunicationMode()) {
                pipeFailure = "SOCIAL_CALL_MODE_ENDED"
                return -2
            }
            val current = track ?: return -3
            var offset = 0
            val started = android.os.SystemClock.elapsedRealtime()
            while (offset < pcm.size && !stopping.get()) {
                if (socialCallOnlyActive && !isInternetCommunicationMode()) return -2
                val n = current.write(pcm, offset, pcm.size - offset, AudioTrack.WRITE_NON_BLOCKING)
                if (n < 0) { pipeFailure = "AudioTrack.write=$n"; return n }
                if (n == 0) {
                    if (android.os.SystemClock.elapsedRealtime() - started > 750L) {
                        pipeFailure = "Binder PCM AudioTrack write stalled for 750 ms"
                        return -4
                    }
                    try { Thread.sleep(2) } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt(); return -5
                    }
                } else offset += n
            }
            if (stopping.get()) -6 else offset
        }
        override fun setInputRoutePaused(paused: Boolean): String = setRoutePaused(paused)
        override fun stopInputRouteSession() { stopRoute() }
        override fun destroy() { stopRoute() }
        override fun getLog(): String = synchronized(logs) { logs.toString() }
        override fun getPipeStatus(): String = synchronized(lock) {
            // Enforce the Social Call gate again in the privileged process. The
            // app-side check alone is not trusted because mode can change between
            // the UI check and AudioPolicy/pipe creation.
            if (socialCallOnlyActive && !isInternetCommunicationMode()) {
                pipeFailure = "SOCIAL_CALL_MODE_ENDED"
                stopping.set(true)
                runCatching { pipeInput?.close() }
                pipeInput = null
                return@synchronized "SOCIAL_CALL_MODE_ENDED"
            }
            when {
                pipeFailure != null -> "PIPE_FAILED:${pipeFailure}"
                !active -> "ROUTE_INACTIVE"
                binderPcmMode -> "PIPE_ACTIVE"
                pipeThread?.isAlive != true -> "PIPE_NOT_RUNNING"
                else -> "PIPE_ACTIVE"
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        log("ShizukuAudioUserService created uid=${Process.myUid()} pid=${Process.myPid()} sdk=${Build.VERSION.SDK_INT}")
    }

    override fun onBind(intent: Intent?): IBinder {
        log("ShizukuAudioUserService bound uid=${Process.myUid()}")
        return binder
    }

    private fun has(name: String) = runCatching { Class.forName(name) }.isSuccess

    private fun isInternetCommunicationMode(): Boolean = runCatching {
        (getSystemService(AUDIO_SERVICE) as AudioManager).mode == AudioManager.MODE_IN_COMMUNICATION
    }.getOrDefault(false)

    private fun startRoute(rate: Int, socialCallOnly: Boolean): String = synchronized(lock) {
        if (Build.VERSION.SDK_INT < 33) return "UNSUPPORTED_ANDROID_VERSION:${Build.VERSION.SDK_INT}; requires API 33+"
        if (socialCallOnly && !isInternetCommunicationMode()) {
            log("SOCIAL_CALL_REJECTED: Android mode is not MODE_IN_COMMUNICATION")
            return "SOCIAL_CALL_NOT_ACTIVE:MODE_IN_COMMUNICATION_REQUIRED"
        }
        if (active && policy != null && track != null && pipeThread?.isAlive != true && !stopping.get()) {
            return "ROUTE_ALREADY_ACTIVE"
        }
        if (!stopRouteLocked()) return "ROUTE_STOP_TIMEOUT: previous PCM writer is still alive"
        socialCallOnlyActive = false
        if (Process.myUid() != 2000) log("WARNING: expected Shizuku shell UID 2000, got ${Process.myUid()}")
        runCatching {
            // HiddenApiBypass is required for Android hidden AudioPolicy APIs.
            val bypass = Class.forName("org.lsposed.hiddenapibypass.HiddenApiBypass")
            bypass.getMethod("addHiddenApiExemptions", Array<String>::class.java)
                .invoke(null, arrayOf("Landroid/media/", "Landroid/media/audiopolicy/"))
        }.onFailure { log("Hidden API exemption failed: ${it.message}") }

        val rates = listOf(rate, 48000, 44100, 16000).distinct()
        // Social-call profile is deliberately restricted to VOICE_COMMUNICATION (7).
        // It must never silently fall back to MIC / CAMCORDER / VOICE_CALL presets.
        val presets = if (socialCallOnly) listOf(7) else listOf(7, 1, 5, 6, 4)
        var lastError = "no candidate succeeded"
        for (preset in presets) {
            for (candidateRate in rates) {
                var candidatePolicy: Any? = null
                var candidateTrack: AudioTrack? = null
                var policyRegistered = false
                try {
                    val stack = buildPolicyStack(preset, candidateRate)
                    candidatePolicy = stack.first
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    val register = findMethod(AudioManager::class.java, "registerAudioPolicy", candidatePolicy.javaClass)
                    val result = register.invoke(am, candidatePolicy) as Int
                    log("registerAudioPolicy preset=$preset rate=$candidateRate result=$result")
                    if (result != 0) { lastError = "register returned $result"; continue }
                    policyRegistered = true
                    val createTrack = findMethod(candidatePolicy.javaClass, "createAudioTrackSource", stack.second.javaClass)
                    candidateTrack = createTrack.invoke(candidatePolicy, stack.second) as? AudioTrack
                        ?: throw IllegalStateException("createAudioTrackSource returned null")
                    candidateTrack!!.play()
                    policy = candidatePolicy
                    track = candidateTrack
                    candidateTrack = null // ownership transferred to the active route
                    active = true
                    socialCallOnlyActive = socialCallOnly
                    stopping.set(false)
                    // Recheck immediately after registration; if the call ended
                    // during hidden-API setup, tear the candidate down instead of
                    // leaving a stale injector policy registered.
                    if (socialCallOnly && !isInternetCommunicationMode()) {
                        log("SOCIAL_CALL_ENDED_DURING_ROUTE_SETUP; unregistering policy")
                        stopRouteLocked()
                        return "SOCIAL_CALL_NOT_ACTIVE:CALL_ENDED_DURING_SETUP"
                    }
                    log("ROUTE_READY preset=$preset rate=$candidateRate socialCallOnly=$socialCallOnly")
                    return "ROUTE_READY:$candidateRate:preset=$preset${if (socialCallOnly) ":SOCIAL_CALL" else ""}"
                } catch (t: Throwable) {
                    lastError = "${t.javaClass.simpleName}: ${t.message}"
                    log("route candidate preset=$preset rate=$candidateRate failed: $lastError")
                    // A track may already exist when play()/later setup fails.
                    // Release it before trying another candidate to avoid leaking
                    // an AudioTrack from a partially-created route.
                    runCatching { candidateTrack?.pause() }
                    runCatching { candidateTrack?.flush() }
                    runCatching { candidateTrack?.stop() }
                    runCatching { candidateTrack?.release() }
                    candidateTrack = null
                    if (policyRegistered && candidatePolicy != null) runCatching {
                        findMethod(AudioManager::class.java, "unregisterAudioPolicy", candidatePolicy.javaClass)
                            .invoke(getSystemService(AUDIO_SERVICE), candidatePolicy)
                    }.onFailure { log("candidate unregister failed: ${it.message}; policy state uncertain") }
                }
            }
        }
        "ROUTE_FAILED:$lastError"
    }

    private fun buildPolicyStack(preset: Int, rate: Int): Pair<Any, Any> {
        val policyClass = Class.forName("android.media.AudioPolicy")
        val policyBuilderClass = Class.forName("android.media.AudioPolicy\$Builder")
        val mixClass = Class.forName("android.media.AudioMix")
        val mixBuilderClass = Class.forName("android.media.AudioMix\$Builder")
        val ruleClass = Class.forName("android.media.audiopolicy.AudioMixingRule")
        val ruleBuilderClass = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
        val attrBuilderClass = Class.forName("android.media.AudioAttributes\$Builder")
        val attrCtor = attrBuilderClass.getDeclaredConstructor().also { it.isAccessible = true }
        val attrBuilder = attrCtor.newInstance()
        val setPreset = attrBuilderClass.methods.firstOrNull { it.name == "setCapturePreset" }
            ?: throw NoSuchMethodException("AudioAttributes.Builder.setCapturePreset")
        setPreset.invoke(attrBuilder, preset)
        val attributes = attrBuilderClass.getMethod("build").invoke(attrBuilder)

        val ruleCtor = ruleBuilderClass.getDeclaredConstructor().also { it.isAccessible = true }
        val ruleBuilder = ruleCtor.newInstance()
        val injectorRole = readInt(ruleClass, "MIX_ROLE_INJECTOR", 1)
        val setRole = ruleBuilderClass.methods.firstOrNull { it.name == "setTargetMixRole" }
            ?: throw NoSuchMethodException("setTargetMixRole")
        setRole.invoke(ruleBuilder, injectorRole)
        val matchPreset = readInt(ruleClass, "MIX_RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET", 2)
        val addRule = ruleBuilderClass.methods.firstOrNull { it.name == "addRule" && it.parameterTypes.size == 2 }
            ?: throw NoSuchMethodException("AudioMixingRule.Builder.addRule")
        addRule.invoke(ruleBuilder, attributes, matchPreset)
        val rule = ruleBuilderClass.getMethod("build").invoke(ruleBuilder)
        val actualRole = findMethod(ruleClass, "getTargetMixRole").invoke(rule) as Int
        if (actualRole != injectorRole) throw IllegalStateException("mix role is $actualRole, not injector")

        val mixCtor = mixBuilderClass.getDeclaredConstructor(ruleClass).also { it.isAccessible = true }
        val mixBuilder = mixCtor.newInstance(rule)
        val format = AudioFormat.Builder().setSampleRate(rate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        invokeOne(mixBuilder, "setFormat", format)
        invokeOne(mixBuilder, "setRouteFlags", readInt(mixClass, "ROUTE_FLAG_LOOP_BACK", 2))
        val mix = invokeZero(mixBuilder, "build")

        val context = resolvePolicyContext()
        val policyCtor = policyBuilderClass.getDeclaredConstructor(Context::class.java).also { it.isAccessible = true }
        val policyBuilder = policyCtor.newInstance(context)
        runCatching { invokeOne(policyBuilder, "setLooper", android.os.Looper.getMainLooper()) }
        invokeOne(policyBuilder, "addMix", mix)
        val builtPolicy = invokeZero(policyBuilder, "build")
        return builtPolicy to mix
    }

    private fun resolvePolicyContext(): Context {
        // Shizuku service normally runs as shell. Try shell package context first,
        // then the service context; all failures are recorded, not hidden.
        return runCatching {
            createPackageContext("com.android.shell", Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY)
        }.onFailure { log("shell context unavailable: ${it.message}") }.getOrElse { this }
    }

    private fun readInt(cls: Class<*>, field: String, fallback: Int): Int = runCatching {
        cls.getField(field).getInt(null)
    }.getOrDefault(fallback)

    private fun findMethod(cls: Class<*>, name: String, vararg types: Class<*>): Method {
        return runCatching { cls.getMethod(name, *types) }.getOrElse {
            cls.getDeclaredMethod(name, *types).also { it.isAccessible = true }
        }
    }
    private fun invokeZero(target: Any, name: String): Any =
        findMethod(target.javaClass, name).invoke(target) ?: throw IllegalStateException("$name returned null")
    private fun invokeOne(target: Any, name: String, arg: Any): Any? {
        val method = target.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 &&
            (it.parameterTypes[0].isInstance(arg) || it.parameterTypes[0].isPrimitive && arg is Int) }
            ?: target.javaClass.declaredMethods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }
            ?.also { it.isAccessible = true } ?: throw NoSuchMethodException(name)
        return method.invoke(target, arg)
    }

    private fun startPipe(readEnd: ParcelFileDescriptor): String = synchronized(lock) {
        if (socialCallOnlyActive && !isInternetCommunicationMode()) {
            runCatching { readEnd.close() }
            pipeFailure = "SOCIAL_CALL_NOT_ACTIVE"
            return "SOCIAL_CALL_NOT_ACTIVE"
        }
        if (!active || track == null) { runCatching { readEnd.close() }; return "ROUTE_NOT_ACTIVE" }
        if (pipeThread?.isAlive == true) { runCatching { readEnd.close() }; return "PIPE_ALREADY_RUNNING" }
        pipeInput = readEnd
        pipeFailure = null
        binderPcmMode = false
        stopping.set(false)
        pipeThread = thread(name = "PrimeVoicePcmPipe", isDaemon = true) {
            try {
                FileInputStream(readEnd.fileDescriptor).use { input ->
                    val buffer = ByteArray(8192)
                    while (!stopping.get() && !Thread.currentThread().isInterrupted) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        if (n == 0) continue
                        if (socialCallOnlyActive && !isInternetCommunicationMode()) {
                            throw IllegalStateException("SOCIAL_CALL_MODE_ENDED; refusing further PCM writes")
                        }
                        val current = track ?: break
                        var offset = 0
                        val writeStartedAt = android.os.SystemClock.elapsedRealtime()
                        while (offset < n && !stopping.get() && !Thread.currentThread().isInterrupted) {
                            // Recheck before every partial AudioTrack write, not
                            // only once per pipe read, so a call-mode transition
                            // cannot continue a large buffered chunk unchecked.
                            if (socialCallOnlyActive && !isInternetCommunicationMode()) {
                                throw IllegalStateException("SOCIAL_CALL_MODE_ENDED during AudioTrack write")
                            }
                            val wrote = current.write(buffer, offset, n - offset, AudioTrack.WRITE_NON_BLOCKING)
                            if (wrote < 0) throw IllegalStateException("AudioTrack.write=$wrote")
                            if (wrote == 0) {
                                // WRITE_NON_BLOCKING should never pin the Shizuku writer forever.
                                // Fail closed if AudioTrack cannot accept this PCM chunk.
                                if (android.os.SystemClock.elapsedRealtime() - writeStartedAt > 750L) {
                                    throw IllegalStateException("AudioTrack write stalled for 750 ms")
                                }
                                try {
                                    Thread.sleep(4)
                                } catch (_: InterruptedException) {
                                    Thread.currentThread().interrupt()
                                    break
                                }
                            } else offset += wrote
                        }
                    }
                }
                log("PCM pipe finished")
            } catch (t: Throwable) {
                pipeFailure = "${t.javaClass.simpleName}: ${t.message}"
                log("PCM pipe failed: $pipeFailure")
            }
            finally { runCatching { readEnd.close() }; if (pipeInput === readEnd) pipeInput = null }
        }
        "PIPE_STARTED"
    }

    private fun setRoutePaused(paused: Boolean): String = synchronized(lock) {
        val current = track ?: return "ROUTE_NOT_ACTIVE"
        if (!active) return "ROUTE_NOT_ACTIVE"
        runCatching {
            if (paused) current.pause() else current.play()
        }.onFailure { return "ROUTE_PAUSE_FAILED:${it.javaClass.simpleName}:${it.message}" }
        if (paused) "ROUTE_PAUSED" else "ROUTE_RESUMED"
    }

    private fun stopRoute() = synchronized(lock) { stopRouteLocked() }
    private fun stopRouteLocked(): Boolean {
        stopping.set(true)
        runCatching { pipeInput?.close() }
        pipeInput = null
        val oldPipeThread = pipeThread
        oldPipeThread?.interrupt()
        // Closing the read descriptor above unblocks FileInputStream.read().
        // Join before resetting the stop flag or replacing AudioTrack, so an
        // old pipe worker can never write into a newly started route session.
        if (oldPipeThread != null && oldPipeThread !== Thread.currentThread()) {
            runCatching { oldPipeThread.join(1500) }
            if (oldPipeThread.isAlive) {
                // Do not release/replace the AudioTrack while a writer may
                // still hold its reference. A later stop/start can retry cleanup.
                log("PCM writer did not exit within 1500 ms; retaining old route resources")
                return false
            }
        }
        pipeThread = null
        binderPcmMode = false
        val oldTrack = track; track = null
        runCatching { oldTrack?.pause() }; runCatching { oldTrack?.flush() }; runCatching { oldTrack?.stop() }; runCatching { oldTrack?.release() }
        val oldPolicy = policy; policy = null
        if (oldPolicy != null) runCatching {
            findMethod(AudioManager::class.java, "unregisterAudioPolicy", oldPolicy.javaClass)
                .invoke(getSystemService(AUDIO_SERVICE), oldPolicy)
        }.onFailure { log("unregisterAudioPolicy failed: ${it.message}; policy state uncertain") }
        active = false
        socialCallOnlyActive = false
        log("route stopped and cleanup attempted")
        return true
    }

    override fun onDestroy() { stopRoute(); super.onDestroy() }
}
