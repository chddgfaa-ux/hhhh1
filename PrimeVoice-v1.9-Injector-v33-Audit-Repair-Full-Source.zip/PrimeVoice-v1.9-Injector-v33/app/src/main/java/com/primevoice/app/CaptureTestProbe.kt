package com.primevoice.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Looper
import android.os.Process
import android.util.Log
import java.lang.reflect.Method
import java.util.concurrent.Callable
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.sin

/**
 * Capture Test probe — runs ONLY inside the Shizuku UserService process.
 *
 * Purpose (one question only):
 *   On this phone (Redmi 14C, Android 16 / HyperOS), does
 *   AudioPolicy.registerAudioPolicy() + createAudioTrackSource()
 *   deliver PCM into AudioRecord(MIC)?
 *
 * Constructor / role facts, verified against AOSP source (not guessed):
 *  - AudioPolicy.Builder has ONLY Builder(Context). There is no no-arg
 *    constructor. (AOSP AudioPolicy.java; used as `new AudioPolicy.Builder(context)`.)
 *  - AudioMix.Builder has ONLY the public constructor Builder(AudioMixingRule).
 *    setMixingRule() is package-private (@hide, "Only used by AudioPolicyConfig").
 *  - AudioMixingRule.Builder.setTargetMixRole(MIX_ROLE_INJECTOR) must be
 *    called BEFORE addRule(). If the role is never set, build() defaults
 *    the rule to MIX_ROLE_PLAYERS and the mix will NOT inject.
 *  - MIX_ROLE_INJECTOR = AudioMix.MIX_TYPE_RECORDERS = 1,
 *    MIX_ROLE_PLAYERS = AudioMix.MIX_TYPE_PLAYERS = 0.
 *  - ROUTE_FLAG_LOOP_BACK = 0x1 << 1 = 2. RULE_MATCH_ATTRIBUTE_USAGE = 0x1,
 *    RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET = 0x1 << 1 = 2.
 *  The probe reads these values by reflection and logs them; the numbers
 *  above are only fallbacks if a field cannot be read.
 *
 * Flow (v4):
 *  Phase A — register test, preset by preset [7, 1, 5, 6, 4]:
 *    build stack -> register (8000 ms timeout) -> unregister immediately,
 *    but ONLY if the register call actually returned 0. A non-zero return
 *    means "not registered", so there is nothing to unregister.
 *  Phase B — hold tone:
 *    the FIRST preset that registered is built again, registered, and its
 *    880 Hz tone is played CONTINUOUSLY until STOP TEST (max 120 s), so
 *    CHECK MIC never arrives too late.
 *
 * v4 hardening (review):
 *  1. Registration timeout: on timeout the background registration task is
 *     NOT killed with shutdownNow() — a Binder/reflection call in flight
 *     may ignore it. Instead the worker WAITS for the real outcome (up to
 *     30 s more, in 5 s slices). If it registers late, the policy is
 *     unregistered immediately and the late result is logged. If it never
 *     answers, the policy is recorded as UNKNOWN state, the run is aborted,
 *     and it is NEVER unregistered blindly — the leak is logged loudly.
 *  2. STOP/RUN concurrency: a state machine (IDLE -> RUNNING -> FINISHING
 *     -> IDLE). A new RUN is refused until the previous worker thread has
 *     fully finished AND cleanup is done (state back to IDLE). `running =
 *     false` alone never means "done". Cleanup is idempotent
 *     (cleanupOnce) and verifies track released + policies unregistered.
 *  3. No wrong fallbacks: AudioPolicy.Builder(Context) and
 *     AudioMix.Builder(AudioMixingRule) only. If the correct constructor
 *     is missing, that preset FAILS with a detailed log — no no-arg
 *     fallback. setTargetMixRole must exist, and the built rule's
 *     getTargetMixRole() must read back 1 (INJECTOR), or the preset fails.
 *
 * v5 fix (the one problem found in v4): "cleanup started" and "cleanup
 * finished" are now TWO different states. v4 had a single `cleanedUp`
 * flag meaning "started": a second caller (worker finally) saw it and
 * returned immediately while the first caller (STOP's Binder thread)
 * was still unregistering policies — and the worker then set
 * state=IDLE too early, so a new RUN could start before the old policy
 * was gone. Now the starter does the work and counts down a
 * CountDownLatch; every other caller WAITS on the same latch, and IDLE
 * is set only after the latch reaches zero. Nothing else changed in v5.
 *
 * v6 fixes (the two problems found in v5):
 *  1. STOP vs AudioTrack creation race: the STOP check, track creation,
 *     storing currentTrack, and the decision to play are now ONE atomic
 *     step under toneArmLock. Cleanup takes the same lock before it
 *     reads/nulls currentTrack. If STOP arrives before or during track
 *     creation, no track is created (or the just-created one is released
 *     inside the lock) — the tone can never start after cleanup.
 *  2. Late registration: a registration that succeeds after the 8 s
 *     timeout is unregistered immediately, so it is NOT usable for
 *     Phase B. RegisterOutcome now carries `usable` (true only when
 *     code == 0 AND it arrived within the timeout). Phase A counts
 *     only usable presets as candidates; Phase B refuses a late
 *     registration instead of creating an AudioTrack from a policy
 *     that is already gone.
 *
 * v7 fix (the one race found in v6): the stopRequested check and
 * track.play() in playToneLoop() were NOT under a common lock, so STOP
 * could land between them. Now the check + play() are one atomic step
 * under toneArmLock. The lock is held ONLY for check + play() (a few
 * ms), never for the write loop — so STOP is never blocked for long.
 *
 * v8 fix (the one race found in v7): stop() set stopRequested = true
 * WITHOUT toneArmLock, so STOP could set it after the worker had
 * checked it but before play(). Now stop() sets the flag UNDER
 * toneArmLock (inside the startLock block), so the flag write and the
 * worker's check + play() are serialized by the same lock.
 * Lock order everywhere: startLock -> toneArmLock -> policyLock, and
 * cleanupLock -> toneArmLock -> policyLock. No code takes toneArmLock
 * and then startLock, and no code takes startLock while holding
 * toneArmLock — so no deadlock. Full execution orders for every race
 * scenario are documented in CAPTURE_TEST.md
 * ("Race scenario execution orders (v8)").
 *
 *  getProcessUid() returns Process.myUid() — a UID only. It is NOT
 *  treated here as proof of privileged permission.
 *
 * This file does NOT touch the Floating Player or the Soundboard / Voice
 * Pack code. It is a separate test, started only from the Settings
 * "CAPTURE TEST" section.
 */
class CaptureTestProbe(private val context: Context) {

    companion object {
        const val TAG = "PrimeVoiceCaptureTest"
        /** v2.0 APK analysis: policy register latch timeout. */
        const val POLICY_TIMEOUT_MS = 8000L
        /** After a register timeout, how long to wait for the real outcome. */
        const val LATE_RESOLVE_MS = 30000L
        /** Phase B safety limit: never hold the tone longer than this. */
        const val MAX_HOLD_SECONDS = 120
        /** Capture presets, tried one by one (v2.0 APK analysis). */
        val PRESETS = intArrayOf(7, 1, 5, 6, 4)
        val PRESET_NAMES = mapOf(
            7 to "VOICE_COMMUNICATION",
            1 to "MIC",
            5 to "CAMCORDER",
            6 to "VOICE_RECOGNITION",
            4 to "VOICE_CALL"
        )
        const val TEST_TONE_HZ = 880.0
    }

    /** One run at a time. IDLE = a new RUN is allowed; anything else = refused. */
    enum class ProbeState { IDLE, RUNNING, FINISHING }

    @Volatile private var state = ProbeState.IDLE
    @Volatile private var stopRequested = false
    @Volatile private var leakSuspected = false
    private val logLock = Any()
    private val logLines = StringBuilder()
    private val startMs = System.currentTimeMillis()

    private val startLock = Any()
    private val cleanupLock = Any()
    private val policyLock = Any()
    /**
     * v5: "cleanup started" and "cleanup finished" are TWO different
     * states, kept in two different fields. `cleanupStarted` says one
     * thread is doing (or has done) the work; `cleanupDone` (a latch)
     * reaches zero only when the work is TRULY finished — track released
     * AND policies unregistered. A caller that finds cleanup already
     * started must WAIT on the latch instead of returning early.
     * Both are reset in tryStart(), under cleanupLock.
     */
    @Volatile private var cleanupStarted = false
    private var cleanupDone = CountDownLatch(1)
    /**
     * v6: guards the "arm the tone" sequence. STOP check, AudioTrack
     * creation, storing currentTrack, and the decision to play happen
     * under this ONE lock; cleanupOnce() takes the same lock before it
     * reads/nulls currentTrack. So STOP and tone-start can never
     * interleave: either STOP wins (no track, or the just-created track
     * is released inside the lock) or the tone is armed (currentTrack is
     * set, so cleanup will release it). Lock order everywhere:
     * toneArmLock -> policyLock.
     */
    private val toneArmLock = Any()

    // Live objects — all guarded by policyLock.
    private var currentPolicy: Any? = null
    private var currentTrack: AudioTrack? = null
    // v13: @Volatile — written by the worker thread in run(), read by
    // cleanupOnce() which may run on STOP's Binder thread. Without it a
    // stale null read could skip unregistering a registered policy.
    @Volatile private var audioManager: AudioManager? = null
    /** Policies KNOWN to be registered right now (policy -> preset). */
    private val registeredPolicies = LinkedHashMap<Any, Int>()
    /**
     * Policies whose registration outcome was NEVER confirmed (timed out and
     * never answered). They are deliberately NEVER unregistered blindly —
     * unregistering without knowing whether registration finished is
     * forbidden by the review. They are logged as LEAK WARNINGs instead.
     * Kept across runs on purpose: the reference is the only trace left.
     */
    private val pendingPolicies = ArrayList<Pair<Any, Int>>()

    fun getState(): String = state.name

    /** True while a run is active OR still finishing its cleanup. */
    fun isRunning(): Boolean = state != ProbeState.IDLE

    fun log(): String = synchronized(logLock) { logLines.toString() }

    private fun addLog(msg: String) {
        val elapsed = System.currentTimeMillis() - startMs
        val line = "[+${elapsed}ms] $msg"
        synchronized(logLock) { logLines.append(line).append('\n') }
        Log.i(TAG, line)
    }

    /**
     * Claims the probe for a new run. Returns false if a previous run has
     * not fully finished (state != IDLE) — the caller must refuse the RUN.
     * Called by the service BEFORE starting the worker thread.
     */
    fun tryStart(): Boolean {
        synchronized(startLock) {
            if (state != ProbeState.IDLE) {
                addLog("tryStart REFUSED: state=$state — previous test has not finished cleanup yet. Wait for state=IDLE.")
                return false
            }
            state = ProbeState.RUNNING
            stopRequested = false
            leakSuspected = false
            synchronized(cleanupLock) {
                cleanupStarted = false
                cleanupDone = CountDownLatch(1)
            }
            synchronized(policyLock) {
                registeredPolicies.clear()
                currentPolicy = null
                currentTrack = null
            }
            val pending = synchronized(policyLock) { pendingPolicies.size }
            if (pending > 0) {
                addLog("NOTE: $pending polic(ies) from earlier runs still have UNKNOWN state (see LEAK WARNING lines) — they were never unregistered blindly.")
            }
            return true
        }
    }

    /**
     * Asks the run to stop and WAITS until the cleanup is truly finished.
     * It sets the flag, moves the state to FINISHING, and then waits on
     * the cleanup latch — so when stop() returns, the track is released
     * and every known policy is unregistered (or logged as LEAK).
     * The state becomes IDLE only in run()'s finally block, after the
     * worker thread has actually exited. So a caller must never treat
     * "stop() returned" as "the worker is done" — but it CAN treat it
     * as "the cleanup is done".
     */
    fun stop() {
        synchronized(startLock) {
            if (state == ProbeState.RUNNING) {
                // v8: set stopRequested UNDER toneArmLock — the same lock
                // playToneLoop's check + track.play() hold. In v7 the flag
                // was set at the top of stop() WITHOUT any lock, so STOP
                // could set it after the worker had checked it but before
                // play() — and the tone could start after STOP was requested.
                // Lock order: startLock -> toneArmLock -> policyLock. No
                // code takes toneArmLock and then startLock, and no code
                // takes startLock while holding toneArmLock, so this
                // cannot deadlock. The flag write is now serialized with
                // the worker's check + play(): either STOP's write happens
                // first (worker sees true, no play) or the worker's
                // check + play happens first (STOP's cleanup then releases
                // the track). If state is already FINISHING, the flag was
                // set by the first stop() call; if IDLE, no run exists.
                synchronized(toneArmLock) { stopRequested = true }
                state = ProbeState.FINISHING
            }
        }
        addLog("stop() called — stop requested; waiting for cleanup to truly finish (state stays FINISHING until then)")
        awaitCleanupDone()
    }

    /**
     * Starts the cleanup if nobody has, and returns the latch that
     * reaches zero when the cleanup is TRULY finished. Only the first
     * caller does the work; every other caller gets the SAME latch and
     * must wait on it (see awaitCleanupDone). The latch is counted down
     * in `finally`, so it always fires even if a release/unregister
     * step throws.
     *
     * No deadlock: the cleanup work (track.release() +
     * unregisterAudioPolicy()) never waits for the worker thread, so a
     * thread waiting on the latch can never block the thread doing the
     * work. If the waiting thread IS the worker (run()'s finally) and
     * it is also the starter, the latch is already zero by the time
     * cleanupOnce() returns.
     */
    private fun cleanupOnce(): CountDownLatch {
        val latch: CountDownLatch
        synchronized(cleanupLock) {
            latch = cleanupDone
            if (cleanupStarted) return latch
            cleanupStarted = true
        }
        // Only the starter reaches here.
        try {
            addLog("cleanup: starting (AudioTrack + AudioPolicies)")
            // v6: take toneArmLock too, so this take-and-null is atomic
            // with the worker's arming sequence (which also holds
            // toneArmLock). Lock order everywhere: startLock ->
            // toneArmLock -> policyLock (stop() sets the flag under
            // toneArmLock), and cleanupLock -> toneArmLock -> policyLock.
            val track: AudioTrack? = synchronized(toneArmLock) {
                synchronized(policyLock) {
                    val t = currentTrack
                    currentTrack = null
                    t
                }
            }
            if (track != null) {
                try { track.pause(); track.flush(); track.stop() } catch (_: Exception) {}
                try { track.release() } catch (_: Exception) {}
                addLog("cleanup: AudioTrack released — tone is off")
            } else {
                addLog("cleanup: no live AudioTrack")
            }
            val am = audioManager
            val toUnregister: List<Pair<Any, Int>> = synchronized(policyLock) {
                registeredPolicies.entries.map { it.key to it.value }
            }
            if (am != null) {
                for ((policy, preset) in toUnregister) unregisterPolicy(am, policy, preset)
            } else if (toUnregister.isNotEmpty()) {
                addLog("cleanup: AudioManager unavailable — ${toUnregister.size} polic(ies) could not be unregistered")
            }
            val left = synchronized(policyLock) { registeredPolicies.size }
            if (left > 0) {
                val presets = synchronized(policyLock) { registeredPolicies.values.toList() }
                addLog("LEAK: $left polic(ies) STILL registered after cleanup (presets $presets) — unregister failed for them")
            } else {
                addLog("cleanup: no policy left registered (all known registrations cleaned up)")
            }
            val pending = synchronized(policyLock) { pendingPolicies.toList() }
            if (pending.isNotEmpty()) {
                addLog("LEAK WARNING: ${pending.size} polic(ies) with UNKNOWN state (registration never confirmed, presets ${pending.map { it.second }}) — " +
                    "NOT unregistered blindly. If a tone keeps playing after STOP, reboot the phone.")
            }
            if (leakSuspected) {
                addLog("LEAK WARNING: this run suspected a leaked policy — see the [4e] lines above")
            }
        } finally {
            latch.countDown()
            addLog("cleanup: finished (latch released)")
        }
        return latch
    }

    /**
     * Waits until the cleanup is truly finished — never returns early.
     * If the wait is interrupted, it keeps waiting (and restores the
     * interrupt flag afterwards), because returning early would reopen
     * the exact v4 race this fix closes.
     */
    private fun awaitCleanupDone() {
        val latch = cleanupOnce()
        var interrupted = false
        while (true) {
            try {
                latch.await()
                break
            } catch (_: InterruptedException) {
                interrupted = true
                addLog("cleanup wait interrupted — still waiting for cleanup to finish (IDLE must wait)")
            }
        }
        if (interrupted) Thread.currentThread().interrupt()
    }

    /** Runs the whole probe on the calling thread. Call from a worker thread after tryStart(). */
    fun run(sampleRate: Int, maxHoldSeconds: Int) {
        if (state != ProbeState.RUNNING) {
            addLog("run: refused — state=$state (tryStart was not called, or a test is already running)")
            return
        }
        val rate = sampleRate.coerceIn(8000, 48000)
        val maxHold = maxHoldSeconds.coerceIn(10, MAX_HOLD_SECONDS)
        try {
            addLog("=== CAPTURE TEST START (v4) ===")
            addLog("sdk=${android.os.Build.VERSION.SDK_INT} model=${android.os.Build.MODEL} " +
                "manufacturer=${android.os.Build.MANUFACTURER} uid=${Process.myUid()} " +
                "(uid is UID only, not proof of privilege) sampleRate=$rate maxHold=${maxHold}s")

            stepHiddenApiBypass()
            val classes = stepFindClasses()
            if (classes == null) {
                addLog("RESULT: FAIL — hidden classes not found, cannot continue")
                return
            }
            stepListBuilderMethods(classes)
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager = am

            // ---- Phase A: register test, preset by preset ----
            addLog("--- Phase A: register test, preset by preset (no tone yet) ---")
            var bestPreset = -1
            var lateCount = 0
            var aborted = false
            for (preset in PRESETS) {
                if (stopRequested) { addLog("stopped by user during Phase A"); break }
                addLog("--- preset $preset (${PRESET_NAMES[preset] ?: "?"}) ---")
                val stack = buildStack(classes, preset, rate)
                if (stack == null) {
                    addLog("[4] preset $preset: stack build FAILED, skipping preset")
                    continue
                }
                val outcome = registerWithTimeout(am, stack.policy, preset)
                if (outcome.unknown) {
                    addLog("[4] preset $preset: ABORTING Phase A — registration outcome unknown (see LEAK WARNING above). No further preset will be tested.")
                    aborted = true
                    break
                }
                if (outcome.code == 0 && outcome.usable) {
                    addLog("[4] preset $preset: REGISTER OK")
                    synchronized(policyLock) { registeredPolicies[stack.policy] = preset }
                    if (bestPreset < 0) bestPreset = preset
                    unregisterPolicy(am, stack.policy, preset)
                } else if (outcome.code == 0) {
                    // v6: late success is NOT usable. It registered after
                    // the 8 s timeout, and resolvePendingRegistration
                    // already unregistered it. It proves the mechanism can
                    // work, but the policy is gone — it is NOT a candidate
                    // for Phase B.
                    addLog("[4] preset $preset: REGISTER OK but LATE (>8s) — already unregistered, NOT usable for Phase B, not counted as a candidate")
                    lateCount++
                } else {
                    addLog("[4] preset $preset: register returned ${outcome.code} (not 0) — not registered, nothing to unregister")
                }
            }
            if (aborted) {
                addLog("=== CAPTURE TEST END ===")
                addLog("RESULT: FAIL — aborted: a registration outcome is unknown and a policy may be leaked. See LEAK WARNING lines. Reboot the phone before running again.")
                return
            }
            if (bestPreset < 0 || stopRequested) {
                addLog("=== CAPTURE TEST END ===")
                if (bestPreset < 0 && lateCount > 0) {
                    addLog("RESULT: FAIL — no USABLE preset registered ($lateCount preset(s) registered late but were unregistered before they could be used). No tone was played.")
                } else {
                    addLog("RESULT: FAIL — no preset registered (bestPreset=$bestPreset). No tone was played.")
                }
                return
            }

            // ---- Phase B: hold the tone on the best preset ----
            // Lifecycle rule: STOP TEST must win at EVERY step. After each
            // slow step (build / register / create track) we check
            // stopRequested BEFORE creating the next live object, so a stop
            // pressed mid-Phase-B can never leave a tone playing or a policy
            // registered. cleanupOnce() in finally is the last safety net,
            // and the tone itself has a max-hold safety limit (120 s), so
            // even if the app is killed the tone cannot play forever.
            addLog("--- Phase B: holding tone on preset $bestPreset (${PRESET_NAMES[bestPreset]}) ---")
            val stack = buildStack(classes, bestPreset, rate)
            if (stack == null) {
                addLog("RESULT: FAIL — could not rebuild stack for preset $bestPreset")
                return
            }
            if (stopRequested) {
                addLog("[5] stopped by user before register — cleaning up, no tone played")
                return
            }
            val outcome = registerWithTimeout(am, stack.policy, bestPreset)
            if (outcome.unknown) {
                addLog("RESULT: FAIL — Phase B registration outcome unknown (see LEAK WARNING). Aborting, no tone played.")
                return
            }
            if (!outcome.usable) {
                if (outcome.code == 0) {
                    addLog("RESULT: FAIL — preset $bestPreset registered LATE (after ${POLICY_TIMEOUT_MS}ms). The policy was already unregistered in [4e], so no AudioTrack can be created from it. Register is too slow to be usable on this phone.")
                } else {
                    addLog("RESULT: FAIL — preset $bestPreset registered in Phase A but not in Phase B (code ${outcome.code})")
                }
                return
            }
            synchronized(policyLock) {
                registeredPolicies[stack.policy] = bestPreset
                currentPolicy = stack.policy
            }
            if (stopRequested) {
                addLog("[5] stopped by user after register — unregistering, no tone played")
                unregisterPolicy(am, stack.policy, bestPreset)
                return
            }
            // v6: STOP check, track creation, storing currentTrack, and the
            // decision to play are ONE atomic step under toneArmLock.
            // Cleanup takes the same lock before it reads/nulls
            // currentTrack, so the two can never interleave: either STOP
            // wins (no track is created, or the just-created track is
            // released here) or the tone is armed (currentTrack is set, so
            // cleanup will release it). A track can never be created after
            // cleanup has finished.
            var track: AudioTrack? = null
            var armAborted = false
            synchronized(toneArmLock) {
                if (stopRequested || cleanupStarted) {
                    addLog("[5] STOP came before track creation — no AudioTrack will be created, no tone")
                    armAborted = true
                } else {
                    val created = runCatching {
                        val m = findMethod(classes.audioPolicy, "createAudioTrackSource", classes.audioMix)
                        m.invoke(stack.policy, stack.mix) as? AudioTrack
                    }.onFailure { addLog("[5] createAudioTrackSource FAILED: ${it.javaClass.simpleName}: ${it.message}") }
                        .getOrNull()
                    if (created == null) {
                        track = null
                    } else if (stopRequested || cleanupStarted) {
                        // STOP arrived WHILE the track was being created.
                        // The track exists but must never play: release it now.
                        addLog("[5] STOP arrived during track creation — releasing the just-created track, no tone will play")
                        try { created.release() } catch (_: Exception) {}
                        track = null
                        armAborted = true
                    } else {
                        track = created
                        synchronized(policyLock) { currentTrack = created }
                    }
                }
            }
            if (track == null) {
                if (armAborted) {
                    addLog("RESULT: FAIL — stopped before the tone could start (no tone played)")
                } else {
                    addLog("RESULT: FAIL — createAudioTrackSource returned null")
                }
                unregisterPolicy(am, stack.policy, bestPreset)
                return
            }
            addLog("[5] TONE PLAYING preset $bestPreset (${TEST_TONE_HZ.toInt()} Hz) — press CHECK MIC now.")
            addLog("[5] Tone keeps playing until STOP TEST (max ${maxHold}s).")
            addLog("[5] WARNING: if you can hear the tone from the phone speaker, use headphones — " +
                "speaker sound reaching the mic gives a false TONE_DETECTED. " +
                "Do the BASELINE CHECK first (no tone) and compare.")
            playToneLoop(track, rate, maxHold)
            addLog("=== CAPTURE TEST END ===")
            addLog("RESULT: tone held on preset $bestPreset. " +
                "Check the MIC CHECK result: TONE_DETECTED only counts if the baseline " +
                "(no tone) ratio was clearly lower. The decisive proof is a recording " +
                "from ANOTHER app while the tone was playing.")
        } catch (t: Throwable) {
            addLog("RESULT: FAIL — unexpected error: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            stop()
            // Belt and braces: stop() already waited for cleanup, but IDLE
            // is set ONLY here, after a second wait that returns instantly
            // when cleanup is done. Cleanup can never still be running
            // when state becomes IDLE — that is the v5 guarantee.
            awaitCleanupDone()
            synchronized(startLock) { state = ProbeState.IDLE }
            addLog("state=IDLE — worker finished and cleanup is done. A new RUN is now allowed.")
        }
    }

    // ---- Step 1: Hidden API bypass ---------------------------------------

    private fun stepHiddenApiBypass() {
        addLog("[1] Hidden API bypass")
        val result = runCatching {
            val cls = Class.forName("org.lsposed.hiddenapibypass.HiddenApiBypass")
            val m = cls.getMethod("addHiddenApiExemptions", Array<String>::class.java)
            m.invoke(null, arrayOf(""))
            "HiddenApiBypass.addHiddenApiExemptions(\"\") OK"
        }.getOrElse {
            "HiddenApiBypass NOT available/failed: ${it.javaClass.simpleName}: ${it.message} — continuing with plain reflection"
        }
        addLog("[1] $result")
    }

    // ---- Step 2: find the hidden classes ---------------------------------

    private data class HiddenClasses(
        val audioPolicy: Class<*>,
        val audioPolicyBuilder: Class<*>,
        val audioMix: Class<*>,
        val audioMixBuilder: Class<*>,
        val mixingRule: Class<*>,
        val mixingRuleBuilder: Class<*>
    )

    private fun findClass(name: String): Class<*>? {
        return runCatching { Class.forName(name) }.onFailure {
            addLog("[2] Class NOT found: $name (${it.message})")
        }.getOrNull()?.also { addLog("[2] Class found: $name") }
    }

    private fun stepFindClasses(): HiddenClasses? {
        addLog("[2] Finding hidden classes (Class.forName only)")
        val policy = findClass("android.media.AudioPolicy") ?: return null
        val policyBuilder = findClass("android.media.AudioPolicy\$Builder") ?: return null
        val mix = findClass("android.media.AudioMix") ?: return null
        val mixBuilder = findClass("android.media.AudioMix\$Builder") ?: return null
        val rule = findClass("android.media.audiopolicy.AudioMixingRule") ?: return null
        val ruleBuilder = findClass("android.media.audiopolicy.AudioMixingRule\$Builder") ?: return null
        return HiddenClasses(policy, policyBuilder, mix, mixBuilder, rule, ruleBuilder)
    }

    // ---- Step 3: list what the Builders can actually do ------------------

    private fun stepListBuilderMethods(c: HiddenClasses) {
        addLog("[3] Builder shapes on this phone (discovery, not assumption)")
        for ((label, cls) in listOf(
            "AudioPolicy.Builder" to c.audioPolicyBuilder,
            "AudioMix.Builder" to c.audioMixBuilder,
            "AudioMixingRule.Builder" to c.mixingRuleBuilder
        )) {
            val ctors = cls.declaredConstructors
                .map { "ctor(" + it.parameterTypes.joinToString(",") { p -> p.simpleName } + ")" }
                .sorted()
            addLog("[3] $label constructors: ${ctors.joinToString("; ")}")
            val methods = cls.declaredMethods
                .map { it.name + "(" + it.parameterTypes.joinToString(",") { p -> p.simpleName } + ")" }
                .sorted()
            addLog("[3] $label methods: ${methods.joinToString("; ")}")
        }
        // Field values we depend on — read them, do not hard-code silently.
        // AOSP values: ROUTE_FLAG_LOOP_BACK = 0x1 << 1 = 2; MIX_ROLE_INJECTOR = 1;
        // RULE_MATCH_ATTRIBUTE_USAGE = 0x1; RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET = 0x1 << 1 = 2.
        addLog("[3] AudioMix.ROUTE_FLAG_LOOP_BACK = ${readIntField(c.audioMix, "ROUTE_FLAG_LOOP_BACK", 2)}")
        addLog("[3] AudioMixingRule.MIX_ROLE_INJECTOR = ${readIntField(c.mixingRule, "MIX_ROLE_INJECTOR", 1)} (1 = injector, 0 = players)")
        addLog("[3] AudioMixingRule.MIX_RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET = ${readIntField(c.mixingRule, "MIX_RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET", 2)}")
        addLog("[3] AudioMixingRule.MIX_RULE_MATCH_ATTRIBUTE_USAGE = ${readIntField(c.mixingRule, "MIX_RULE_MATCH_ATTRIBUTE_USAGE", 1)}")
    }

    private fun readIntField(cls: Class<*>, name: String, fallback: Int): Int {
        return runCatching {
            val f = cls.getField(name)
            f.isAccessible = true
            f.getInt(null)
        }.getOrElse {
            addLog("[3] field $name not readable on ${cls.simpleName}, using fallback $fallback (${it.message})")
            fallback
        }
    }

    /** Finds a method, trying public lookup first, then declared (hidden) lookup. */
    private fun findMethod(cls: Class<*>, name: String, vararg paramTypes: Class<*>): Method {
        return runCatching { cls.getMethod(name, *paramTypes) }.getOrElse {
            val m = cls.getDeclaredMethod(name, *paramTypes)
            m.isAccessible = true
            m
        }
    }

    // ---- Step 4: build one full stack (attributes + rule + mix + policy) --

    private data class Stack(val policy: Any, val mix: Any)

    private fun buildStack(c: HiddenClasses, preset: Int, rate: Int): Stack? {
        val attributes = buildAttributes(preset)
        if (attributes == null) {
            addLog("[4a] preset $preset: AudioAttributes build FAILED")
            return null
        }
        addLog("[4a] preset $preset: AudioAttributes OK")
        val rule = buildMixingRule(c, attributes)
        if (rule == null) {
            addLog("[4b] preset $preset: AudioMixingRule build FAILED")
            return null
        }
        val mix = buildMix(c, rule, rate, preset)
        if (mix == null) {
            addLog("[4c] preset $preset: AudioMix build FAILED")
            return null
        }
        addLog("[4c] preset $preset: AudioMix OK")
        val policy = buildPolicy(c, mix, preset)
        if (policy == null) {
            addLog("[4d] preset $preset: AudioPolicy build FAILED")
            return null
        }
        addLog("[4d] preset $preset: AudioPolicy OK")
        return Stack(policy, mix)
    }

    private fun buildAttributes(preset: Int): Any? {
        return runCatching {
            val builderCls = Class.forName("android.media.AudioAttributes\$Builder")
            val b = builderCls.getDeclaredConstructor().newInstance()
            // Preferred: setCapturePreset(preset). Fall back to USAGE_VOICE_COMMUNICATION.
            val setPreset: Method? = builderCls.methods.firstOrNull { it.name == "setCapturePreset" }
            if (setPreset != null) {
                setPreset.invoke(b, preset)
                addLog("[4a] setCapturePreset($preset) used")
            } else {
                val setUsage = builderCls.getMethod("setUsage", Int::class.javaPrimitiveType)
                setUsage.invoke(b, 2) // AudioAttributes.USAGE_VOICE_COMMUNICATION = 2
                addLog("[4a] setCapturePreset NOT found on this phone, fallback setUsage(VOICE_COMMUNICATION)")
            }
            builderCls.getMethod("build").invoke(b)
        }.onFailure { addLog("[4a] AudioAttributes FAILED: ${it.javaClass.simpleName}: ${it.message}") }
            .getOrNull()
    }

    private fun buildMixingRule(c: HiddenClasses, attributes: Any): Any? {
        val injectorRole = readIntField(c.mixingRule, "MIX_ROLE_INJECTOR", 1)
        return try {
            val b = c.mixingRuleBuilder.getDeclaredConstructor().newInstance()
            // v4: setTargetMixRole must exist. If it is missing we cannot set
            // the INJECTOR role, and build() would default to PLAYERS — so
            // fail the preset here instead of building a wrong rule.
            val setRole = c.mixingRuleBuilder.methods.firstOrNull { it.name == "setTargetMixRole" }
            if (setRole == null) {
                addLog("[4b] FAIL — setTargetMixRole NOT found on this phone. Cannot set MIX_ROLE_INJECTOR, so this preset cannot be an injector. Failing preset.")
                return null
            }
            // The role must be set FIRST, before any rule is added.
            // AOSP: setTargetMixRole throws if the role is incompatible with
            // rules added earlier — so it must come first.
            setRole.invoke(b, injectorRole)
            addLog("[4b] setTargetMixRole(MIX_ROLE_INJECTOR=$injectorRole) OK")
            val rulePreset = readIntField(c.mixingRule, "MIX_RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET", 2)
            val ruleUsage = readIntField(c.mixingRule, "MIX_RULE_MATCH_ATTRIBUTE_USAGE", 1)
            val addRule = c.mixingRuleBuilder.methods.firstOrNull {
                it.name == "addRule" && it.parameterTypes.size == 2
            }
            if (addRule != null) {
                val first = runCatching { addRule.invoke(b, attributes, rulePreset) }.isSuccess
                if (!first) {
                    addLog("[4b] addRule(capturePreset) failed, trying addRule(usage)")
                    addRule.invoke(b, attributes, ruleUsage)
                }
            } else {
                val addMixRule = c.mixingRuleBuilder.methods.firstOrNull { it.name == "addMixRule" }
                    ?: throw NoSuchMethodException("no addRule/addMixRule on AudioMixingRule.Builder")
                val params = addMixRule.parameterTypes
                if (params[0] == Int::class.javaPrimitiveType) addMixRule.invoke(b, rulePreset, attributes)
                else addMixRule.invoke(b, attributes, rulePreset)
            }
            val rule = c.mixingRuleBuilder.getMethod("build").invoke(b)
            // Verify the built rule really is an injector rule — do not assume it.
            val actualRole = runCatching {
                val m = findMethod(c.mixingRule, "getTargetMixRole")
                m.invoke(rule) as Int
            }.getOrNull()
            addLog("[4b] built rule targetMixRole=$actualRole (1=INJECTOR, 0=PLAYERS)")
            // Role 1 must be CONFIRMED. If getTargetMixRole() returns null
            // (cannot verify) or anything other than INJECTOR, this preset
            // is discarded — an unverified mix must never be treated as an
            // injector.
            if (actualRole == null) {
                addLog("[4b] ROLE UNKNOWN — getTargetMixRole() could not be read, failing this preset")
                null
            } else if (actualRole != injectorRole) {
                addLog("[4b] ROLE MISMATCH — rule is NOT an injector rule, failing this preset")
                null
            } else {
                rule
            }
        } catch (t: Throwable) {
            addLog("[4b] AudioMixingRule FAILED: ${t.javaClass.simpleName}: ${t.message}")
            null
        }
    }

    private fun buildMix(c: HiddenClasses, rule: Any, rate: Int, preset: Int): Any? {
        // v4: ONLY the public constructor Builder(AudioMixingRule). The
        // no-arg Builder() and setMixingRule() are package-private (@hide,
        // "Only used by AudioPolicyConfig") — the old fallback was wrong
        // and is removed. If the correct constructor is missing, fail.
        val b: Any = try {
            val ctor = c.audioMixBuilder.getDeclaredConstructor(c.mixingRule)
            ctor.isAccessible = true
            ctor.newInstance(rule).also {
                addLog("[4c] preset $preset: AudioMix.Builder(rule) used (correct AOSP constructor)")
            }
        } catch (e: NoSuchMethodException) {
            val ctors = c.audioMixBuilder.declaredConstructors
                .map { "ctor(" + it.parameterTypes.joinToString(",") { p -> p.simpleName } + ")" }
            addLog("[4c] preset $preset: FAIL — AudioMix.Builder(AudioMixingRule) NOT found on this phone. " +
                "Constructors found: ${ctors.joinToString("; ")}. No no-arg fallback is used (it is package-private and wrong).")
            return null
        } catch (e: Exception) {
            addLog("[4c] preset $preset: FAIL — AudioMix.Builder(rule) could not be created: ${e.javaClass.simpleName}: ${e.message}")
            return null
        }
        return runCatching {
            val format = AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            invokeBuilder(b, "setFormat", format)
            invokeBuilder(b, "setRouteFlags", readIntField(c.audioMix, "ROUTE_FLAG_LOOP_BACK", 2))
            invokeBuilder(b, "build")
        }.onFailure { addLog("[4c] preset $preset: AudioMix FAILED: ${it.javaClass.simpleName}: ${it.message}") }
            .getOrNull()
    }

    private fun buildPolicy(c: HiddenClasses, mix: Any, preset: Int): Any? {
        // v4: ONLY Builder(Context). AOSP AudioPolicy.Builder has no no-arg
        // constructor — the old fallback was wrong and is removed. If the
        // correct constructor is missing, fail with the details.
        val b: Any = try {
            val ctor = c.audioPolicyBuilder.getDeclaredConstructor(Context::class.java)
            ctor.isAccessible = true
            ctor.newInstance(context).also {
                addLog("[4d] preset $preset: AudioPolicy.Builder(Context) used (correct AOSP constructor)")
            }
        } catch (e: NoSuchMethodException) {
            val ctors = c.audioPolicyBuilder.declaredConstructors
                .map { "ctor(" + it.parameterTypes.joinToString(",") { p -> p.simpleName } + ")" }
            addLog("[4d] preset $preset: FAIL — AudioPolicy.Builder(Context) NOT found on this phone. " +
                "Constructors found: ${ctors.joinToString("; ")}. No no-arg fallback is used (AOSP has no no-arg constructor).")
            return null
        } catch (e: Exception) {
            addLog("[4d] preset $preset: FAIL — AudioPolicy.Builder(Context) could not be created: ${e.javaClass.simpleName}: ${e.message}")
            return null
        }
        return runCatching {
            // AOSP examples always set a Looper.
            runCatching {
                val setLooper = findMethod(c.audioPolicyBuilder, "setLooper", Looper::class.java)
                setLooper.invoke(b, Looper.getMainLooper())
                addLog("[4d] preset $preset: setLooper(main) OK")
            }.onFailure { addLog("[4d] preset $preset: setLooper not available: ${it.message}") }
            invokeBuilder(b, "addMix", mix)
            invokeBuilder(b, "build")
        }.onFailure { addLog("[4d] preset $preset: AudioPolicy FAILED: ${it.javaClass.simpleName}: ${it.message}") }
            .getOrNull()
    }

    /** Calls a Builder method by name, with one argument or none. */
    private fun invokeBuilder(builder: Any, name: String, arg: Any? = null): Any? {
        if (arg == null) {
            val m = builder.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.isEmpty() }
                ?: runCatching { builder.javaClass.getMethod(name) }.getOrNull()
                ?: builder.javaClass.getDeclaredMethod(name).also { it.isAccessible = true }
            return m.invoke(builder)
        }
        val m = builder.javaClass.methods.firstOrNull {
            it.name == name && it.parameterTypes.size == 1 &&
                (it.parameterTypes[0].isInstance(arg) || it.parameterTypes[0].isAssignableFrom(arg.javaClass) ||
                    (it.parameterTypes[0] == Int::class.javaPrimitiveType && arg is Int))
        } ?: runCatching { builder.javaClass.getMethod(name, arg.javaClass) }.getOrNull()
            ?: builder.javaClass.declaredMethods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }
                ?.also { it.isAccessible = true }
            ?: throw NoSuchMethodException("$name on ${builder.javaClass.simpleName}")
        return m.invoke(builder, arg)
    }

    /**
     * Unregisters a policy that is KNOWN to be registered (register
     * returned 0). Removes it from the registered set on success; on
     * failure it stays in the set so cleanup reports it as a LEAK.
     */
    private fun unregisterPolicy(am: AudioManager, policy: Any, preset: Int) {
        runCatching {
            val m = findMethod(AudioManager::class.java, "unregisterAudioPolicy", policy.javaClass)
            m.invoke(am, policy)
            synchronized(policyLock) {
                registeredPolicies.remove(policy)
                if (currentPolicy === policy) currentPolicy = null
            }
            addLog("[4] preset $preset: unregisterAudioPolicy() OK")
        }.onFailure { addLog("[4] preset $preset: unregister FAILED: ${it.message} — policy may still be registered") }
    }

    /**
     * Outcome of one register attempt.
     * `unknown` = the call never answered, policy state unknown.
     * `usable` = the policy is registered AND still registered right now,
     * so an AudioTrack may be created from it. A LATE success (code 0
     * after the timeout) is NOT usable: resolvePendingRegistration
     * already unregistered that policy, so Phase B must never treat
     * code 0 alone as success.
     */
    private data class RegisterOutcome(
        val code: Int?,
        val timedOut: Boolean,
        val lateResolved: Boolean,
        val unknown: Boolean,
        val usable: Boolean
    )

    /**
     * registerAudioPolicy() with an 8000 ms timeout — and a real cleanup
     * plan for the timeout case (v4).
     *
     * - On timeout, the background task is NOT killed with shutdownNow():
     *   a Binder/reflection call already in flight may ignore interruption,
     *   so "cancelled" would be a lie. Instead the worker WAITS for the
     *   real outcome (up to 30 s more, in 5 s slices).
     * - If it registers LATE (code 0 after the timeout), the policy is
     *   unregistered immediately and the late result is logged.
     * - If it never answers (8 s + 30 s), the policy is recorded as
     *   UNKNOWN state and the run must abort. unregisterAudioPolicy() is
     *   NEVER called for it, because registration was never confirmed —
     *   instead a LEAK WARNING is logged.
     * - The executor is shut down with plain shutdown() only after the
     *   future is done; shutdown() does not cancel an in-flight call, it
     *   just releases the thread once it finishes.
     * - v6: the returned `usable` flag is true ONLY when code == 0 AND
     *   the answer arrived within the 8 s timeout. A late success is
     *   unregistered before it is returned, so it is never usable.
     */
    private fun registerWithTimeout(am: AudioManager, policy: Any, preset: Int): RegisterOutcome {
        val executor = Executors.newSingleThreadExecutor()
        val future = executor.submit(Callable<Int> {
            val m = findMethod(AudioManager::class.java, "registerAudioPolicy", policy.javaClass)
            m.invoke(am, policy) as Int
        })
        try {
            val t0 = System.currentTimeMillis()
            val code = future.get(POLICY_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            addLog("[4e] preset $preset: registerAudioPolicy() returned $code in ${System.currentTimeMillis() - t0}ms (0 = success)")
            return RegisterOutcome(code, false, false, false, code == 0)
        } catch (e: java.util.concurrent.TimeoutException) {
            addLog("[4e] preset $preset: registerAudioPolicy() TIMEOUT — no answer within ${POLICY_TIMEOUT_MS}ms. " +
                "Registration is still in flight; unregister will NOT be called until its outcome is known. " +
                "shutdownNow() is NOT used — it cannot stop an in-flight Binder/reflection call.")
            return resolvePendingRegistration(future, am, policy, preset)
        } catch (e: Exception) {
            addLog("[4e] preset $preset: registerAudioPolicy() ERROR ${e.javaClass.simpleName}: ${e.message} — treated as failed, nothing registered")
            return RegisterOutcome(null, false, false, false, false)
        } finally {
            executor.shutdown()
        }
    }

    /** Waits (up to 30 s, in 5 s slices) for a timed-out registration to answer. */
    private fun resolvePendingRegistration(
        future: Future<Int>,
        am: AudioManager,
        policy: Any,
        preset: Int
    ): RegisterOutcome {
        val deadline = System.currentTimeMillis() + LATE_RESOLVE_MS
        while (System.currentTimeMillis() < deadline) {
            try {
                val code = future.get(5000, TimeUnit.MILLISECONDS)
                addLog("[4e] preset $preset: LATE result after timeout — registerAudioPolicy() returned $code")
                if (code == 0) {
                    addLog("[4e] preset $preset: LATE REGISTER — policy registered AFTER the 8s timeout. Unregistering it now. NOTE: this late registration is NOT usable — the policy is gone before any AudioTrack can be created from it.")
                    unregisterPolicy(am, policy, preset)
                } else {
                    addLog("[4e] preset $preset: late result is a failure (code $code) — nothing is registered")
                }
                return RegisterOutcome(code, true, true, false, false)
            } catch (e: java.util.concurrent.TimeoutException) {
                val waitedSec = (LATE_RESOLVE_MS - (deadline - System.currentTimeMillis())) / 1000
                addLog("[4e] preset $preset: still waiting for the late registration result (${waitedSec}s of ${LATE_RESOLVE_MS / 1000}s)…")
            } catch (e: Exception) {
                addLog("[4e] preset $preset: late registration wait failed: ${e.javaClass.simpleName}: ${e.message}")
                break
            }
        }
        addLog("[4e] preset $preset: LEAK WARNING — registration STILL in flight after ${POLICY_TIMEOUT_MS + LATE_RESOLVE_MS}ms. " +
            "Policy state is UNKNOWN: it may register later and stay registered. " +
            "This policy will NOT be unregistered blindly (registration was never confirmed). Aborting this test run.")
        synchronized(policyLock) { pendingPolicies.add(policy to preset) }
        leakSuspected = true
        return RegisterOutcome(null, true, false, true, false)
    }

    /** Plays the test tone continuously until stop is requested or the time limit is hit. */
    private fun playToneLoop(track: AudioTrack, rate: Int, maxHoldSeconds: Int) {
        // v7: the STOP check and track.play() are ONE atomic step under
        // toneArmLock. In v6 the check (old line 925) and play() (old line
        // 936) were NOT under a common lock, so STOP could land between
        // them and the tone could start for a moment after STOP.
        //
        // The lock is held ONLY for the check + play() call (a few ms) —
        // NEVER for the write loop below. So STOP is never blocked for
        // long: if STOP is pressed while the worker is inside this block,
        // cleanup waits a few ms for play() to finish, then releases the
        // track. The loop itself checks stopRequested every chunk (~85 ms)
        // and a write on a released track throws, so the tone stops fast.
        val started: Boolean = synchronized(toneArmLock) {
            if (stopRequested || cleanupStarted) {
                addLog("[5] stop was requested before the tone started — not playing")
                false
            } else {
                try {
                    track.play()
                    true
                } catch (e: Exception) {
                    addLog("[5] track.play() failed (${e.javaClass.simpleName}) — no tone")
                    false
                }
            }
        }
        if (!started) return
        val deadlineMs = System.currentTimeMillis() + maxHoldSeconds * 1000L
        var lastLogMs = 0L
        runCatching {
            val totalPerChunk = 4096
            val chunk = ShortArray(totalPerChunk)
            var phase = 0.0
            val step = 2.0 * PI * TEST_TONE_HZ / rate
            while (!stopRequested && System.currentTimeMillis() < deadlineMs) {
                for (i in 0 until totalPerChunk) {
                    chunk[i] = (sin(phase) * 16000).toInt().toShort()
                    phase += step
                }
                val w = try {
                    track.write(chunk, 0, totalPerChunk)
                } catch (e: Exception) {
                    addLog("[5] AudioTrack.write failed (${e.javaClass.simpleName}) — stopping tone")
                    break
                }
                if (w < 0) {
                    addLog("[5] AudioTrack.write error $w — stopping tone")
                    break
                }
                val now = System.currentTimeMillis()
                if (now - lastLogMs > 30000L) {
                    lastLogMs = now
                    addLog("[5] tone still playing… (STOP TEST to end it)")
                }
            }
            if (stopRequested) addLog("[5] tone stopped by user (STOP TEST)")
            else addLog("[5] tone stopped: max hold time (${maxHoldSeconds}s) reached")
        }.onFailure { addLog("[5] playToneLoop FAILED: ${it.javaClass.simpleName}: ${it.message}") }
    }
}
