# v25.4 Shizuku connection status

- Settings now displays `SHIZUKU` in green only after the app's Shizuku UserService bridge has actually connected.
- Disconnected state is red; pending bridge state is amber.
- On app launch, if Shizuku Binder is running and permission is already granted, the app automatically requests its diagnostic UserService bridge.
- The status is based on the app bridge callback, not merely the Shizuku app being open or permission being granted.
- This is a source-only change. Build and device runtime verification are still required.
