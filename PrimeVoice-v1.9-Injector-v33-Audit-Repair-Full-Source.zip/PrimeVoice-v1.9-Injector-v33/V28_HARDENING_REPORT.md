# Prime Voice v28 — Handshake Timeout & APK Verification Hardening

## Changes applied
1. The 8-second Shizuku timeout remains active after `onServiceConnected` and is cleared only after the remote `getDiagnostics()` handshake succeeds or fails. This closes the prior gap where a connected-but-unresponsive Binder could remain pending indefinitely.
2. On handshake timeout/failure, the app clears stale bridge state, attempts to unbind the stale UserService connection, and schedules recovery.
3. Reconnect scheduling now has a single-pending guard to prevent duplicate delayed reconnect jobs from stacking.
4. Version metadata updated to versionCode 35 / `1.9 Injector v28 Handshake Timeout Hardening`.
5. GitHub Actions serializes/cancels overlapping builds, applies a job timeout, prints Gradle stack traces, and runs an APK verification script before publishing the artifact.
6. APK verification checks the built APK for applicationId, merged Shizuku Provider declaration and authority, plus DEX class descriptors for ShizukuProvider, MainActivity and ShizukuAudioUserService.

## Verification status
- Source edits and workflow files: applied.
- ZIP integrity: checked after packaging.
- Android Gradle build: not run in this environment.
- APK/DEX/merged-manifest verification: configured to run in GitHub Actions after a build.
- Redmi 14C runtime: not tested here.
- ME ONLY / TEAMMATES ONLY / BOTH / Social Call: no new device test was performed.

This update hardens connection recovery and build verification. It does not establish that hidden AudioPolicy injection works on every Android 16 / HyperOS device, nor that teammates receive audio in every call/game configuration.
