# v25.2 Window Start UI + Live FX removal

- Removed the Live FX tab from bottom navigation and removed its screen/effect controls and LiveAudioEngine implementation.
- The app now opens on the Soundboard tab.
- Added a prominent `WINDOW START` button to the top Audio Status card. Tapping it starts FloatingMenuService when overlay permission is already granted; otherwise it opens Android's overlay-permission settings and tells the user to tap again after granting permission.
- Existing Soundboard, Music/Fun folder handling, Recorder, Settings, Shizuku provider dependency, and injector code were left unchanged.
- VersionCode 31; versionName `1.9 Injector v25.2 Window Start UI`.

Build/runtime status: source edited and ZIP structure checked. Android Gradle build and on-device runtime verification have not been performed in this environment.
