package com.primevoice.app

import androidx.core.content.ContextCompat

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import rikka.shizuku.Shizuku
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.RemoteException
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.random.Random

/** Floating-only soundboard. The full player is created only after a clip is selected here. */
class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelWrapper: ScrollView? = null
    private var player: MediaPlayer? = null
    private var seek: SeekBar? = null
    private var elapsed: TextView? = null
    private var total: TextView? = null
    private var playPause: Button? = null
    private var currentIndex = -1
    private var clips: List<Pair<String, Uri>> = emptyList()
    // v10: two voice folders. musicClips / funClips are the two lists;
    // `clips` is always the DISPLAYED folder's list (library panel).
    // currentFolder = the folder open in the library (also the import
    // target, shared with MainActivity through prefs). playingFolder =
    // the folder of the clip loaded in the player (null: nothing loaded).
    // currentIndex is the index inside the PLAYING folder's list.
    private var musicClips: List<Pair<String, Uri>> = emptyList()
    private var funClips: List<Pair<String, Uri>> = emptyList()
    private var currentFolder: VoiceFolder = VoiceFolder.MUSIC
    private var playingFolder: VoiceFolder? = null
    private var playerVisible = false
    // v9 Auto Next + Infinite Loop:
    // - shuffleOn: Shuffle mode (toggled by the ⇄ button). Auto Next
    //   follows it; manual Next / Previous always follow playlist order.
    // - playerGeneration: bumped on every releasePlayer(). A completion
    //   listener captures the generation of ITS player and must ignore
    //   the callback when the generation changed — so a stale listener
    //   can never release or change the NEW player.
    private var shuffleOn = false
    private var playerGeneration = 0
    // v11: live folder sync. Kept in a field: SharedPreferences holds
    // listeners weakly, so a local listener could be garbage-collected
    // and stop syncing.
    private var prefsListener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    // 0 = ME ONLY, 1 = TEAMMATES ONLY, 2 = BOTH (Bluetooth monitor + injector).
    private var outputMode = 0
    private var socialCallEnabled = false
    private val outputModeTeam: Boolean get() = outputMode == 1 || outputMode == 2
    // Injected-player state: explicit fields required by the player UI and PCM streamer.
    private var pcmStreamer: PcmClipStreamer? = null
    private var injectedStatusText: TextView? = null
    private var injectedDurationMs: Int = 0
    private var injectedPlaybackFailed: Boolean = false

    private var injectorApi: IShizukuAudioBridge? = null
    private var injectorDeathBinder: IBinder? = null
    private var injectorDeathRecipient: IBinder.DeathRecipient? = null
    private var injectorBindRequested = false
    private var injectorHandshakeComplete = false
    private var injectorReconnectAttempt = 0
    private var injectorReconnectScheduled = false
    private val injectorHeartbeatInFlight = AtomicBoolean(false)
    private val pendingInjectorCallbacks = mutableListOf<(IShizukuAudioBridge?) -> Unit>()
    private val injectorArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(this, ShizukuAudioUserService::class.java))
            .daemon(false).processNameSuffix("audio").debuggable(BuildConfig.DEBUG).version(4)
    }
    private val injectorConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            if (isFinishingService) return
            if (service == null) {
                handleInjectorDisconnect("Shizuku returned a null audio Binder")
                return
            }
            clearInjectorDeathRecipient()
            val recipient = IBinder.DeathRecipient {
                handler.post {
                    if (injectorDeathBinder === service) {
                        handleInjectorDisconnect("Shizuku audio UserService Binder died")
                    }
                }
            }
            try {
                service.linkToDeath(recipient, 0)
                injectorDeathBinder = service
                injectorDeathRecipient = recipient
            } catch (_: RemoteException) {
                handleInjectorDisconnect("Shizuku audio UserService died during bind")
                return
            }
            val api = IShizukuAudioBridge.Stub.asInterface(service)
            injectorApi = api
            injectorBindRequested = true
            injectorHandshakeComplete = false
            handler.removeCallbacks(injectorBindTimeout)
            handler.postDelayed(injectorBindTimeout, 8000L)
            // A Binder callback is not a successful connection until the remote
            // service answers a real transaction. Never block the main thread.
            thread(name = "PrimeVoiceFloatingHandshake", isDaemon = true) {
                val result = runCatching { api.getDiagnostics() }
                handler.post {
                    if (injectorApi !== api || !injectorBindRequested) return@post
                    handler.removeCallbacks(injectorBindTimeout)
                    result.onSuccess {
                        injectorHandshakeComplete = true
                        injectorReconnectAttempt = 0
                        injectorReconnectScheduled = false
                        handler.removeCallbacks(injectorReconnectTask)
                        val callbacks = pendingInjectorCallbacks.toList()
                        pendingInjectorCallbacks.clear()
                        callbacks.forEach { cb -> runCatching { cb(api) } }
                    }.onFailure {
                        handleInjectorDisconnect("Shizuku handshake failed: ${it.message ?: it.javaClass.simpleName}")
                    }
                }
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            handler.post { handleInjectorDisconnect("Shizuku audio UserService disconnected") }
        }
        override fun onBindingDied(name: ComponentName?) {
            handler.post { handleInjectorDisconnect("Shizuku audio UserService binding died") }
        }
        override fun onNullBinding(name: ComponentName?) {
            handler.post { handleInjectorDisconnect("Shizuku audio UserService returned null binding") }
        }
    }
    private val handler = Handler(Looper.getMainLooper())
    private val injectorBindTimeout = Runnable {
        if (injectorBindRequested && !injectorHandshakeComplete) {
            handleInjectorDisconnect("Shizuku UserService bind/handshake timed out (8s)")
        }
    }
    private val injectorReconnectTask = Runnable {
        injectorReconnectScheduled = false
        if (!isFinishingService && injectorApi == null) ensureInjectorBound()
    }
    private val injectorHeartbeat = object : Runnable {
        override fun run() {
            val api = injectorApi
            if (api != null && injectorBindRequested && injectorHeartbeatInFlight.compareAndSet(false, true)) {
                thread(name = "PrimeVoiceFloatingHeartbeat", isDaemon = true) {
                    val result = runCatching { if (api.asBinder().isBinderAlive) api.getDiagnostics() else error("Binder not alive") }
                    injectorHeartbeatInFlight.set(false)
                    handler.post {
                        if (injectorApi === api && result.isFailure) {
                            handleInjectorDisconnect("Shizuku heartbeat failed")
                        }
                    }
                }
            }
            if (!isFinishingService) handler.postDelayed(this, 10000L)
        }
    }
    private val shizukuBinderReceivedListener = Shizuku.OnBinderReceivedListener {
        handler.post { if (playerVisible && outputModeTeam && injectorApi == null) ensureInjectorBound() }
    }
    private val shizukuBinderDeadListener = Shizuku.OnBinderDeadListener {
        handler.post { handleInjectorDisconnect("Shizuku manager Binder died", unbind = false) }
    }

    private fun clearInjectorDeathRecipient() {
        runCatching {
            val binder = injectorDeathBinder
            val recipient = injectorDeathRecipient
            if (binder != null && recipient != null) binder.unlinkToDeath(recipient, 0)
        }
        injectorDeathBinder = null
        injectorDeathRecipient = null
    }

    private fun handleInjectorDisconnect(reason: String, unbind: Boolean = true) {
        handler.removeCallbacks(injectorBindTimeout)
        clearInjectorDeathRecipient()
        val hadBinding = injectorBindRequested
        injectorApi = null
        injectorBindRequested = false
        injectorHandshakeComplete = false
        if (unbind && hadBinding) runCatching { Shizuku.unbindUserService(injectorArgs, injectorConnection, true) }
        val callbacks = pendingInjectorCallbacks.toList()
        pendingInjectorCallbacks.clear()
        callbacks.forEach { cb -> runCatching { cb(null) } }
        if (playerVisible && outputModeTeam) {
            injectedStatusText?.text = "$reason • tap Play to retry"
        }
        if (!isFinishingService) scheduleInjectorReconnect()
    }

    private fun scheduleInjectorReconnect() {
        if (injectorReconnectScheduled || isFinishingService) return
        if (!runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)) return
        if (injectorReconnectAttempt >= 5) {
            injectedStatusText?.text = "Shizuku reconnect paused after 5 attempts. Reopen the player to retry."
            return
        }
        val delay = (1000L shl injectorReconnectAttempt.coerceIn(0, 4)).coerceAtMost(16000L)
        injectorReconnectAttempt += 1
        injectorReconnectScheduled = true
        handler.removeCallbacks(injectorReconnectTask)
        handler.postDelayed(injectorReconnectTask, delay)
    }
    private val tick = object : Runnable {
        override fun run() {
            val mp = player
            if (mp != null) {
                try {
                    val pos = mp.currentPosition
                    seek?.let { if (!it.isPressed) it.progress = pos }
                    elapsed?.text = time(pos)
                    total?.text = time(mp.duration)
                } catch (_: Exception) { }
                handler.postDelayed(this, 200)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startPlaybackForegroundNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        reloadClips()
        val prefs = getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE)
        outputMode = prefs.getInt("audio_output_mode", if (prefs.getBoolean("team_output_mode", false)) 1 else 0).coerceIn(0, 2)
        socialCallEnabled = prefs.getBoolean("social_call_enabled", false)
        // v11: live folder sync. MainActivity writes selected_folder too;
        // when it changes elsewhere, re-render the library panel if it
        // is showing, so the two folder tabs never disagree. Changes
        // this service makes itself are ignored (currentFolder already
        // matches). The player panel is never yanked away: while a clip
        // plays, the folder change only takes effect at the next library
        // open. Views are touched on the main thread via handler.post.
        prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "social_call_enabled") {
                handler.post {
                    socialCallEnabled = getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE).getBoolean("social_call_enabled", false)
                    if (panel != null && !playerVisible) showLibraryPanel()
                }
            }
            if (key == VoiceFolders.KEY_SELECTED) {
                handler.post {
                    val newFolder = VoiceFolders.selectedFolder(this)
                    if (newFolder != currentFolder && panel != null && !playerVisible) {
                        currentFolder = newFolder
                        reloadClips()
                        showLibraryPanel()
                    }
                }
            }
        }
        getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefsListener)
        runCatching { Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener) }
        runCatching { Shizuku.addBinderDeadListener(shizukuBinderDeadListener) }
        handler.postDelayed(injectorHeartbeat, 10000L)
        showBubble()
        // ME ONLY uses local playback and must not request Shizuku access.
        if (outputModeTeam) ensureInjectorBound()
    }

    private fun startPlaybackForegroundNotification() {
        val channelId = "prime_voice_floating_playback"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Prime Voice floating player", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the floating soundboard available during playback"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else Notification.Builder(this)
        val notification = builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Prime Voice").setContentText("Floating player is active")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(1201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1201, notification)
    }

    private fun ensureInjectorBound(onReady: ((IShizukuAudioBridge?) -> Unit)? = null) {
        val current = injectorApi
        if (current != null && injectorHandshakeComplete && current.asBinder().isBinderAlive) {
            onReady?.invoke(current)
            return
        }
        if (onReady != null) pendingInjectorCallbacks.add(onReady)
        if (injectorBindRequested) return
        val allowed = runCatching {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (!allowed) {
            val callbacks = pendingInjectorCallbacks.toList()
            pendingInjectorCallbacks.clear()
            callbacks.forEach { cb -> runCatching { cb(null) } }
            Toast.makeText(this, "Shizuku is unavailable or permission is missing.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            injectorBindRequested = true
            injectorHandshakeComplete = false
            Shizuku.bindUserService(injectorArgs, injectorConnection)
            handler.removeCallbacks(injectorBindTimeout)
            handler.postDelayed(injectorBindTimeout, 8000L)
        } catch (e: Exception) {
            injectorBindRequested = false
            val callbacks = pendingInjectorCallbacks.toList()
            pendingInjectorCallbacks.clear()
            callbacks.forEach { cb -> runCatching { cb(null) } }
            Toast.makeText(this, "Shizuku bind failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            scheduleInjectorReconnect()
        }
    }

    private fun reloadClips() {
        VoiceFolders.migrateIfNeeded(this)
        currentFolder = VoiceFolders.selectedFolder(this)
        musicClips = VoiceFolders.loadClips(this, VoiceFolder.MUSIC)
            .map { it.name to it.uri }.sortedBy { it.first.lowercase(Locale.getDefault()) }
        funClips = VoiceFolders.loadClips(this, VoiceFolder.FUN)
            .map { it.name to it.uri }.sortedBy { it.first.lowercase(Locale.getDefault()) }
        clips = clipsFor(currentFolder)
    }

    private fun clipsFor(folder: VoiceFolder): List<Pair<String, Uri>> =
        if (folder == VoiceFolder.FUN) funClips else musicClips

    @Suppress("DEPRECATION")
    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun params(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.END): WindowManager.LayoutParams =
        WindowManager.LayoutParams(width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity; x = 18; y = 240 }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        setStroke(dp(1), Color.rgb(65, 91, 105))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        if (bubble != null) return
        val v = TextView(this).apply {
            text = "PV"; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(20, 190, 215)); setStroke(dp(2), Color.WHITE) }
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            setOnTouchListener { touched, event ->
                val lp = touched.layoutParams as? WindowManager.LayoutParams ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                        if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                        val metrics = resources.displayMetrics
                        val maxX = (metrics.widthPixels - touched.width).coerceAtLeast(0)
                        val maxY = (metrics.heightPixels - touched.height).coerceAtLeast(0)
                        lp.x = (startX - dx).coerceIn(0, maxX); lp.y = (startY + dy).coerceIn(0, maxY)
                        runCatching { wm.updateViewLayout(touched, lp) }; true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                    else -> true
                }
            }
        }
        runCatching { wm.addView(v, params(dp(58), dp(58))) }.onSuccess { bubble = v }.onFailure { stopSelf() }
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        if (playerVisible) { showPlayer(); return }
        showLibraryPanel()
    }

    private fun basePanel(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(Color.rgb(15, 25, 35))
        }
        // Header controls: minimize keeps the bubble and playback alive;
        // close stops playback and removes the floating service entirely.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = title; textSize = 16f; setTextColor(Color.rgb(32, 221, 245))
            typeface = Typeface.DEFAULT_BOLD; maxLines = 1
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        fun headerControl(label: String, close: Boolean, action: () -> Unit) {
            val control = Button(this).apply {
                text = label; isAllCaps = false; textSize = 16f
                setTextColor(Color.WHITE)
                background = rounded(if (close) Color.rgb(75, 43, 48) else Color.rgb(27, 48, 62), 30f)
                setOnClickListener { action() }
            }
            header.addView(control, LinearLayout.LayoutParams(dp(42), dp(38)).apply {
                leftMargin = dp(5)
            })
        }
        headerControl("−", false) { minimizePanel() }
        headerControl("×", true) { closeFloatingMenu() }
        root.addView(header)
        return root
    }

    private fun minimizePanel() {
        // Keep playerVisible true while a player exists. This preserves
        // Music auto-next and lets tapping the PV bubble reopen the player.
        removePanel()
    }

    private fun closeFloatingMenu() {
        // Explicit close is different from minimize: stop both ordinary
        // MediaPlayer and injected PCM playback, then remove the bubble.
        releasePlayer()
        playerVisible = false
        playingFolder = null
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
        bubble = null
        stopSelf()
    }

    private fun addPanel(root: LinearLayout, height: Int = WindowManager.LayoutParams.WRAP_CONTENT) {
        removePanel()
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = true
            addView(root, FrameLayout.LayoutParams(-1, -2))
        }
        val screenHeight = resources.displayMetrics.heightPixels
        val maxPanelHeight = (screenHeight * 0.78f).toInt().coerceAtLeast(dp(220))
        val requestedHeight = if (height == WindowManager.LayoutParams.WRAP_CONTENT) maxPanelHeight else height.coerceAtMost(maxPanelHeight)
        // Keep `panel` as the actual attached root so removePanel() removes the wrapper below.
        panel = root
        scroller.tag = "prime_voice_panel_wrapper"
        panelWrapper = scroller
        runCatching { wm.addView(scroller, params(dp(300), requestedHeight)) }.onFailure { panel = null; panelWrapper = null }
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f
            setTextColor(Color.WHITE); background = rounded(Color.rgb(27, 48, 62), 14f)
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(6) })
    }

    private fun showLibraryPanel() {
        reloadClips()
        val root = basePanel("PRIME VOICE • ${currentFolder.label.uppercase(Locale.getDefault())}")
        // v10 folder tabs. Music = playlist (Auto Next + Loop), Fun =
        // one-shot (plays once, stops). The selected tab is highlighted.
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun folderTab(folder: VoiceFolder, label: String): Button = Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f
            setTextColor(if (folder == currentFolder) Color.BLACK else Color.WHITE)
            background = rounded(if (folder == currentFolder) Color.rgb(32, 221, 245) else Color.rgb(27, 48, 62), 14f)
            setOnClickListener { switchFolder(folder) }
        }
        tabs.addView(folderTab(VoiceFolder.MUSIC, "♪ Music"), LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(0, 0, dp(3), dp(6)) })
        tabs.addView(folderTab(VoiceFolder.FUN, "☺ Fun"), LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, 0, dp(6)) })
        root.addView(tabs)
        addButton(root, "Social Call: ${if (socialCallEnabled) "ON" else "OFF"}") {
            socialCallEnabled = !socialCallEnabled
            getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE).edit().putBoolean("social_call_enabled", socialCallEnabled).apply()
            if (!socialCallEnabled) {
                // Turning the master switch OFF must stop an already-running
                // Social Call stream, not merely affect the next clip.
                pcmStreamer?.stop()
                pcmStreamer = null
                playerVisible = false
            }
            Toast.makeText(this, if (socialCallEnabled) "Social Call ON — use during supported Internet calls" else "Social Call OFF — active Social Call playback stopped", Toast.LENGTH_LONG).show()
            showLibraryPanel()
        }
        addButton(root, "Output: ${outputModeLabel()}") {
            outputMode = (outputMode + 1) % 3
            if (outputMode == 2 && Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "BOTH mode needs Bluetooth permission. Open Prime Voice and allow Bluetooth / Nearby devices.", Toast.LENGTH_LONG).show()
            }
            getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE).edit()
                .putInt("audio_output_mode", outputMode)
                .putBoolean("team_output_mode", outputModeTeam).apply()
            if (outputModeTeam) ensureInjectorBound()
            showLibraryPanel()
        }
        addButton(root, "Close menu") { removePanel() }
        if (clips.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (currentFolder == VoiceFolder.FUN) "No fun clips yet. Import audio in Prime Voice (Fun folder) first."
                else "No music yet. Import audio in Prime Voice (Music folder) first."
                setTextColor(Color.LTGRAY); textSize = 13f
            }
            root.addView(empty)
        } else {
            clips.forEachIndexed { index, clip -> addButton(root, "▶  ${clip.first}") { startClip(currentFolder, index) } }
        }
        addButton(root, "Open Prime Voice app") {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (launch != null) startActivity(launch)
        }
        addPanel(root)
    }

    /**
     * v10: switching folder only changes which list is shown (and the
     * import target, shared through prefs). It does NOT release the
     * player: the v9 playerVisible guard + the playingFolder check in
     * the completion listener already stop the old listener from
     * auto-playing in the new folder — the playing clip just finishes
     * and stops. Tapping a clip in the new folder releases the old
     * player (generation bump) and starts the new one.
     */
    private fun switchFolder(folder: VoiceFolder) {
        if (folder == currentFolder) return
        currentFolder = folder
        VoiceFolders.setSelectedFolder(this, folder)
        reloadClips()
        showLibraryPanel()
    }

    private fun outputModeLabel(): String = when (outputMode) {
        1 -> "TEAMMATES ONLY"
        2 -> "BOTH (Bluetooth + Team)"
        else -> "ME ONLY"
    }

    private fun startClip(folder: VoiceFolder, index: Int) {
        val list = clipsFor(folder)
        if (socialCallEnabled && !outputModeTeam) {
            Toast.makeText(this, "Social Call is ON. Select TEAMMATES ONLY or BOTH before playing a clip.", Toast.LENGTH_LONG).show()
            return
        }
        if (outputModeTeam) { startInjectedClip(folder, index); return }
        if (index !in list.indices) return
        val (name, uri) = list[index]
        try {
            releasePlayer()
            currentIndex = index
            playingFolder = folder
            // The generation of THIS player: the listener below captures
            // it and must ignore the callback if it changed meanwhile.
            val gen = playerGeneration
            player = MediaPlayer().apply {
                setDataSource(this@FloatingMenuService, uri)
                setOnPreparedListener {
                    it.start(); playerVisible = true; showPlayer(); handler.removeCallbacks(tick); handler.post(tick)
                }
                setOnCompletionListener { mp ->
                    // v9 guards (unchanged): only the CURRENT player's
                    // listener may act. Identity + generation must BOTH
                    // match: a stale listener (player replaced by Next /
                    // Previous / a new clip, or released by Stop / Close
                    // / onDestroy) returns here and can never release or
                    // change the new player.
                    if (mp !== player || gen != playerGeneration) return@setOnCompletionListener
                    // v10: playback logic is per FOLDER, not per name.
                    // `folder` is captured when the clip starts, so even
                    // if the user switched folders while it played, the
                    // old listener can never auto-play in the new folder.
                    // No Auto Next when (a) the panel is hidden (Close /
                    // Playlist — v9), or (b) this clip is from the Fun
                    // folder (one-shot rule). In both cases the clip just
                    // ends: rewind and show ▶.
                    if (!playerVisible || folder == VoiceFolder.FUN) {
                        try { mp.seekTo(0) } catch (_: Exception) { }
                        playPause?.text = "▶"
                        seek?.progress = 0
                        elapsed?.text = "0:00"
                        return@setOnCompletionListener
                    }
                    autoNext()  // Music only.
                }
                setOnErrorListener { _, _, _ -> showLibraryPanel(); true }
                prepareAsync()
            }
        } catch (_: Exception) { releasePlayer(); showLibraryPanel() }
    }

    private fun startInjectedClip(folder: VoiceFolder, index: Int) {
        val list = clipsFor(folder)
        if (index !in list.indices) return
        releasePlayer()
        pcmStreamer?.stop(); pcmStreamer = null
        currentIndex = index; playingFolder = folder; playerVisible = true
        val generation = playerGeneration
        showInjectedPlayer(list[index].first, "Connecting to Shizuku Audio UserService…")
        ensureInjectorBound { api ->
            if (!playerVisible || generation != playerGeneration || isFinishingService) return@ensureInjectorBound
            if (api == null) {
                playerVisible = false
                showLibraryPanel()
                Toast.makeText(this, "Shizuku connection failed. Check Shizuku permission and retry.", Toast.LENGTH_LONG).show()
                return@ensureInjectorBound
            }
            startInjectedClipWithApi(folder, index, api)
        }
    }

    private fun startInjectedClipWithApi(folder: VoiceFolder, index: Int, api: IShizukuAudioBridge) {
        val list = clipsFor(folder)
        if (index !in list.indices) return
        val (name, uri) = list[index]
        injectedPlaybackFailed = false
        injectedDurationMs = 0
        pcmStreamer = PcmClipStreamer(this, api,
            onStatus = { message ->
                if (message.startsWith("Injection failed:")) injectedPlaybackFailed = true
                handler.post { injectedStatusText?.text = message }
            },
            onFinished = {
                handler.post {
                    pcmStreamer = null
                    if (playerVisible && folder == VoiceFolder.MUSIC && !isFinishingService && !injectedPlaybackFailed) autoNext()
                    else if (playerVisible) showInjectedPlayer(name, if (injectedPlaybackFailed) "Playback failed — check Bluetooth / Shizuku" else "Clip finished")
                }
            },
            onProgress = { positionMs, durationMs ->
                handler.post {
                    if (playerVisible && outputModeTeam) {
                        injectedDurationMs = durationMs
                        seek?.let { bar ->
                            if (!bar.isPressed) {
                                if (durationMs > 0) bar.max = durationMs
                                bar.progress = positionMs.coerceAtMost(bar.max)
                            }
                        }
                        elapsed?.text = time(positionMs)
                        total?.text = if (durationMs > 0) time(durationMs) else "--:--"
                    }
                }
            },
            monitorOnBluetooth = (outputMode == 2),
            socialCallMode = socialCallEnabled)
        showInjectedPlayer(name, if (socialCallEnabled) "Starting Social Call VOICE_COMMUNICATION route…" else if (outputMode == 2) "Starting Bluetooth + Shizuku routes…" else "Starting Shizuku AudioPolicy route…")
        pcmStreamer?.start(uri)
    }

    @Volatile private var isFinishingService = false

    private fun showInjectedPlayer(name: String, message: String) {
        val root = basePanel(if (outputMode == 2) "BOTH • BLUETOOTH + TEAMMATES" else "TEAMMATES ONLY • INJECTED AUDIO")
        root.addView(TextView(this).apply { text = name; textSize = 14f; setTextColor(Color.WHITE); maxLines = 2 })
        injectedStatusText = TextView(this).apply { text = message; textSize = 11f; setTextColor(Color.LTGRAY) }
        root.addView(injectedStatusText)
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        elapsed = TextView(this).apply { text = "0:00"; setTextColor(Color.WHITE); textSize = 12f }
        total = TextView(this).apply { text = "--:--"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.RIGHT }
        times.addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(total, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(times)
        seek = SeekBar(this).apply {
            max = injectedDurationMs.coerceAtLeast(1)
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(30, 205, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(30, 205, 45))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) elapsed?.text = time(value)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) { }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    pcmStreamer?.seekTo(bar?.progress ?: 0)
                }
            })
        }
        root.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
        addButton(root, "PAUSE / RESUME") {
            injectedStatusText?.text = "Updating audio…"
            pcmStreamer?.togglePauseAsync { paused ->
                injectedStatusText?.text = if (paused) "Paused" else "Resumed"
            }
        }
        addButton(root, "Previous") { previous() }
        addButton(root, "Next") { next(false) }
        addButton(root, "STOP AUDIO") { pcmStreamer?.stop(); pcmStreamer = null; playerVisible = false; showLibraryPanel() }
        addButton(root, "Playlist") { playerVisible = false; showLibraryPanel() }
        addButton(root, "Minimize (audio continues)") { minimizePanel() }
        addPanel(root)
    }

    /**
     * v10 Auto Next + Infinite Loop — MUSIC ONLY. Fun never reaches
     * here (its listener returns early). Shuffle picks only from the
     * Music folder, never from Fun. One Music clip replays itself.
     * Called only from the current player's completion listener
     * (identity + generation checked there).
     */
    private fun autoNext() {
        if (musicClips.isEmpty()) return
        val n = pickNextIndex()
        if (n in musicClips.indices) startClip(VoiceFolder.MUSIC, n)
    }

    private fun pickNextIndex(): Int {
        if (musicClips.isEmpty()) return -1
        if (musicClips.size == 1) return 0
        return if (shuffleOn) {
            var n: Int
            do { n = Random.nextInt(musicClips.size) } while (n == currentIndex)
            n
        } else {
            (currentIndex + 1) % musicClips.size
        }
    }

    private fun showPlayer() {
        val mp = player ?: run { playerVisible = false; showLibraryPanel(); return }
        val name = clipsFor(playingFolder ?: currentFolder).getOrNull(currentIndex)?.first ?: "Now playing"
        val root = basePanel("NOW PLAYING")
        val track = TextView(this).apply { text = name; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1; setPadding(0, 0, 0, dp(5)) }
        root.addView(track)
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        elapsed = TextView(this).apply { text = "0:00"; setTextColor(Color.WHITE); textSize = 12f }
        total = TextView(this).apply { text = time(runCatching { mp.duration }.getOrDefault(0)); setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.RIGHT }
        times.addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f)); times.addView(total, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(times)
        seek = SeekBar(this).apply {
            max = runCatching { mp.duration.coerceAtLeast(1) }.getOrDefault(1)
            progress = runCatching { mp.currentPosition }.getOrDefault(0)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(30, 205, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(30, 205, 45))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) elapsed?.text = time(value) }
                override fun onStartTrackingTouch(bar: SeekBar?) { }
                override fun onStopTrackingTouch(bar: SeekBar?) { runCatching { player?.seekTo(bar?.progress ?: 0) } }
            })
        }
        root.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun control(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE); background = rounded(Color.rgb(27, 48, 62), 40f); setOnClickListener { action() } }
            controls.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        control("|◀") { previous() }
        playPause = Button(this).apply {
            text = if (runCatching { mp.isPlaying }.getOrDefault(false)) "Ⅱ" else "▶"; isAllCaps = false; textSize = 21f
            setTextColor(Color.WHITE); background = rounded(Color.rgb(18, 135, 65), 40f)
            setOnClickListener { togglePlayback() }
        }
        controls.addView(playPause, LinearLayout.LayoutParams(0, dp(58), 1.2f).apply { setMargins(dp(5), dp(3), dp(5), dp(3)) })
        control("▶|") { next(false) }
        root.addView(controls)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        // v11: Shuffle exists ONLY in the Music player. The Fun player
        // has no Shuffle button at all, so Shuffle can never start a
        // Fun voice.
        if (playingFolder == VoiceFolder.MUSIC) {
            val shuffle = Button(this).apply {
                text = if (shuffleOn) "⇄ ✓" else "⇄"; isAllCaps = false; textSize = 18f; setTextColor(Color.WHITE)
                background = rounded(if (shuffleOn) Color.rgb(18, 135, 65) else Color.rgb(27, 48, 62), 14f)
                setOnClickListener { toggleShuffle() }
            }
            bottom.addView(shuffle, LinearLayout.LayoutParams(0, dp(44), 0.7f).apply { setMargins(0, dp(5), dp(3), 0) })
        }
        val list = Button(this).apply { text = "☷ Playlist"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.rgb(27, 48, 62), 14f); setOnClickListener { playerVisible = false; showLibraryPanel() } }
        val close = Button(this).apply { text = "Minimize"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.rgb(27, 48, 62), 14f); setOnClickListener { minimizePanel() } }
        bottom.addView(list, LinearLayout.LayoutParams(0, dp(44), 1.3f).apply { setMargins(dp(3), dp(5), dp(3), 0) })
        bottom.addView(close, LinearLayout.LayoutParams(0, dp(44), 0.8f).apply { setMargins(dp(3), dp(5), 0, 0) })
        root.addView(bottom)
        addPanel(root)
    }

    private fun togglePlayback() {
        val mp = player ?: return
        runCatching { if (mp.isPlaying) mp.pause() else mp.start() }
        playPause?.text = if (runCatching { mp.isPlaying }.getOrDefault(false)) "Ⅱ" else "▶"
    }
    private fun previous() {
        // v10: Previous / Next always work inside the PLAYING folder's
        // list (Music or Fun), never the displayed folder's list.
        val folder = playingFolder ?: currentFolder
        val list = clipsFor(folder)
        if (list.isEmpty()) return
        val pos = runCatching { player?.currentPosition ?: 0 }.getOrDefault(0)
        if (pos > 3000) runCatching { player?.seekTo(0) } else startClip(folder, if (currentIndex <= 0) list.lastIndex else currentIndex - 1)
    }
    private fun next(shuffle: Boolean) {
        val folder = playingFolder ?: currentFolder
        val list = clipsFor(folder)
        if (list.isEmpty()) return
        // v11: a Shuffle random jump is Music-only. A shuffle request
        // while a Fun clip is playing does nothing — no new voice may
        // ever start from Shuffle in Fun.
        if (shuffle && folder != VoiceFolder.MUSIC) return
        val n = if (shuffle && list.size > 1) Random.nextInt(list.size) else (currentIndex + 1) % list.size
        startClip(folder, n)
    }
    /**
     * v9: the ⇄ button now toggles Shuffle mode (it used to jump to a
     * random clip on every tap). Turning Shuffle ON also jumps to a
     * random clip right away (as before); turning it OFF keeps the
     * current clip playing. Auto Next follows the mode; manual Next /
     * Previous always follow playlist order, as before. The button
     * shows its state (green + ✓ when ON) whenever the panel rebuilds.
     * v11: Shuffle is Music-only. The button does not exist in the Fun
     * player, and this function refuses to run while a Fun clip is
     * playing — so Shuffle can never start a Fun voice, in any state.
     */
    private fun toggleShuffle() {
        if (playingFolder != VoiceFolder.MUSIC) return
        shuffleOn = !shuffleOn
        if (shuffleOn) next(true) else showPlayer()
    }
    private fun releasePlayer() {
        handler.removeCallbacks(tick)
        pcmStreamer?.stop(); pcmStreamer = null
        // v9: bump the generation, so any completion listener belonging
        // to this player becomes stale and can never touch the next one.
        playerGeneration++
        runCatching { player?.stop() }; runCatching { player?.release() }
        player = null
    }
    private fun removePanel() {
        try { panelWrapper?.let { wm.removeView(it) } } catch (_: Exception) { }
        panelWrapper = null
        panel = null
        injectedStatusText = null
    }
    private fun time(ms: Int): String {
        val s = ms.coerceAtLeast(0) / 1000
        return String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        isFinishingService = true
        pcmStreamer?.stop(); pcmStreamer = null
        handler.removeCallbacks(injectorBindTimeout)
        handler.removeCallbacks(injectorReconnectTask)
        handler.removeCallbacks(injectorHeartbeat)
        injectorReconnectScheduled = false
        clearInjectorDeathRecipient()
        pendingInjectorCallbacks.clear()
        runCatching { Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener) }
        runCatching { Shizuku.removeBinderDeadListener(shizukuBinderDeadListener) }
        if (injectorBindRequested) runCatching { Shizuku.unbindUserService(injectorArgs, injectorConnection, true) }
        injectorBindRequested = false; injectorHandshakeComplete = false; injectorApi = null
        prefsListener?.let { getSharedPreferences(VoiceFolders.PREFS, MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(it) }
        prefsListener = null
        handler.removeCallbacks(tick); releasePlayer(); removePanel()
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
        bubble = null
        super.onDestroy()
    }
}
