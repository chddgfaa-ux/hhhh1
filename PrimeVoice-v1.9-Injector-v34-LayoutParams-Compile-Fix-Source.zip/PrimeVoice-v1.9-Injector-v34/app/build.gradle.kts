plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.primevoice.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.primevoice.app"
        minSdk = 26
        targetSdk = 35
        // v14 experimental AudioPolicy injector + PCM pipe integration.
        // Retains the v13 folder/import/ZIP-safety behavior.
        versionCode = 41
        versionName = "1.9 Injector v34 LayoutParams Compile Fix"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    // v13 BUILD FIX (see V13_AUDIT_FIXES.md): AGP did not create the
    // compileDebugAidl task even though src/main/aidl holds both AIDL
    // files, so the IShizukuAudioBridge / ICaptureTestBridge stubs were
    // never generated and Kotlin compilation failed with "unresolved
    // reference". Enabling the aidl build feature explicitly makes AGP
    // create the task. No source file changes; the AIDL files themselves
    // are untouched.
    buildFeatures { compose = true; aidl = true; buildConfig = true }
}

// v13 BUILD FIX: exclude the stale collection-ktx:1.2.0 jar from every
// configuration (see the comment on the ui dependency above).
configurations.all {
    exclude(group = "androidx.collection", module = "collection-ktx")
}

android {
    // v13 BUILD FIX (see V13_AUDIT_FIXES.md): the Kotlin-multiplatform
    // jars lifecycle-common:2.8.3 and annotation:1.8.1 both ship the same
    // KMP metadata files (commonMain/ and nonJvmMain/ linkdata, e.g.
    // .../package_androidx/0_androidx.knm and .../linkdata/module,
    // byte-identical in both jars), and :app:mergeDebugJavaResource fails
    // on the duplicates. Those two directories hold only Kotlin/Native
    // metadata, never read by an Android JVM app (the JVM classes live
    // at the jar root), so they are excluded from the packaged resources.
    // No code or feature changes.
    packaging {
        resources {
            excludes += "commonMain/**"
            excludes += "nonJvmMain/**"
            // Same family: KMP project-structure metadata shipped
            // byte-identically by collection:1.4.0, lifecycle-common:2.8.3
            // and annotation:1.8.1. Also unused by an Android JVM app.
            excludes += "META-INF/kotlin-project-structure-metadata.json"
        }
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    // v13 BUILD FIX (see V13_AUDIT_FIXES.md): ui-unit-android:1.7.6 pulls in
    // androidx.collection:collection-ktx:1.2.0, whose ArrayMapKt/ArraySetKt
    // classes duplicate the ones in collection-jvm:1.4.4 (pulled in by
    // runtime-android:1.7.6 via collection:1.4.4). The -ktx APIs moved into
    // collection itself in 1.4.0, and collection-ktx:1.4.4 is an empty jar,
    // so excluding the stale 1.2.0 jar removes no API the app uses (the
    // app's own code never imports androidx.collection). Without this the
    // build fails in :app:checkDebugDuplicateClasses. It must be excluded
    // globally: the -ktx jar enters through ui-tooling (debug) as well as
    // through ui, so excluding it from one dependency alone is not enough.
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("dev.rikka.shizuku:api:13.1.5")
    // Required because AndroidManifest declares rikka.shizuku.ShizukuProvider.
    implementation("dev.rikka.shizuku:provider:13.1.5")
    // ADDITIVE ONLY (Capture Test): hidden-API bypass for the probe.
    // Version 6.1 is the release that fixes Android 16 compatibility.
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:6.1")
}
