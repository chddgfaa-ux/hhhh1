# Prime Voice v34 — GitHub Build Error Fix

## Confirmed error from user's GitHub Actions screenshot
`FloatingMenuService.kt:461:38` — `Unresolved reference: LayoutParams` at `ScrollView.LayoutParams(-1, -2)`.

## Fix applied
- Added `import android.widget.FrameLayout`.
- Replaced `ScrollView.LayoutParams(-1, -2)` with `FrameLayout.LayoutParams(-1, -2)`.
- Incremented Android `versionCode` from 40 to 41 and updated `versionName` to v34.

## Verification scope
- Source contains the FrameLayout import and constructor.
- Old invalid constructor is absent.
- ZIP integrity is checked after packaging.
- This package has NOT been built with Android Gradle in this environment. A new GitHub Actions run is required; further compiler errors may still appear.
