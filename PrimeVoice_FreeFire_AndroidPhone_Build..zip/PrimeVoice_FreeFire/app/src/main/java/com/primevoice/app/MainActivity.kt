package com.primevoice.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File

private val Bg = Color(0xFF080D13)
private val Panel = Color(0xFF111B25)
private val Cyan = Color(0xFF20DDF5)
private val Muted = Color(0xFF8FA3B5)

data class SoundClip(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeVoiceApp() }
    }
}

@Composable
fun PrimeVoiceApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Live FX") }
    var status by remember { mutableStateOf("Ready") }
    var selectedEffect by remember { mutableStateOf("Deep") }
    var clips by remember { mutableStateOf(listOf<SoundClip>()) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var currentPosition by remember { mutableIntStateOf(0) }
    var trackDuration by remember { mutableIntStateOf(0) }
    var activeClip by remember { mutableStateOf<SoundClip?>(null) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    val liveEngine = remember { LiveAudioEngine() }
    var liveOn by remember { mutableStateOf(false) }

    val importAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val name = it.lastPathSegment?.substringAfterLast(':') ?: "Imported audio"
            clips = clips + SoundClip(name, it)
            status = "Added to soundboard"
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (tab == "Live FX") {
                liveEngine.effect = selectedEffect
                liveEngine.start { msg -> status = msg }
                liveOn = true
                status = "Live mic monitor started"
            } else status = "Microphone permission granted"
        } else status = "Microphone permission denied"
    }

    fun playClip(clip: SoundClip) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(context, clip.uri)
                setOnCompletionListener { it.release(); player = null; currentPosition = 0; status = "Finished" }
                prepare()
                trackDuration = duration
                currentPosition = 0
                activeClip = clip
                start()
            }
            status = "Playing: ${clip.name}"
        } catch (e: Exception) { status = "Cannot play this file" }
    }
    fun startLiveMonitor() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) { micPermission.launch(Manifest.permission.RECORD_AUDIO); return }
        liveEngine.effect = selectedEffect
        liveEngine.start { msg -> status = msg }
        liveOn = true
        status = "Live mic monitor started"
    }
    fun stopLiveMonitor() {
        liveEngine.stop()
        liveOn = false
        status = "Live mic monitor stopped"
    }
    fun stopAudio() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        currentPosition = 0
        activeClip = null
        status = "Stopped"
    }
    fun startRecording() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted) { micPermission.launch(Manifest.permission.RECORD_AUDIO); return }
        try {
            val file = File(context.getExternalFilesDir(null), "prime_voice_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordingFile = file
            isRecording = true
            status = "Recording…"
        } catch (e: Exception) { status = "Recorder could not start" }
    }
    fun stopRecording() {
        try {
            recorder?.stop()
            recorder?.release()
            recordingFile?.let { f ->
                clips = clips + SoundClip(f.name, Uri.fromFile(f))
            }
            status = "Recording saved to Soundboard"
        } catch (_: Exception) { status = "Recording was too short or failed" }
        recorder = null
        isRecording = false
    }

    LaunchedEffect(player) {
        while (player != null) {
            try { currentPosition = player?.currentPosition ?: 0 } catch (_: Exception) {}
            delay(250)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Live FX", "Soundboard", "Recorder", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) {
                            "Soundboard" -> Icons.Default.LibraryMusic
                            "Recorder" -> Icons.Default.Mic
                            "Settings" -> Icons.Default.Tune
                            else -> Icons.Default.GraphicEq
                        }, contentDescription = item) },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF183642), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PRIME VOICE", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("FREE FIRE EDITION • GAMING AUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Text("● READY", color = Cyan, fontSize = 11.sp)
                }
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("AUDIO STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Text(status, fontWeight = FontWeight.SemiBold)
                    }
                }
                when (tab) {
                    "Live FX" -> {
                        Text("LIVE VOICE EFFECTS", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Live microphone effects are monitored through this phone's audio output. Use headphones to reduce feedback. This does not inject processed audio into Free Fire chat.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Button(onClick = { if (liveOn) stopLiveMonitor() else startLiveMonitor() },
                            colors = ButtonDefaults.buttonColors(containerColor = if (liveOn) Color(0xFF9E3445) else Cyan, contentColor = Color.White)) {
                            Icon(if (liveOn) Icons.Default.Stop else Icons.Default.Mic, null)
                            Text(if (liveOn) "  STOP LIVE MONITOR" else "  START LIVE MONITOR")
                        }
                        listOf("Deep", "Female-style", "Robot", "Echo", "Monster", "Radio").forEach { effect ->
                            Surface(color = if (selectedEffect == effect) Color(0xFF153440) else Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { selectedEffect = effect; liveEngine.effect = effect }) {
                                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.GraphicEq, null, tint = Cyan)
                                    Spacer(Modifier.width(12.dp))
                                    Text(effect, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                    if (selectedEffect == effect) Text("SELECTED", color = Cyan, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    "Soundboard" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SOUND PACKS", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Button(onClick = { importAudio.launch(arrayOf("audio/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("IMPORT AUDIO") }
                        }
                        Text("Import MP3, WAV, M4A or other Android-supported audio files.", color = Muted, fontSize = 12.sp)
                        if (activeClip != null) {
                            Surface(color = Color(0xFF102630), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.GraphicEq, null, tint = Cyan)
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(activeClip?.name ?: "Now playing", color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text(if (player != null) "NOW PLAYING" else "PLAYBACK FINISHED", color = Cyan, fontSize = 10.sp, letterSpacing = 1.3.sp)
                                        }
                                        IconButton(onClick = { stopAudio() }) { Icon(Icons.Default.Stop, "Stop", tint = Cyan) }
                                    }
                                    Slider(
                                        value = if (trackDuration > 0) currentPosition.coerceIn(0, trackDuration).toFloat() else 0f,
                                        onValueChange = { value ->
                                            currentPosition = value.toInt()
                                            try { player?.seekTo(currentPosition) } catch (_: Exception) {}
                                        },
                                        valueRange = 0f..(trackDuration.coerceAtLeast(1).toFloat()),
                                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF36515C))
                                    )
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(formatTime(currentPosition), color = Muted, fontSize = 11.sp)
                                        Text(formatTime(trackDuration), color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        Button(onClick = { stopAudio() }, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cyan)) { Icon(Icons.Default.Stop, null); Text("  STOP PLAYBACK") }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(clips) { clip ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { playClip(clip) }) {
                                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Cyan)
                                        Spacer(Modifier.width(12.dp))
                                        Text(clip.name, modifier = Modifier.weight(1f), maxLines = 1)
                                        Text("PLAY", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        if (clips.isEmpty()) Text("No clips yet. Import an audio file or record your own.", color = Muted)
                    }
                    "Recorder" -> {
                        Text("VOICE RECORDER", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Record a voice clip and it will be added to your Soundboard.", color = Muted, fontSize = 13.sp)
                        Button(onClick = { if (isRecording) stopRecording() else startRecording() }, colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color(0xFF9E3445) else Cyan, contentColor = Color.White)) {
                            Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, null)
                            Text(if (isRecording) "  STOP & SAVE" else "  START RECORDING")
                        }
                    }
                    else -> {
                        Text("SETTINGS", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("No expiry timer • No mandatory access key • Local audio library", color = Color.White)
                        Text("Live mic effects are local monitoring only. Free Fire voice-chat injection and Shizuku routing are not implemented.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}


@Composable
private fun formatTime(milliseconds: Int): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0) / 1000)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
