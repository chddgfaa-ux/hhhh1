package com.primevoice.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.sin

/**
 * Low-latency microphone monitor with simple real-time effects.
 * Output is local monitoring only; it does not replace another app's mic input.
 */
class LiveAudioEngine {
    @Volatile private var running = false
    private var worker: Thread? = null
    @Volatile var effect: String = "Deep"

    fun start(onError: (String) -> Unit = {}) {
        if (running) return
        worker = Thread {
            val sampleRate = 44100
            val minIn = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val minOut = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minIn <= 0 || minOut <= 0) {
                onError("Audio device is not available")
                return@Thread
            }
            val bufferSize = maxOf(minIn, minOut, 4096)
            var recorder: AudioRecord? = null
            var track: AudioTrack? = null
            try {
                recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                track = AudioTrack.Builder()
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (recorder.state != AudioRecord.STATE_INITIALIZED ||
                    track.state != AudioTrack.STATE_INITIALIZED) {
                    onError("Could not initialize microphone/audio output")
                    return@Thread
                }
                val input = ShortArray(bufferSize / 2)
                val output = ShortArray(bufferSize / 2)
                val echo = FloatArray(sampleRate / 4)
                var echoIndex = 0
                var phase = 0.0
                var low = 0.0
                running = true
                recorder.startRecording()
                track.play()
                while (running) {
                    val count = recorder.read(input, 0, input.size)
                    if (count <= 0) continue
                    for (i in 0 until count) {
                        val x = input[i].toFloat() / 32768f
                        val y = when (effect) {
                            "Robot" -> {
                                phase += 2.0 * PI * 35.0 / sampleRate
                                (x * sin(phase) * 1.8).coerceIn(-1.0, 1.0).toFloat()
                            }
                            "Echo" -> {
                                val delayed = echo[echoIndex]
                                echo[echoIndex] = x + delayed * 0.35f
                                echoIndex = (echoIndex + 1) % echo.size
                                (x + delayed * 0.55f).coerceIn(-1f, 1f)
                            }
                            "Radio" -> {
                                low += 0.22 * (x - low)
                                ((x - low) * 3.0).coerceIn(-1.0, 1.0).toFloat()
                            }
                            "Monster", "Deep" -> {
                                low += 0.18 * (x - low)
                                (low * 1.8).coerceIn(-1.0, 1.0).toFloat()
                            }
                            "Female-style" -> {
                                // Bright EQ-style preview, not true pitch/formant shifting.
                                (x * 1.15f).coerceIn(-1f, 1f)
                            }
                            else -> x
                        }
                        output[i] = (y * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    }
                    track.write(output, 0, count)
                }
            } catch (e: SecurityException) {
                onError("Microphone permission is required")
            } catch (e: Exception) {
                onError("Audio engine error: ${e.message ?: "unknown"}")
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                try { recorder?.release() } catch (_: Exception) {}
                try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
                try { track?.release() } catch (_: Exception) {}
                running = false
            }
        }.apply { name = "PrimeVoiceAudio"; start() }
    }

    fun stop() {
        running = false
        try { worker?.join(500) } catch (_: InterruptedException) {}
        worker = null
    }

    fun isRunning() = running
}
