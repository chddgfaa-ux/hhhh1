# Prime Voice — Free Fire Edition (Prototype 1.3)

## Included
- Premium dark/cyan Jetpack Compose UI
- Live microphone monitor with simple real-time DSP presets: Deep/Monster (low-pass emphasis), Robot (ring modulation), Echo (delay), Radio (band-limited style), Female-style (bright EQ only)
- Soundboard: import Android-supported audio files and play/stop them
- Now Playing panel with elapsed time, total duration, seek/progress slider
- Microphone recorder: records M4A clips and adds them to the in-app soundboard
- No account key and no expiry timer

## Open in Android Studio
1. Extract the ZIP.
2. Open the extracted `PrimeVoice_FreeFire` folder in Android Studio.
3. Allow Gradle sync.
4. Run on an Android phone (Android 8.0+).
5. Grant microphone permission when prompted. Use wired/Bluetooth headphones to avoid acoustic feedback.

## Important limitations
- Live FX currently processes the microphone for local monitoring through the phone output. The "Female-style" preset is EQ brightening, not true pitch/formant transformation.
- This app does NOT inject processed audio into Free Fire's microphone/chat. Android does not provide ordinary apps a universal public API for replacing another app's mic input; Shizuku alone does not guarantee this.
- ZIP pack import/export, actual waveform visualization, floating overlay and Shizuku integration remain future work.
