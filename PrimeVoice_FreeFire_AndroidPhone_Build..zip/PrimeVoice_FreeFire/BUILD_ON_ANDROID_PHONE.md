# Build Prime Voice APK using only an Android phone

This project includes a GitHub Actions workflow so you do not need a PC or Android Studio.

1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this project ZIP to the repository (extract the ZIP first; upload the files/folders, including `.github`).
3. Open the repository's **Actions** tab.
4. Select **Build Prime Voice APK** and tap **Run workflow** (or wait for the push build).
5. When the workflow finishes successfully, open the run, scroll to **Artifacts**, and download `Prime-Voice-debug-apk`.
6. Extract the artifact ZIP. It contains `app-debug.apk`. Tap it to install; allow installation from that browser/files app if Android asks.

Notes:
- The build is performed on GitHub's hosted Linux runner, not on your phone.
- A GitHub account is required. Keep the repository private if you do not want to publish the source.
- The first build may fail if there are source-code or dependency issues; read the Actions build log and share the error screenshot/log so it can be fixed.
- This debug APK is for testing. A release APK should later be signed with a key you control.
- Live effects are local microphone monitoring only. Free Fire voice-chat routing is not implemented or guaranteed.
