# Prime Voice v35 — Shizuku Connection Diagnostics & Heartbeat Recovery

## Changes applied
- Added structured Logcat events under tag `PrimeVoiceShizuku` for startup probe, permission result, manual check, Shizuku manager Binder receive/death, UserService bind request/throw, service connection/disconnection, Binder handshake start/success/failure, and heartbeat timeout.
- Added a 5-second watchdog to both MainActivity diagnostic and FloatingMenuService playback heartbeats. A blocked `getDiagnostics()` Binder transaction can no longer leave the heartbeat in-flight flag permanently set and silently prevent future probes.
- Kept the existing 8-second bind/handshake timeout, remote Binder death recipient, bounded exponential reconnect, separate diagnostic/playback process suffixes, and Shizuku permission flow.
- Reset the diagnostic reconnect counter when the user manually retries CHECK / REQUEST SHIZUKU.
- Bumped versionCode to 42 and versionName to `1.9 Injector v35 Shizuku Diagnostics`.

## Logcat capture
After installing the build, start Shizuku, grant Prime Voice permission, tap CHECK / REQUEST SHIZUKU, then capture:

```sh
logcat -d -v time | grep -iE 'PrimeVoiceShizuku|ShizukuServerLog|com\.primevoice\.app|AndroidRuntime|FATAL EXCEPTION'
```

Expected successful sequence includes `STARTUP_PROBE`, `BIND_REQUEST`, `SERVICE_CONNECTED`, `HANDSHAKE_START`, and `BRIDGE_READY`. If `BIND_REQUEST` appears without `SERVICE_CONNECTED`, the failure is before the app receives its UserService Binder. If `SERVICE_CONNECTED` appears without `BRIDGE_READY`, inspect handshake or timeout events.

## Verification limits
- Source-level patch only. This environment has Java but no Gradle executable, Gradle wrapper, or configured Android SDK; no APK build or Kotlin compile was run.
- No Redmi 14C / Shizuku-Next runtime test was run. The new logs are intended to identify the exact failing stage on-device; they do not claim the connection is now confirmed working.
- AudioPolicy delivery to Free Fire remains a separate device/game validation.
